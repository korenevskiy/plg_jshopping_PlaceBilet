# Vuejs scan qrcode
Vuejs scan qrcode สอนการเขียน Javascript กับการ scan barcode แบบง่ายๆกันครับ

Credit : https://github.com/schmich/instascan
