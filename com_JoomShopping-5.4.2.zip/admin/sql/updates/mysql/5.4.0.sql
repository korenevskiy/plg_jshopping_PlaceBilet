ALTER TABLE `#__jshopping_payment_method` ADD `access` INT NOT NULL default 1;
ALTER TABLE `#__jshopping_shipping_method` ADD `access` INT NOT NULL default 1;