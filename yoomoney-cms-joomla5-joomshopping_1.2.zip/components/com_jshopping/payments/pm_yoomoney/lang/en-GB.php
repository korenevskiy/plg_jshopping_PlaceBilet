<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

defined('_JEXEC') or die();

const _JSHOP_YOO_LICENSE_TEXT = "To start operating the module, connect your store to <a target=\"_blank\" href=\"https://yookassa.ru/en/\">YooKassa</a>";
const _JSHOP_YOO_VERSION_DESCRIPTION = 'Module version ';

const _JSHOP_YOO_TAB_KASSA = 'YooKassa';

const _JSHOP_ERROR_PAYMENT = 'Please activate payment method';

const _JSHOP_YOO_KASSA_ON = 'Enable payment acceptance via YooKassa';

const _JSHOP_YOO_KASSA_HEAD_LK = 'Link your website on Joomla to your store in YooMoney';
const _JSHOP_YOO_KASSA_SHOP_ID_LABEL = 'shopid';
const _JSHOP_YOO_KASSA_TEST_STORE = 'Test store';
const _JSHOP_YOO_KASSA_REAL_STORE = 'Real store';
const _JSHOP_YOO_KASSA_URL_HELP_HEAD = 'If you aren\'t receiving notifications about payments, you need to change the address';
const _JSHOP_YOO_KASSA_URL_HELP_TEXT = 'Ask your developer to set a new address for notifications or contact the YooKassa Support Service';
const _JSHOP_YOO_KASSA_URL_DEFAULT = 'Default address: ';
const _JSHOP_YOO_KASSA_FISCALIZATION_HELP_HEAD = 'To activate your online sales register, enable sending data for receipts to YooMoney';
const _JSHOP_YOO_KASSA_FISCALIZATION_HELP_TEXT_STRONG = 'Important: ';
const _JSHOP_YOO_KASSA_FISCALIZATION_HELP_TEXT = 'if you selected not to link the payment to the receipt, then you don\'t need to enable this feature.';
const _JSHOP_YOO_KASSA_TEST_SHOP_HELP_HEAD = 'To switch from the test store to the real store, click "Switch store"';
const _JSHOP_YOO_KASSA_TEST_SHOP_HELP_TEXT = 'In the pop-up window, sign in to your account, give YooKassa access, and select the required store.';
const _JSHOP_YOO_KASSA_DEFAULT_PAYMENT_MODE_LABEL = 'Payment mode';
const _JSHOP_YOO_KASSA_DEFAULT_PAYMENT_SUBJECT_LABEL = 'Payment subject';
const _JSHOP_YOO_KASSA_DEFAULT_DELIVERY_MODE_LABEL = 'Delivery payment mode';
const _JSHOP_YOO_KASSA_DEFAULT_DELIVERY_SUBJECT_LABEL = 'Delivery payment subject';
const _JSHOP_YOO_KASSA_DEBUG = 'Logging';

const _JSHOP_YOO_KASSA_PAYMENT_MODE_FULL_PREPAYMENT = 'Full prepayment (full_prepayment)';
const _JSHOP_YOO_KASSA_PAYMENT_MODE_PARTIAL_PREPAYMENT = 'Partial prepayment (partial_prepayment)';
const _JSHOP_YOO_KASSA_PAYMENT_MODE_ADVANCE = 'Advance payment (advance)';
const _JSHOP_YOO_KASSA_PAYMENT_MODE_FULL_PAYMENT = 'Full payment (full_payment)';
const _JSHOP_YOO_KASSA_PAYMENT_MODE_PARTIAL_PAYMENT = 'Partial payment and loan (partial_payment)';
const _JSHOP_YOO_KASSA_PAYMENT_MODE_CREDIT = 'Loan (credit)';
const _JSHOP_YOO_KASSA_PAYMENT_MODE_CREDIT_PAYMENT = 'Loan repayment (credit_payment)';

const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_COMMODITY = 'Product (commodity)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_EXCISE = 'Excisable goods (excise)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_JOB = 'Job (job)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_SERVICE = 'Service (service)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_GAMBLING_BET = 'Gambling bet (gambling_bet)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_GAMBLING_PRIZE = 'Gambling winnings (gambling_prize)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_LOTTERY = 'Lottery ticket (lottery)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_LOTTERY_PRIZE = 'Lottery winnings (lottery_prize)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_INTELLECTUAL_ACTIVITY = 'Intellectual property (intellectual_activity)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_PAYMENT = 'Payment (payment)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_AGENT_COMMISSION = 'Agent’s commission (agent_commission)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_COMPOSITE = 'Several subjects (composite)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_ANOTHER = 'Another (another)';

const _JSHOP_YOO_KASSA_PAYMODE_HEAD = 'Check the preferable scenario of selecting the payment method';
const _JSHOP_YOO_KASSA_PAYMODE_LABEL = 'Select payment method';
const _JSHOP_YOO_KASSA_SEND_RECEIPT_LABEL = 'Transmit details for receipts to YooKassa (Federal Law 54-FZ)';
const _JSHOP_YOO_KASSA_SEND_SECOND_RECEIPT_LABEL = 'Second receipt:';
const _JSHOP_YOO_KASSA_SEND_SECOND_RECEIPT_STATUS_LABEL = 'Send the second receipt when order status changes to';
const _JSHOP_YOO_KASSA_SEND_SECOND_RECEIPT_INFO = 'Two checks need to be formed if the customer makes an advance payment and then receives the goods or services. The first check — when the money comes to your account, the second — when shipping goods or performing services.';
const _JSHOP_YOO_KASSA_SEND_SECOND_RECEIPT_HELP_BLOCK = 'If there are items in the order with the signs «Full prepayment» — the second check will be sent automatically when the order enters the selected status.';
const _JSHOP_YOO_KASSA_SEND_SECOND_RECEIPT_HISTORY = 'The second receipt was sent. Amount %s rubles.';
const _JSHOP_YOO_KASSA_PAYMODE_KASSA = 'On YooKassa\'s site';
const _JSHOP_YOO_KASSA_PAYMODE_SHOP = 'On the store\'s site';
const _JSHOP_YOO_KASSA_PAYMODE_LINK = '<a href=\'https://yookassa.ru/docs/payment-solution/payments/payment-form/basics\' target=\'_blank\'>More about payment scenarios</a>';
const _JSHOP_YOO_KASSA_SELECT_TEXT = 'Check payment methods from the contract';

const _JSHOP_YOO_DESCRIPTION_TITLE = 'Transaction data';
const _JSHOP_YOO_DESCRIPTION_DEFAULT_PLACEHOLDER = 'Payment for order No. %order_id%';
const _JSHOP_YOO_ENABLE_HOLD_MODE = 'Enable payment holding';
const _JSHOP_YOO_ENABLE_HOLD_MODE_HELP = 'If the option is enabled, payments are processed in two steps: first, the required amount is blocked on the customer’s card, and then you need to manually capture it via the administrator’s dashboard. <a href="https://yookassa.ru/features/#10" target="_blank">Learn more at</a>';
const _JSHOP_YOO_HOLD_MODE_STATUSES = 'What status should be assigned to an order if it is:';
const _JSHOP_YOO_HOLD_MODE_ON_HOLD_STATUS = 'waiting for capture';
const _JSHOP_YOO_HOLD_MODE_CANCEL_STATUS = 'canceled';
const _JSHOP_YOO_HOLD_MODE_CANCEL_STATUS_HELP = 'the order status will be changed to this one after the payment is canceled';
const _JSHOP_YOO_HOLD_MODE_COMMENT_ON_HOLD = 'New payment received. Capture until %1$s, after that date it will be automatically canceled';
const _JSHOP_YOO_HOLD_MODE_CAPTURE_PAYMENT_SUCCESS = 'You\'ve captured a payment in YooKassa. ';
const _JSHOP_YOO_HOLD_MODE_CAPTURE_PAYMENT_FAIL = 'Payment wasn\'t captured. Please try again.';
const _JSHOP_YOO_HOLD_MODE_CANCEL_PAYMENT_SUCCESS = 'You\'ve canceled a payment in YooKassa.  Money will be returned to the user.';
const _JSHOP_YOO_HOLD_MODE_CANCEL_PAYMENT_FAIL = 'Payment wasn\'t canceled. Please try again.';
const _JSHOP_YOO_DESCRIPTION_HELP = 'Full description of the transaction that the user will see during the checkout process. You can find it in your YooKassa Merchant Profile. For example, "Payment for order No. 72 by user@yoomoney.ru". Limitations: no more than 128 symbols.';
const _JSHOP_YOO_METHOD_YOO_MONEY_DESCRIPTION = 'YooMoney';
const _JSHOP_YOO_METHOD_CARDS_DESCRIPTION = 'Bank cards';
const _JSHOP_YOO_METHOD_BANK_CARD_DESCRIPTION = 'Bank cards';
const _JSHOP_YOO_METHOD_CASH_DESCRIPTION = 'Cash via payment kiosks';
const _JSHOP_YOO_METHOD_SBERBANK_DESCRIPTION = 'SberPay';
const _JSHOP_YOO_METHOD_TINKOFF_BANK_DESCRIPTION = 'Tinkoff online banking';
const _JSHOP_YOO_METHOD_WIDGET_DESCRIPTION = 'Payment widget from YooKassa';
const _JSHOP_YOO_METHOD_SBP_DESCRIPTION = 'SBP';
const _JSHOP_YOO_METHOD_SBER_LOAN_DESCRIPTION = '«Credit purchases» by SberBank';

const _JSHOP_YOO_METHOD_YOO_MONEY_DESCRIPTION_PUBLIC = 'YooMoney';
const _JSHOP_YOO_METHOD_CARDS_DESCRIPTION_PUBLIC = 'Bank cards';
const _JSHOP_YOO_METHOD_BANK_CARD_DESCRIPTION_PUBLIC = 'Bank cards';
const _JSHOP_YOO_METHOD_CASH_DESCRIPTION_PUBLIC = 'Cash via payment kiosks';
const _JSHOP_YOO_METHOD_SBERBANK_DESCRIPTION_PUBLIC = 'SberPay';
const _JSHOP_YOO_METHOD_TINKOFF_BANK_DESCRIPTION_PUBLIC = 'Tinkoff online banking';
const _JSHOP_YOO_METHOD_WIDGET_DESCRIPTION_PUBLIC = 'Bank cards';
const _JSHOP_YOO_METHOD_SBP_DESCRIPTION_PUBLIC = 'SBP';
const _JSHOP_YOO_METHOD_SBER_LOAN_DESCRIPTION_PUBLIC = '«Credit purchases» by SberBank';

const _JSHOP_YOO_INSTALL_VERIFY_APPLE_PAY_FILE_WARNING = 'Чтобы покупатели могли заплатить вам через Apple Pay, <a href="https://yookassa.ru/docs/merchant.ru.yoomoney">скачайте файл apple-developer-merchantid-domain-association</a> и добавьте его в папку ./well-known на вашем сайте. Если не знаете, как это сделать, обратитесь к администратору сайта или в поддержку хостинга. Не забудьте также подключить оплату через Apple Pay <a href="https://yookassa.ru/my/payment-methods/settings#applePay">в личном кабинете ЮKassa</a>. <a href="https://yookassa.ru/developers/payment-forms/widget#apple-pay-configuration">Почитать о подключении Apple Pay в документации ЮKassa</a>';

const _JSHOP_YOO_COMMON_HEAD = 'Additional settings for administrator';
const _JSHOP_YOO_COMMON_STATUS = 'Order status after the payment';

const _JSHOP_YOO_LICENSE = 'License agreement:';
const _JSHOP_YOO_LICENSE_TEXT2 = "<p>By using this program in any way, you fully and unconditionally accept <a href=\"https://yoomoney.ru/doc.xml?id=527132\">the terms of the license agreement</a>. If you do not accept any part of the terms of the license agreement, you are forbidden to use the program for any purpose.</p>";

//updater
const _JSHOP_YOO_UPDATER_ERROR_RESTORE = 'Unable to restore the data from the backup. ';
const _JSHOP_YOO_UPDATER_SUCCESS_MESSAGE = 'Module successfully installed ';
const _JSHOP_YOO_UPDATER_ERROR_REMOVE = 'Unable to delete backup %s.';
const _JSHOP_YOO_ERROR_BACKUP_NOT_FOUND = 'Unable to delete backup %s.';
const _JSHOP_YOO_ERROR_REMOVE_BACKUP = 'Unable to delete backup %s.';
const _JSHOP_YOO_SUCCESS_REMOVE_BECKUP = 'Backup %s successfully deleted';
const _JSHOP_YOO_SUCCESS_UPDATE_VERSION = 'Module version %s successfully downloaded and installed';
const _JSHOP_YOO_ERROR_UNPACK_NEW_VERSION = 'Unable to extract archive %s. More about the error in <a href="%s">module\'s logs</a>';
const _JSHOP_YOO_ERROR_CREATE_BACKUP = 'Unable to create a backup copy of the installed module version. More about the error in <a href="%s">module\'s logs</a>';
const _JSHOP_YOO_ERROR_DOWNLOAD_NEW_VERSION = 'Unable to load the archive, please try again. More about the error in <a href="%s">module\'s logs</a>';
const _JSHOP_YOO_FAILED_CREATE_DIRECTORY = 'Unable to create directory ';
const _JSHOP_YOO_FAILED_DOWNLOAD_UPDATE = 'Unable to load the archive with the update';
const _JSHOP_YOO_UPDATER_HEADER_TEXT = ' New module versions with added features and fixed errors will appear here. Click the Update button to install the latest module version.';
const _JSHOP_YOO_UPDATER_ABOUT = 'About the module:';
const _JSHOP_YOO_UPDATER_CURRENT_VERSION = 'Current module version —';
const _JSHOP_YOO_UPDATER_LAST_VERSION = 'Latest available module version —';
const _JSHOP_YOO_UPDATER_LAST_CHECK = 'Date of the last check for updates —';
const _JSHOP_YOO_UPDATER_CHECK = 'Check for updates';
const _JSHOP_YOO_HISTORY_LABEL = 'Changelog:';
const _JSHOP_YOO_UPDATE_LABEL = 'Update module';
const _JSHOP_YOO_INSTALL_MESSAGE = 'You have the latest module version installed.';
const _JSHOP_YOO_BACKUPS_LABEL = 'Backups';
const _JSHOP_YOO_MODULE_VERSION_LABEL = 'Module version';
const _JSHOP_YOO_BACKUP_DATE_CREATE = 'Creation date';
const _JSHOP_YOO_BACKUP_FILE_NAME = 'File name';
const _JSHOP_YOO_BACKUP_FILE_SIZE = 'File size';
const _JSHOP_YOO_UPDATER_RESTORE = 'Restore';
const _JSHOP_YOO_UPDATER_DELETE = 'Remove';
const _JSHOP_YOO_UPDATER_APPROVE_ACTION_MESSAGE = 'Do you really want to update module?';
const _JSHOP_YOO_UPDATER_APPROVE_DELETE_MESSAGE = 'Do you really want to delete the backup copy of this module version ';
const _JSHOP_YOO_UPDATER_APPROVE_RESTORE_MESSAGE = 'Do you really want to restore the module from the backup copy of this version';
const _JSHOP_YOO_UPDATER_TEXT_HEADER = 'Module updates';
const _JSHOP_YOO_UPDATER_ABOUT_TEXT = 'New module versions with added features and fixed errors will appear here. Click the Update button to install the latest module version.';
const _JSHOP_YOO_UPDATER_DISABLED_TEXT = 'Unfortunately, the module update option is unavailable';
const _JSHOP_YOO_UPDATER_CAUSE_ZIP_CURL = 'because the <strong>"zip"</strong> and <strong>"curl"</strong> extensions are not installed.';
const _JSHOP_YOO_UPDATER_CAUSE_ZIP = 'because the <strong>"zip"</strong> extension is not installed.';
const _JSHOP_YOO_UPDATER_CAUSE_CURL = 'because the <strong>"curl"</strong> extension is not installed.';

const _JSHOP_YOO_WAITING_FOR_CAPTURE = 'Waiting for capture';
const _JSHOP_YOO_CAPTURE_FAILED = 'Capture failed';
const _JSHOP_YOO_PAYMENT_CAPTURED = 'Payment captured';
const _JSHOP_YOO_PAYMENT_CAPTURED_TEXT = 'Payment %s captured';
const _JSHOP_YOO_ERROR_MESSAGE_CREATE_PAYMENT = 'Unable to create the payment, choose another payment method.';
const _JSHOP_YOO_ENABLE = 'Enable';
const _JSHOP_YOO_DISABLE = 'Disable';
const _JSHOP_YOO_DEFAULT_TAX_LABEL = 'Default rate';
const _JSHOP_YOO_DEFAULT_TAX_DESCRIPTION = 'The default rate applies if another rate is not set on the product\'s page.';
const _JSHOP_YOO_TAX_RATES_LABEL = 'Compare rates';
const _JSHOP_YOO_TAX_IN_MODULE = 'Rate at your store';
const _JSHOP_YOO_TAX_FOR_CHECKOUT = 'Rate for the receipt to the tax service';
const _JSHOP_YOO_WITHOUT_VAT = 'Without VAT';
const _JSHOP_YOO_VAT_0 = '0%';
const _JSHOP_YOO_VAT_10 = '10%';
const _JSHOP_YOO_VAT_20 = '20%';
const _JSHOP_YOO_VAT_10_100 = 'Applicable rate 10/110';
const _JSHOP_YOO_VAT_20_120 = 'Applicable rate 20/120';

const _JSHOP_YOO_DEFAULT_TAX_SYSTEM_LABEL = 'Default tax system';
const _JSHOP_YOO_DEFAULT_TAX_SYSTEM_DESCRIPTION = 'Select the default tax system. This parameter is only required if you have several tax systems, otherwise it is not passed.';
const _JSHOP_YOO_DEFAULT_TAX_SYSTEM_1_LABEL = 'General tax system';
const _JSHOP_YOO_DEFAULT_TAX_SYSTEM_2_LABEL = 'Simplified (STS, income)';
const _JSHOP_YOO_DEFAULT_TAX_SYSTEM_3_LABEL = 'Simplified (STS, income with costs deducted)';
const _JSHOP_YOO_DEFAULT_TAX_SYSTEM_4_LABEL = 'Unified tax on imputed income (ENVD)';
const _JSHOP_YOO_DEFAULT_TAX_SYSTEM_5_LABEL = 'Unified agricultural tax (ESN)';
const _JSHOP_YOO_DEFAULT_TAX_SYSTEM_6_LABEL = 'Patent Based Tax System';

const _JSHOP_YOO_NOTIFICATION_URL_LABEL = 'Address for notifications';
const _JSHOP_YOO_LOG_VIEW_LABEL = 'View logs';
const _JSHOP_YOO_CLEAR_LOGS = 'Clear logs';
const _JSHOP_YOO_CLOSE = 'Close';
const _JSHOP_YOO_LOGS_LABEL = 'Logs';

const _JSHOP_YOO_TAB_UPDATE = 'Module update';

const _JSHOP_YOO_BTN_BACK = 'Back';
const _JSHOP_REDIRECT_TO_PAYMENT_PAGE = 'Redirecting to the Payment page, please wait...';
const _JSHOP_PAYMENT_NUMBER = 'Order number %s';
const _JSHOP_YOO_KASSA_REFUND_SUCCEDED_ORDER_HISTORY = 'Refund was made. Amount is %s ₽.';

const _JSHOP_YOO_AUTHORIZATION_TITLE_ERROR = 'Couldn\'t link the website to your Merchant Profile';
const _JSHOP_YOO_AUTHORIZATION_TEXT_ERROR = 'Connect your store to YooMoney again. If it doesn\'t work, contact tech support.';
const _JSHOP_YOO_OAUTH_CONNECT_ERROR = 'Something went wrong. Refresh the page and try again.';
const _JSHOP_YOO_SHOP_INSTRUCTION = 'If you don\'t want to enter the shopid and secret key manually anymore,<br>change the store using this button.';
const _JSHOP_YOO_OAUTH_BTN_CONNECT = 'Connect your store';
const _JSHOP_YOO_OAUTH_BTN_RECONNECT = 'Connect store to YooMoney again';
const _JSHOP_YOO_OAUTH_BTN_CHANGE = 'Change store';

const _JSHOP_YOO_SBER_LOAN_NAME_DISCOUNT = 'Installment plan by SberBank';
const _JSHOP_YOO_SBER_LOAN_WARNING_TITLE = 'You have the "Credit purchases" by SberBank payment method enabled';
const _JSHOP_YOO_SBER_LOAN_WARNING_TEXT = 'It includes <a href="https://yookassa.ru/developers/payment-acceptance/integration-scenarios/manual-integration/other/sber-loan#payment-method-overview-loan-options" target="_blank">loans and installment plans</a>. If a customer uses an installment plan for a payment, the CMS might display the purchase amount incorrectly (the correct amount is going to be displayed <a href="https://yookassa.ru/my/payments" target="_blank">in your YooMoney Merchant Profile</a>). It won\'t have any effect on the customer: they\'re always going to pay the correct amount.';
const _JSHOP_YOO_SBER_LOAN_WARNING_TEXT_INSTRUCTION = 'In order for the displayed amounts to match, make sure your CMS is configured <a href="https://yookassa.ru/docs/support/payments/onboarding/integration/cms-module/joomshopping#sber" target="_blank">using these parameters</a>';
const _JSHOP_YOO_SBER_LOAN_CREATE_PAYMENT_ERROR = '<b>Can\'t create the order</b><br> With this payment method selected, the order amount must be between 3,000 and 600,000 ₽. Add more items to the cart or remove excess items and try again.';