<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

defined('_JEXEC') or die();

//определяем константы для русского языка
const _JSHOP_YOO_LICENSE_TEXT = "Для работы с модулем нужно подключить магазин к <a target=\"_blank\" href=\"https://yookassa.ru/\">ЮKassa</a>";
const _JSHOP_YOO_VERSION_DESCRIPTION = 'Версия модуля ';
const _JSHOP_YOO_TAB_KASSA = 'ЮKassa';

const _JSHOP_ERROR_PAYMENT = 'Пожалуйста, включите способ оплаты';

const _JSHOP_YOO_KASSA_ON = 'Включить приём платежей через ЮKassa';

const _JSHOP_YOO_KASSA_HEAD_LK = 'Свяжите ваш сайт на Joomla с магазином в ЮKassa';
const _JSHOP_YOO_KASSA_SHOP_ID_LABEL = 'shopid';
const _JSHOP_YOO_KASSA_TEST_STORE = 'Тестовый магазин';
const _JSHOP_YOO_KASSA_REAL_STORE = 'Боевой магазин';
const _JSHOP_YOO_KASSA_URL_HELP_HEAD = 'Если вы не получаете уведомления о платежах, нужно изменить адрес';
const _JSHOP_YOO_KASSA_URL_HELP_TEXT = 'Попросите вашего разработчика установить новый адрес уведомлений или свяжитесь с техподдержкой ЮKassa';
const _JSHOP_YOO_KASSA_URL_DEFAULT = 'Адрес по умолчанию: ';
const _JSHOP_YOO_KASSA_FISCALIZATION_HELP_HEAD = 'Чтобы онлайн-касса заработала, включите отправку в ЮKassa данных для чеков';
const _JSHOP_YOO_KASSA_FISCALIZATION_HELP_TEXT_STRONG = 'Важно: ';
const _JSHOP_YOO_KASSA_FISCALIZATION_HELP_TEXT = 'если в личном кабинете ЮKassa вы выбрали не связывать платёж и чек, то ставить галочку не нужно.';
const _JSHOP_YOO_KASSA_TEST_SHOP_HELP_HEAD = 'Чтобы перейти с тестового магазина на настоящий, нажмите на кнопку «Сменить магазин»';
const _JSHOP_YOO_KASSA_TEST_SHOP_HELP_TEXT = 'Во всплывающем окне войдите в личный кабинет, разрешите доступ к ЮKassa и выберите нужный магазин.';
const _JSHOP_YOO_KASSA_DEFAULT_PAYMENT_MODE_LABEL = 'Признак способа расчета';
const _JSHOP_YOO_KASSA_DEFAULT_PAYMENT_SUBJECT_LABEL = 'Признак предмета расчета';
const _JSHOP_YOO_KASSA_DEFAULT_DELIVERY_MODE_LABEL = 'Признак способа расчета для доставки';
const _JSHOP_YOO_KASSA_DEFAULT_DELIVERY_SUBJECT_LABEL = 'Признак предмета расчета для доставки';
const _JSHOP_YOO_KASSA_DEBUG = 'Логирование';

const _JSHOP_YOO_KASSA_PAYMENT_MODE_FULL_PREPAYMENT = 'Полная предоплата (full_prepayment)';
const _JSHOP_YOO_KASSA_PAYMENT_MODE_PARTIAL_PREPAYMENT = 'Частичная предоплата (partial_prepayment)';
const _JSHOP_YOO_KASSA_PAYMENT_MODE_ADVANCE = 'Аванс (advance)';
const _JSHOP_YOO_KASSA_PAYMENT_MODE_FULL_PAYMENT = 'Полный расчет (full_payment)';
const _JSHOP_YOO_KASSA_PAYMENT_MODE_PARTIAL_PAYMENT = 'Частичный расчет и кредит (partial_payment)';
const _JSHOP_YOO_KASSA_PAYMENT_MODE_CREDIT = 'Кредит (credit)';
const _JSHOP_YOO_KASSA_PAYMENT_MODE_CREDIT_PAYMENT = 'Выплата по кредиту (credit_payment)';

const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_COMMODITY = 'Товар (commodity)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_EXCISE = 'Подакцизный товар (excise)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_JOB = 'Работа (job)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_SERVICE = 'Услуга (service)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_GAMBLING_BET = 'Ставка в азартной игре (gambling_bet)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_GAMBLING_PRIZE = 'Выигрыш в азартной игре (gambling_prize)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_LOTTERY = 'Лотерейный билет (lottery)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_LOTTERY_PRIZE = 'Выигрыш в лотерею (lottery_prize)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_INTELLECTUAL_ACTIVITY = 'Результаты интеллектуальной деятельности (intellectual_activity)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_PAYMENT = 'Платеж (payment)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_AGENT_COMMISSION = 'Агентское вознаграждение (agent_commission)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_COMPOSITE = 'Несколько вариантов (composite)';
const _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_ANOTHER = 'Другое (another)';

const _JSHOP_YOO_KASSA_PAYMODE_HEAD = 'Настройка сценария оплаты';
const _JSHOP_YOO_KASSA_PAYMODE_LABEL = 'Выбор способа оплаты';
const _JSHOP_YOO_KASSA_SEND_RECEIPT_LABEL = 'Отправлять в ЮKassa данные для чеков (54-ФЗ)';
const _JSHOP_YOO_KASSA_SEND_SECOND_RECEIPT_LABEL = 'Второй чек:';
const _JSHOP_YOO_KASSA_SEND_SECOND_RECEIPT_STATUS_LABEL = 'Формировать второй чек при переходе заказа в статус';
const _JSHOP_YOO_KASSA_SEND_SECOND_RECEIPT_INFO = 'Два чека нужно формировать, если покупатель вносит предоплату и потом получает товар или услугу. Первый чек — когда деньги поступают вам на счёт, второй — при отгрузке товаров или выполнении услуг.';
const _JSHOP_YOO_KASSA_SEND_SECOND_RECEIPT_HELP_BLOCK = 'Если в заказе будут позиции с признаками «Полная предоплата» — второй чек отправится автоматически, когда заказ перейдёт в выбранный статус.';
const _JSHOP_YOO_KASSA_SEND_SECOND_RECEIPT_HISTORY = 'Отправлен второй чек. Сумма %s рублей.';
const _JSHOP_YOO_DESCRIPTION_TITLE = 'Описание платежа';
const _JSHOP_YOO_DESCRIPTION_DEFAULT_PLACEHOLDER = 'Оплата заказа №%order_id%';
const _JSHOP_YOO_DESCRIPTION_HELP = 'Это описание транзакции, которое пользователь увидит при оплате, а вы — в личном кабинете ЮKassa. Например, «Оплата заказа №72».<br>
Чтобы в описание подставлялся номер заказа (как в примере), поставьте на его месте %order_id% (Оплата заказа №%order_id%).<br>
Ограничение для описания — 128 символов.';
const _JSHOP_YOO_ENABLE_HOLD_MODE = 'Включить отложенную оплату';
const _JSHOP_YOO_ENABLE_HOLD_MODE_HELP = 'Если опция включена, платежи с карт проходят в 2 этапа: у клиента сумма замораживается, и вам вручную нужно подтвердить её списание – через панель администратора. <a href="https://yookassa.ru/features/#10" target="_blank">Подробное описание Холдирования</a>';
const _JSHOP_YOO_HOLD_MODE_STATUSES = 'Какой статус присваивать заказу, если он:';
const _JSHOP_YOO_HOLD_MODE_ON_HOLD_STATUS = 'ожидает подтверждения';
const _JSHOP_YOO_HOLD_MODE_CANCEL_STATUS = 'отменён';
const _JSHOP_YOO_HOLD_MODE_COMMENT_ON_HOLD = 'Поступил новый платёж. Он ожидает подтверждения до %1$s, после чего автоматически отменится';
const _JSHOP_YOO_HOLD_MODE_CAPTURE_PAYMENT_SUCCESS = 'Вы подтвердили платёж в ЮKassa.';
const _JSHOP_YOO_HOLD_MODE_CAPTURE_PAYMENT_FAIL = 'Платёж не подтвердился. Попробуйте ещё раз.';
const _JSHOP_YOO_HOLD_MODE_CANCEL_PAYMENT_SUCCESS = 'Вы отменили платёж в ЮKassa. Деньги вернутся клиенту.';
const _JSHOP_YOO_HOLD_MODE_CANCEL_PAYMENT_FAIL = 'Платёж не отменился. Попробуйте ещё раз.';
const _JSHOP_YOO_KASSA_PAYMODE_KASSA = 'На стороне ЮKassa';
const _JSHOP_YOO_KASSA_PAYMODE_SHOP = 'На стороне магазина';
const _JSHOP_YOO_KASSA_PAYMODE_LINK = '<a href=\'https://yookassa.ru/docs/payment-solution/payments/payment-form/basics\' target=\'_blank\'>Подробнее о сценариях оплаты</a>';
const _JSHOP_YOO_KASSA_SELECT_TEXT = 'Отметьте способы оплаты, которые указаны в вашем договоре с ЮKassa';

const _JSHOP_YOO_METHOD_YOO_MONEY_DESCRIPTION = 'ЮMoney';
const _JSHOP_YOO_METHOD_CARDS_DESCRIPTION = 'Банковские карты';
const _JSHOP_YOO_METHOD_BANK_CARD_DESCRIPTION = 'Банковские карты';
const _JSHOP_YOO_METHOD_CASH_DESCRIPTION = 'Наличные через терминалы';
const _JSHOP_YOO_METHOD_SBERBANK_DESCRIPTION = 'SberPay';
const _JSHOP_YOO_METHOD_TINKOFF_BANK_DESCRIPTION = 'Интернет-банк Тинькофф';
const _JSHOP_YOO_METHOD_WIDGET_DESCRIPTION = 'Платёжный виджет ЮKassa';
const _JSHOP_YOO_METHOD_SBP_DESCRIPTION = 'СБП';
const _JSHOP_YOO_METHOD_SBER_LOAN_DESCRIPTION = '«Покупки в кредит» от СберБанка';

const _JSHOP_YOO_METHOD_YOO_MONEY_DESCRIPTION_PUBLIC = 'ЮMoney';
const _JSHOP_YOO_METHOD_CARDS_DESCRIPTION_PUBLIC = 'Банковские карты';
const _JSHOP_YOO_METHOD_BANK_CARD_DESCRIPTION_PUBLIC = 'Банковские карты';
const _JSHOP_YOO_METHOD_CASH_DESCRIPTION_PUBLIC = 'Наличные через терминалы';
const _JSHOP_YOO_METHOD_SBERBANK_DESCRIPTION_PUBLIC = 'SberPay';
const _JSHOP_YOO_METHOD_TINKOFF_BANK_DESCRIPTION_PUBLIC = 'Интернет-банк Тинькофф';
const _JSHOP_YOO_METHOD_WIDGET_DESCRIPTION_PUBLIC = 'Банковские карты';
const _JSHOP_YOO_METHOD_SBP_DESCRIPTION_PUBLIC = 'СБП';
const _JSHOP_YOO_METHOD_SBER_LOAN_DESCRIPTION_PUBLIC = '«Покупки в кредит» от СберБанка';

const _JSHOP_YOO_COMMON_HEAD = 'Дополнительные настройки для администратора';
const _JSHOP_YOO_COMMON_STATUS = 'Статус заказа после оплаты';

const _JSHOP_YOO_LICENSE = 'Лицензионный договор:';
const _JSHOP_YOO_LICENSE_TEXT2 = "<p>Любое использование Вами программы означает полное и безоговорочное принятие Вами <a href='https://yoomoney.ru/doc.xml?id=527132' target='_blank'>условий лицензионного договора</a>. Если Вы не принимаете условия Лицензионного договора в полном объёме, Вы не имеете права использовать программу в каких-либо целях.</p>";

//updater
const _JSHOP_YOO_UPDATER_ERROR_RESTORE = 'Не удалось восстановить модуль из резервной копии: ';
const _JSHOP_YOO_UPDATER_SUCCESS_MESSAGE = 'Модуль был успешно восстановлен из резервной копии: ';
const _JSHOP_YOO_UPDATER_ERROR_REMOVE = 'Не был передан удаляемый файл резервной копии';
const _JSHOP_YOO_ERROR_BACKUP_NOT_FOUND = 'Файл резервной копии %s не найден';
const _JSHOP_YOO_ERROR_REMOVE_BACKUP = 'Не удалось удалить файл резервной копии ';
const _JSHOP_YOO_SUCCESS_REMOVE_BECKUP = 'Файл резервной копии %s был успешно удалён';
const _JSHOP_YOO_SUCCESS_UPDATE_VERSION = 'Версия модуля %s (%s) была успешно загружена и установлена';
const _JSHOP_YOO_ERROR_UNPACK_NEW_VERSION = 'Не удалось распаковать загруженный архив %s, подробную информацию о произошедшей ошибке можно найти в логах модуля';
const _JSHOP_YOO_ERROR_CREATE_BACKUP = 'Не удалось создать резервную копию установленной версии модуля, подробную информацию о произошедшей ошибке можно найти в логах модуля';
const _JSHOP_YOO_ERROR_DOWNLOAD_NEW_VERSION = 'Не удалось загрузить архив с новой версией, подробную информацию о произошедшей ошибке можно найти в логах модуля';
const _JSHOP_YOO_FAILED_CREATE_DIRECTORY = 'Не удалось создать директорию ';
const _JSHOP_YOO_FAILED_DOWNLOAD_UPDATE = 'Не удалось загрузить архив с обновлением';
const _JSHOP_YOO_UPDATER_HEADER_TEXT = ' Здесь будут появляться новые версии модуля — с новыми возможностями или с исправленными ошибками. Чтобы установить новую версию модуля, нажмите кнопку «Обновить».';
const _JSHOP_YOO_UPDATER_ABOUT = 'О модуле:';
const _JSHOP_YOO_UPDATER_CURRENT_VERSION = 'Установленная версия модуля —';
const _JSHOP_YOO_UPDATER_LAST_VERSION = 'Последняя версия модуля —';
const _JSHOP_YOO_UPDATER_LAST_CHECK = 'Последняя проверка наличия новых версий —';
const _JSHOP_YOO_UPDATER_CHECK = 'Проверить наличие обновлений';
const _JSHOP_YOO_HISTORY_LABEL = 'История изменений:';
const _JSHOP_YOO_UPDATE_LABEL = 'Обновить';
const _JSHOP_YOO_INSTALL_MESSAGE = 'Установлена последняя версия модуля.';
const _JSHOP_YOO_BACKUPS_LABEL = 'Резервные копии';
const _JSHOP_YOO_MODULE_VERSION_LABEL = 'Версия модуля';
const _JSHOP_YOO_BACKUP_DATE_CREATE = 'Дата создания';
const _JSHOP_YOO_BACKUP_FILE_NAME = 'Имя файла';
const _JSHOP_YOO_BACKUP_FILE_SIZE = 'Размер файла';
const _JSHOP_YOO_UPDATER_RESTORE = 'Восстановить';
const _JSHOP_YOO_UPDATER_DELETE = 'Удалить';
const _JSHOP_YOO_UPDATER_APPROVE_ACTION_MESSAGE = 'Вы действительно хотите обновить модуль до последней версии?';
const _JSHOP_YOO_UPDATER_APPROVE_DELETE_MESSAGE = 'Вы действительно хотите удалить резервную копию';
const _JSHOP_YOO_UPDATER_APPROVE_RESTORE_MESSAGE = 'Вы действительно хотите восстановить резервную копию';
const _JSHOP_YOO_UPDATER_TEXT_HEADER = 'Обновление модуля';
const _JSHOP_YOO_UPDATER_ABOUT_TEXT = 'Здесь будут появляться новые версии модуля — с новыми возможностями или с исправленными ошибками.';
const _JSHOP_YOO_UPDATER_DISABLED_TEXT = ' К сожалению функция обновления модуля недоступна';
const _JSHOP_YOO_UPDATER_CAUSE_ZIP_CURL = 'так как для не установлены расширения <strong>"zip"</strong> и <strong>"curl"</strong>.';
const _JSHOP_YOO_UPDATER_CAUSE_ZIP = 'так как для не установлено расширение <strong>"zip"</strong>.';
const _JSHOP_YOO_UPDATER_CAUSE_CURL = 'так как для не установлено расширение <strong>"curl"</strong>.';

const _JSHOP_YOO_WAITING_FOR_CAPTURE = 'Ожидается проведение оплаты';
const _JSHOP_YOO_CAPTURE_FAILED = 'Платёж не был проведён';
const _JSHOP_YOO_PAYMENT_CAPTURED = 'Оплата была проведена';
const _JSHOP_YOO_PAYMENT_CAPTURED_TEXT = 'Платёж %s проведён';
const _JSHOP_YOO_ERROR_MESSAGE_CREATE_PAYMENT = 'Не удалось создать платёж, попробуйте выбрать другой способ оплаты.';
const _JSHOP_YOO_ENABLE = 'Включить';
const _JSHOP_YOO_DISABLE = 'Выключить';
const _JSHOP_YOO_DEFAULT_TAX_LABEL = 'Ставка по умолчанию';
const _JSHOP_YOO_DEFAULT_TAX_DESCRIPTION = 'Ставка по умолчанию будет в чеке, если в карточке товара не указана другая ставка.';
const _JSHOP_YOO_TAX_RATES_LABEL = 'Сопоставьте ставки';
const _JSHOP_YOO_TAX_IN_MODULE = 'Ставка в вашем магазине';
const _JSHOP_YOO_TAX_FOR_CHECKOUT = 'Ставка для чека в налоговую';
const _JSHOP_YOO_WITHOUT_VAT = 'Без НДС';
const _JSHOP_YOO_VAT_0 = '0%';
const _JSHOP_YOO_VAT_10 = '10%';
const _JSHOP_YOO_VAT_20 = '20%';
const _JSHOP_YOO_VAT_10_100 = 'Расчётная ставка 10/110';
const _JSHOP_YOO_VAT_20_120 = 'Расчётная ставка 20/120';

const _JSHOP_YOO_DEFAULT_TAX_SYSTEM_LABEL = 'Система налогообложения по умолчанию';
const _JSHOP_YOO_DEFAULT_TAX_SYSTEM_DESCRIPTION = 'Выберите систему налогообложения по умолчанию. Параметр необходим, только если у вас несколько систем налогообложения, в остальных случаях не передается.';
const _JSHOP_YOO_DEFAULT_TAX_SYSTEM_1_LABEL = 'Общая система налогообложения';
const _JSHOP_YOO_DEFAULT_TAX_SYSTEM_2_LABEL = 'Упрощенная (УСН, доходы)';
const _JSHOP_YOO_DEFAULT_TAX_SYSTEM_3_LABEL = 'Упрощенная (УСН, доходы минус расходы)';
const _JSHOP_YOO_DEFAULT_TAX_SYSTEM_4_LABEL = 'Единый налог на вмененный доход (ЕНВД)';
const _JSHOP_YOO_DEFAULT_TAX_SYSTEM_5_LABEL = 'Единый сельскохозяйственный налог (ЕСН)';
const _JSHOP_YOO_DEFAULT_TAX_SYSTEM_6_LABEL = 'Патентная система налогообложения';

const _JSHOP_YOO_NOTIFICATION_URL_LABEL = 'Адрес для уведомлений';
const _JSHOP_YOO_LOG_VIEW_LABEL = 'Просмотр логов модуля';
const _JSHOP_YOO_CLEAR_LOGS = 'Очистить журнал';
const _JSHOP_YOO_CLOSE = 'Закрыть';
const _JSHOP_YOO_LOGS_LABEL = 'Журнал сообщений модуля';

const _JSHOP_YOO_TAB_UPDATE = 'Обновления';

const _JSHOP_YOO_BTN_BACK = 'Назад';
const _JSHOP_REDIRECT_TO_PAYMENT_PAGE = 'Перенаправление на страницу оплаты';
const _JSHOP_PAYMENT_NUMBER = 'Номер заказа %s';
const _JSHOP_YOO_KASSA_REFUND_SUCCEDED_ORDER_HISTORY = 'Выполнен возврат. Сумма %s руб.';

const _JSHOP_YOO_AUTHORIZATION_TITLE_ERROR = 'Не получилось связать сайт с личным кабинетом';
const _JSHOP_YOO_AUTHORIZATION_TEXT_ERROR = 'Переподключите ЮKassa. Если не получилось, обратитесь в техподдержку.';
const _JSHOP_YOO_OAUTH_CONNECT_ERROR = 'Что-то пошло не так. Перезагрузите страницу и попробуйте ещё раз.';
const _JSHOP_YOO_SHOP_INSTRUCTION = 'Чтобы больше не вводить вручную shopid и секретный ключ,<br>смените магазин по кнопке.';
const _JSHOP_YOO_OAUTH_BTN_CONNECT = 'Подключить магазин';
const _JSHOP_YOO_OAUTH_BTN_RECONNECT = 'Переподключить ЮKassa';
const _JSHOP_YOO_OAUTH_BTN_CHANGE = 'Сменить магазин';

const _JSHOP_YOO_SBER_LOAN_NAME_DISCOUNT = 'Рассрочка от СберБанка';
const _JSHOP_YOO_SBER_LOAN_WARNING_TITLE = 'У вас подключен способ оплаты «Покупки в кредит» от СберБанка';
const _JSHOP_YOO_SBER_LOAN_WARNING_TEXT = 'В него входит <a href="https://yookassa.ru/developers/payment-acceptance/integration-scenarios/manual-integration/other/sber-loan#payment-method-overview-loan-options" target="_blank">кредит и рассрочка</a>. Если покупатель платит в рассрочку, в CMS может отображаться неверная сумма покупки (верная будет <a href="https://yookassa.ru/my/payments" target="_blank">в личном кабинете ЮKassa</a>). На покупателя это никак не повлияет — он всегда оплатит верную сумму.';
const _JSHOP_YOO_SBER_LOAN_WARNING_TEXT_INSTRUCTION = 'Чтобы суммы не расходились — проверьте, что ваша CMS настроена <a href="https://yookassa.ru/docs/support/payments/onboarding/integration/cms-module/joomshopping#sber" target="_blank">по этим параметрам</a>';
const _JSHOP_YOO_SBER_LOAN_CREATE_PAYMENT_ERROR = '<b>Не получается создать заказ</b><br> С этим способом оплаты заказ должен быть от 3 000 до 600 000 ₽. Добавьте другие позиции в корзину или уберите лишние — и попробуйте заплатить ещё раз.';