<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Model;

use Exception;
use YooMoney\Helpers\DatabaseHelper;
use Joomla\Component\Jshopping\Site\Table\OrderTable;

/**
 * Класс методов для работы с заказами
 */
class OrderModel extends OrderTable
{
    /** @var float|int */
    public float|int $order_total;

    /** @var float|int */
    public float|int $order_tax;

    /** @var float|int */
    public float|int $order_shipping;

    /** @var float|int */
    public float|int $order_discount;

    /** @var float|int */
    public int|float $order_subtotal;

    /** @var int */
    public int $order_created;

    /** @var string */
    public string $order_status;

    /** @var string */
    public string $order_number;

    /** @var string|null */
    public ?string $payment_params_data;

    /** @var string|null */
    public ?string $order_add_info;

    /** @var string|null */
    public ?string $currency_code_iso;

    /** @var int|null */
    public ?int $d_country;

    /** @var int|null */
    public ?int $payment_method_id;

    /** @var int|null */
    public ?int $shipping_method_id;

    /** @var string|null */
    public ?string $transaction;

    /** @var string */
    public string $email;

    /** @var int|string */
    public int|string $phone;

    /** @var DatabaseHelper */
    private DatabaseHelper $databaseHelper;

    /**
     * OrderModel конструктор.
     *
     * @param int $orderId
     */
    public function __construct(int $orderId)
    {
        $_db = \JFactory::getDbo();
        parent::__construct($_db);
        $this->load($orderId);
        $this->databaseHelper = new DatabaseHelper();
    }

    /**
     * Добавление скидки в заказ (применяется к товарам, налогам и доставке)
     * и пересчет общей стоимости заказа
     *
     * @param string $title
     * @param float $amount
     * @return OrderModel
     * @throws Exception
     */
    public function orderAddDiscount(string $title, float $amount): OrderModel
    {
        $currentOrderTotal = floatval($this->order_total);

        /** Высчитываем процент, по которому будем вычислять скидку для всех позиций в заказе */
        $percentDiscount = round(100 / ($currentOrderTotal / (int)$amount), 1);

        /** Получаем все товары, что есть в заказе */
        $products = $this->databaseHelper->getOrderItemsByOrderId((int)$this->order_id);
        if (!$products) {
            throw new Exception(sprintf('Error to get information about products in order: %s ', $this->order_id));
        }
        foreach ($products as $product) {
            /** Перерасчитываем и сохраняем стоимость товара с учетом скидки */
            $this->databaseHelper->updateOrderItemByOrderItemId(
                (int)$product->order_item_id,
                [
                    'product_item_price' => $this->calculateTotalFromPercent((float)$product->product_item_price, $percentDiscount)
                ]
            );
        }
        $orderTotalNew = $currentOrderTotal - $amount;
        $taxes = $this->getTaxExt();
        foreach ($taxes as $key => $tax) {
            /** Перерасчитываем все налоги, что применены к заказу с учетом скидки */
            $taxes[$key] = $this->calculateTotalFromPercent((float)$tax, $percentDiscount);
        }
        $this->setTaxExt($taxes);
        $this->order_tax = $this->calculateTotalFromPercent((float)$this->order_tax, $percentDiscount);
        $this->order_shipping = $this->calculateTotalFromPercent((float)$this->order_shipping, $percentDiscount);
        $this->order_discount = $amount;
        $this->order_total = $orderTotalNew;
        $this->order_subtotal = $orderTotalNew;
        $this->saveOrderHistory(false, $title . ': -' . $amount);
        $this->store();
        return $this;
    }

    /**
     * Вычисление процента из числа
     *
     * @param float $total Общая сумма
     * @param float $percent Процент, который хотим вычесть из числа
     *
     * @return float
     */
    private function calculateTotalFromPercent(float $total, float $percent): float
    {
        return $total - ($percent * ($total / 100));
    }
}