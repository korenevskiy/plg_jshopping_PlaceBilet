<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Model;

use Exception;
use pm_yoomoney;
use YooKassa\Client;
use YooKassa\Common\AbstractObject;
use YooKassa\Common\ListObjectInterface;
use YooKassa\Model\Payment\PaymentInterface;
use YooKassa\Model\Payment\PaymentStatus;
use YooKassa\Model\Receipt\PaymentMode;
use YooKassa\Model\Receipt\ReceiptCustomer;
use YooKassa\Model\Receipt\ReceiptItem;
use YooKassa\Model\Receipt\ReceiptType;
use YooKassa\Model\Receipt\Settlement;
use YooKassa\Request\Receipts\CreatePostReceiptRequest;
use YooKassa\Request\Receipts\ReceiptResponseInterface;
use YooKassa\Request\Receipts\ReceiptResponseItemInterface;

/**
 * Класс методов для работы со вторым чеком.
 */
class KassaSecondReceiptModel
{
    /** @var array|null Информация о заказе */
    private ?array $orderInfo;

    /** @var PaymentInterface Данные о платеже */
    private PaymentInterface $paymentInfo;

    /** @var string Сумма по всем позициям в чеке. */
    private string $settlementsSum;

    /** @var Client Класс клиента API */
    private Client $client;

    /**
     * KassaSecondReceiptModel constructor.
     *
     * @param PaymentInterface $paymentInfo
     * @param array $orderInfo
     * @param Client $client
     */
    public function __construct(PaymentInterface $paymentInfo, array $orderInfo, Client $client)
    {
        $this->orderInfo   = $orderInfo;
        $this->paymentInfo = $paymentInfo;
        $this->client      = $client;
    }

    /**
     * Отправляет второй чек.
     *
     * @return bool
     */
    public function sendSecondReceipt(): bool
    {
        $this->log("info", "Hook send second receipt");

        if (!$this->isPaymentInfoValid($this->paymentInfo)) {
            $this->log("error", "Invalid paymentInfo");
            return false;
        }

        if (empty($this->orderInfo['user_email']) || empty($this->orderInfo['user_phone'])) {
            $this->log("error", "Invalid orderInfo orderId = " . $this->orderInfo['order_id']);
            return false;
        }

        /** @var ReceiptResponseInterface $lastReceipt */
        $lastReceipt = $this->getLastReceipt($this->paymentInfo->getId());
        $receiptRequest = $this->buildSecondReceipt($lastReceipt, $this->paymentInfo);

        if (empty($receiptRequest)) {
            return false;
        }

        $this->log("info", "Second receipt request data: " . json_encode($receiptRequest->jsonSerialize()));

        try {
            $response = $this->client->createReceipt($receiptRequest);
        } catch (Exception $e) {
            $this->log("error", "Request second receipt error: " . $e->getMessage());
            return false;
        }

        $this->log("info", "Request second receipt result: " . json_encode($response->jsonSerialize()));
        $this->generateSettlementsAmountSum($response);
        return true;
    }

    /**
     * Возвращает сумму по всем позициям в чеке.
     *
     * @return string
     */
    public function getSettlementsSum(): string
    {
        return $this->settlementsSum;
    }

    /**
     * Формирует общую сумму по всем позициям в чеке.
     *
     * @param ReceiptResponseInterface $response Объект чека
     */
    private function generateSettlementsAmountSum(ReceiptResponseInterface $response): void
    {
        $amount = 0;

        foreach ($response->getSettlements() as $settlement) {
            $amount += $settlement->getAmount()->getIntegerValue();
        }

        $this->settlementsSum = $amount / 100.0;
    }

    /**
     * Формирует второй чек.
     *
     * @param ReceiptResponseInterface $lastReceipt Объект последнего чека
     * @param PaymentInterface $paymentInfo Информация о платеже
     *
     * @return void|CreatePostReceiptRequest
     */
    private function buildSecondReceipt(ReceiptResponseInterface $lastReceipt, PaymentInterface $paymentInfo)
    {
        if ($lastReceipt->getType() === "refund") {
            return;
        }

        $resendItems = $this->getResendItems($lastReceipt->getItems()->toArray());

        if (!count($resendItems['items'])) {
            $this->log("info", "Second receipt isn't need");
            return;
        }

        try {
            $receiptBuilder = CreatePostReceiptRequest::builder();
            $customer = $this->getReceiptCustomer($this->orderInfo);

            if (empty($customer)) {
                $this->log("error", "Need customer phone or email for second receipt");
                return;
            }

            $receiptBuilder->setObjectId($paymentInfo->getId())
                ->setType(ReceiptType::PAYMENT)
                ->setItems($resendItems['items'])
                ->setSettlements(
                    [
                        new Settlement(
                            [
                                'type' => 'prepayment',
                                'amount' => [
                                    'value' => $resendItems['amount'],
                                    'currency' => 'RUB',
                                ],
                            ]
                        ),
                    ]
                )
                ->setCustomer($customer)
                ->setSend(true);

            return $receiptBuilder->build();
        } catch (Exception $e) {
            $this->log("error", $e->getMessage() . ". Property name:" . $e->getProperty());
        }
    }

    /**
     * Флаг на валидность данных о платеже.
     *
     * @param PaymentInterface $paymentInfo Информация о платеже
     *
     * @return bool
     */
    private function isPaymentInfoValid(PaymentInterface $paymentInfo): bool
    {
        if (empty($paymentInfo)) {
            $this->log("error", "Fail send second receipt paymentInfo is null: " . print_r($paymentInfo, true));
            return false;
        }

        if ($paymentInfo->getStatus() !== PaymentStatus::SUCCEEDED) {
            $this->log("error", "Fail send second receipt payment have incorrect status: " . $paymentInfo->getStatus());
            return false;
        }

        return true;
    }

    /**
     * @param array|null $orderInfo Информация о заказе
     *
     * @return ReceiptCustomer|null
     */
    private function getReceiptCustomer(?array $orderInfo): ReceiptCustomer|null
    {
        if (empty($orderInfo)) {
            return null;
        }

        $customerData = [];

        if (!empty($orderInfo['user_email'])) {
            $customerData['email'] = $orderInfo['user_email'];
        }

        if (!empty($orderInfo['user_phone'])) {
            $customerData['phone'] = $orderInfo['user_phone'];
        }

        return new ReceiptCustomer($customerData);
    }

    /**
     * Возвращает данные о последнем чеке.
     *
     * @param string $paymentId Id платежа
     *
     * @return AbstractObject|null
     */
    private function getLastReceipt(string $paymentId): ?AbstractObject
    {
        try {
            /** @var ListObjectInterface $receipts */
            $receipts = $this->client->getReceipts([
                'payment_id' => $paymentId,
            ])->getItems();
        } catch (Exception $e) {
            $this->log("error", "Fail get receipt message", ['exception' => $e->getMessage()]);
            return null;
        }

        if ($receipts->count() === 0) {
            return null;
        }

        return $receipts->get(0);
    }

    /**
     * Обработка товаров и заполнение необходимыми данными.
     *
     * @param array $items Товары в чеке
     *
     * @return array
     */
    private function getResendItems(array $items): array
    {
        $resendItems = [
            'items'  => [],
            'amount' => 0,
        ];

        foreach ($items as $item) {
            if ($item['payment_mode'] === PaymentMode::FULL_PREPAYMENT) {
                $item['payment_mode'] = PaymentMode::FULL_PAYMENT;
                $resendItems['items'][] = new ReceiptItem($item);
                $resendItems['amount'] += $item['amount']['value'] * $item['quantity'];
            }
        }

        return $resendItems;
    }

    /**
     * Создание записи в лог.
     *
     * @param string $level
     * @param string $message
     * @param array $context
     *
     * @return void
     */
    public function log(string $level, string $message, array $context = []): void
    {
        $pm_yoomoney = new pm_yoomoney();
        $pm_yoomoney->log($level, $message, $context);
    }
}