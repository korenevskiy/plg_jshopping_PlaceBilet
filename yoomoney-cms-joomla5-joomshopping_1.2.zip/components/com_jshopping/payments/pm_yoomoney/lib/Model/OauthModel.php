<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Model;

use Exception;
use Psr\Log\LoggerInterface;
use YooMoney\Helpers\OauthHelpers\HttpClientInterface;
use YooMoney\Helpers\OauthHelpers\OauthDataStorageHelperInterface;
use YooMoney\Helpers\OauthHelpers\OauthWebhooksHelperInterface;
use YooMoney\Helpers\OauthHelpers\YookassaShopInfoHelperInterface;

/**
 * Класс для работы с oauth
 */
class OauthModel
{
    /** Путь до oauth приложения */
    public const OAUTH_CMS_PATH = '/integration/oauth-cms';

    /** Часть роута для формирования ссылки на авторизацию мерчаната в OAuth */
    public const AUTHORIZATION = 'authorization';

    /** Часть роута для получения OAuth токена */
    public const GET_TOKEN = 'get-token';

    /** Часть роута для отзыва OAuth токена */
    public const REVOKE_TOKEN = 'revoke-token';

    /** Полученный токен */
    public const ACCESS_TOKEN_KEY = 'access_token';

    /** Дата и время, до которых авторизация действительна */
    public const EXPIRES_IN_TOKEN_KEY = 'expires_in';

    /** Название CMS */
    public const CMS_NAME = 'joomla';

    /** @var LoggerInterface Класс методов для работы с логами модуля */
    private LoggerInterface $logger;

    /** @var OauthDataStorageHelperInterface Класс методов для работы с параметрами платежного метода */
    private OauthDataStorageHelperInterface $storageHelper;

    /** @var OauthWebhooksHelperInterface Класс методов для работы с oauth вебхуками */
    private OauthWebhooksHelperInterface $webhooksHelper;

    /** @var YookassaShopInfoHelperInterface Класс методов для получения информации по магазину */
    private YookassaShopInfoHelperInterface $shopInfoHelper;

    /** @var HttpClientInterface Класс методов для отправки запросов */
    private HttpClientInterface $httpClient;

    /**
     * OauthModel конструктор.
     *
     * @param LoggerInterface $logger
     * @param OauthDataStorageHelperInterface $storageHelper
     * @param OauthWebhooksHelperInterface $webhooksHelper
     * @param YookassaShopInfoHelperInterface $shopInfoHelper
     * @param HttpClientInterface $httpClient
     */
    public function __construct(
        LoggerInterface $logger,
        OauthDataStorageHelperInterface $storageHelper,
        OauthWebhooksHelperInterface $webhooksHelper,
        YookassaShopInfoHelperInterface $shopInfoHelper,
        HttpClientInterface $httpClient
    )
    {
        $this->logger = $logger;
        $this->storageHelper = $storageHelper;
        $this->webhooksHelper = $webhooksHelper;
        $this->shopInfoHelper = $shopInfoHelper;
        $this->httpClient = $httpClient;
    }

    /**
     * Формирование данных, отправка запроса на получение ссылки для авторизации
     * и получение результата запроса.
     *
     * @return array - массив для последующей кодировки в JSON для передачи в JS
     * @throws Exception
     */
    public function getOauthConnectUrl(): array
    {
        $requestParameters = [
            'state' => $this->getOauthState(),
            'cms' => self::CMS_NAME,
            'host' => $_SERVER['HTTP_HOST']
        ];

        $url = self::OAUTH_CMS_PATH . '/' . self::AUTHORIZATION;

        $this->logger->log(
            'info', 'Making a request for OAuth link: ' . $url . ' : ' . json_encode($requestParameters)
        );

        try {
            $response = $this->httpClient->sendRequest($url, $requestParameters);
        } catch (Exception $e) {
            $this->logger->log('error', 'Failed to get OAuth link', ['exception' => $e->getMessage()]);
            return ['error' => 'Got error while getting OAuth link.'];
        }

        $this->logger->log('info', 'Got response from ' . $url . ' : ' . $response);

        $responseData = json_decode($response, true);

        if (empty($responseData['oauth_url'])) {
            $error = empty($responseData['error']) ? 'OAuth URL not found' : $responseData['error'];
            $this->logger->log('error', 'Got error while getting OAuth link: ' . $error);
            throw new Exception($error);
        }

        return ['oauth_url' => $responseData['oauth_url']];
    }

    /**
     * Формирует параметры, инициирует отправку, получает результат запроса на получение токена,
     * проверяет ответ на запрос, инициирует сохранение токена в БД.
     *
     * @return array - массив для последующей кодировки в JSON для передачи в JS
     * @throws Exception
     */
    public function getOauthToken(): array
    {
        $requestParameters = [
            'state' => $this->storageHelper->getState()
        ];

        $url = self::OAUTH_CMS_PATH . '/' . self::GET_TOKEN;

        $this->logger->log(
            'info', 'Making a request for OAuth token: ' . $url . ' : ' . json_encode($requestParameters)
        );

        try {
            $response = $this->httpClient->sendRequest($url, $requestParameters);
        } catch (Exception $e) {
            $this->logger->log('error', 'Failed to get OAuth token', ['exception' => $e->getMessage()]);
            throw new Exception('Got error while getting OAuth token.');
        }

        $this->logger->log('info', 'Got response from ' . $url . ' : ' . $response);

        $responseData = json_decode($response, true);

        if (empty($responseData[self::ACCESS_TOKEN_KEY])) {
            $error = empty($data['error']) ? 'OAuth token not found' : $data['error'];
            $this->logger->log('error', 'Got error while getting OAuth token: ' . $error);
            throw new Exception($error);
        }

        $expiresIn = empty($responseData[self::EXPIRES_IN_TOKEN_KEY]) ? null : $responseData[self::EXPIRES_IN_TOKEN_KEY];

        $this->revokeOldToken();

        if (!$this->storageHelper->saveToken($responseData[self::ACCESS_TOKEN_KEY], $expiresIn)) {
            $error = 'OAuth token was not saved!';
            $this->logger->log('error', $error);
            throw new Exception($error);
        }
        $this->logger->log('info', 'OAuth token saved successfully');

        try {
            $notificationUrl = $this->webhooksHelper->getNotificationUrl();
            $this->webhooksHelper->addWebhooksWithGivenToken($responseData[self::ACCESS_TOKEN_KEY], $notificationUrl);
        } catch (Exception $e) {
            $this->logger->log('error', 'Failed to make webhooks', ['exception' => $e->getMessage()]);
            throw new Exception('Failed to make webhooks');
        }

        try {
            $shopId = $this->shopInfoHelper->fetchShopIdWithGivenToken($responseData[self::ACCESS_TOKEN_KEY]);
        } catch (Exception $e) {
            $this->logger->log('error', $e->getMessage());
            throw new Exception('Got error while getting shop info! ' . $e->getMessage());
        }

        if (!$this->storageHelper->saveShopId($shopId)) {
            $error = 'Shop Id was not saved!';
            $this->logger->log('error', $error);
            throw new Exception($error);
        }
        $this->logger->log('info', 'Shop Id saved successfully');

        return ['success' => true];
    }

    /**
     * Проверяет в БД state и возвращает его, если нет в БД, генерирует его.
     *
     * @return string
     */
    public function getOauthState(): string
    {
        $state = $this->storageHelper->getState();

        if (!$state) {
            $state = substr(md5(time()), 0, 12);
            $this->storageHelper->saveState($state);
        }

        return $state;
    }

    /**
     * Выполняет запрос в OAuth приложение на отзыв токена.
     *
     * @return void
     */
    public function revokeOldToken(): void
    {
        $token = $this->storageHelper->getToken();
        if (!$token) {
            $this->logger->log('info', 'Old token not found. Skip revoking.');
            return;
        }

        try {
            $this->webhooksHelper->removeWebhooksWithGivenToken($token);
        } catch (Exception $e) {
            $this->logger->log('error', 'Got error while deleting webhooks', ['exception' => $e->getMessage()]);
            return;
        }

        $requestParameters = [
            'state' => $this->storageHelper->getState(),
            'token' => $token,
            'cms' => self::CMS_NAME
        ];

        $url = self::OAUTH_CMS_PATH . '/' . self::REVOKE_TOKEN;

        $this->logger->log('info', 'Sending request to revoke OAuth token. ' . $url . ' : ' . json_encode($requestParameters));

        try {
            $result = $this->httpClient->sendRequest($url, $requestParameters);
        } catch (Exception $e) {
            $this->logger->log('error', 'Got error while revoking OAuth token', ['exception' => $e->getMessage()]);
            return;
        }

        $this->logger->log('info', 'Response from ' . $url . ' : ' . $result);

        $body = json_decode($result, true);

        if (!empty($body['error'])) {
            $this->logger->log('error', 'Got error while revoking OAuth token.');
            return;
        }
        $this->logger->log('info', 'Token ' . $token . ' revoked successfully!');
    }
}