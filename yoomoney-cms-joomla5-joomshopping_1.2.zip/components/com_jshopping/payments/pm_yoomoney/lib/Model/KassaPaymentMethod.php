<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Model;

use Exception;
use pm_yoomoney;
use pm_yoomoney_sbbol;
use YooKassa\Client;
use YooKassa\Model\CurrencyCode;
use YooKassa\Model\Payment\ConfirmationType;
use YooKassa\Model\Payment\Payment;
use YooKassa\Model\Payment\PaymentInterface;
use YooKassa\Model\Payment\PaymentMethod\B2b\Sberbank\VatDataFactory;
use YooKassa\Model\Payment\PaymentMethod\B2b\Sberbank\VatDataType;
use YooKassa\Model\Payment\PaymentMethodType;
use YooKassa\Request\Payments\AbstractPaymentRequestBuilder;
use YooKassa\Request\Payments\CreateCaptureRequest;
use YooKassa\Request\Payments\CreatePaymentRequest;
use YooKassa\Request\Payments\CreatePaymentResponse;
use YooKassa\Request\Payments\PaymentData\PaymentDataB2bSberbank;
use YooKassa\Request\Refunds\RefundResponse;
use YooMoney\Helpers\LoggerHelper;
use YooMoney\Helpers\YookassaClientFactory;
use YooMoney\Helpers\OauthHelpers\OauthWebhooksHelper;
use YooMoney\Helpers\OauthHelpers\YookassaShopInfoHelper;
use Joomla\Component\Jshopping\Site\Model\CartModel;
use Joomla\Component\Jshopping\Site\Table\PaymentMethodTable;

require_once JPATH_ROOT . '/components/com_jshopping/payments/pm_yoomoney_sbbol/SbbolException.php';

/**
 * Класс методов для оплаты через ЮКассу.
 */
class KassaPaymentMethod
{
    /** Метод оплаты виджет */
    public const PAYMENT_METHOD_WIDGET = 'widget';

    /** @var pm_yoomoney|pm_yoomoney_sbbol Модуль оплаты ЮМани или ЮКасса СББОЛ */
    private pm_yoomoney|pm_yoomoney_sbbol $module;

    /** @var string|int Ставка по умолчанию */
    private string|int $defaultTaxRate;

    /** @var int Система налогообложения по умолчанию */
    private int $defaultTaxSystemCode;

    /** @var array Массив ставок для чека в налоговую */
    private array $taxRates;

    /** @var string Описание платежа */
    private string $descriptionTemplate;

    /** @var array|null Массив настроек модуля оплаты */
    private ?array $pmconfigs = [];

    /** @var string Признак способа расчета */
    private string $defaultPaymentMode;

    /** @var string Признак предмета расчета */
    private string $defaultPaymentSubject;

    /** @var string Признак способа расчета для доставки */
    private string $defaultDeliveryPaymentMode;

    /** @var string Признак предмета расчета для доставки */
    private string $defaultDeliveryPaymentSubject;

    /** Признак тестового магазина полученный из данных по магазину */
    public const SHOP_INFO_TEST = 'test';

    /** Флаг включенной фискализации полученный из данных по магазину */
    public const SHOP_INFO_FISCALIZATION_ENABLED = 'fiscalization_enabled';

    /** Список способов оплаты, доступных магазину */
    public const SHOP_INFO_PAYMENT_METHODS = 'payment_methods';

    /**
     * KassaPaymentMethod конструктор.
     *
     * @param pm_yoomoney_sbbol|pm_yoomoney $module
     * @param array|null $pmConfig
     */
    public function __construct(pm_yoomoney_sbbol|pm_yoomoney $module, ?array $pmConfig = [])
    {
        $this->pmconfigs           = $pmConfig;
        $this->module              = $module;

        //yookassa
        if ($module instanceof pm_yoomoney) {
            $this->descriptionTemplate = !empty($pmConfig['yookassa_description_template'])
                ? $pmConfig['yookassa_description_template']
                : _JSHOP_YOO_DESCRIPTION_DEFAULT_PLACEHOLDER;

            $this->defaultTaxRate = 1;

            if (!empty($pmConfig['yookassa_default_tax'])) {
                $this->defaultTaxRate = $pmConfig['yookassa_default_tax'];
            }

            if (!empty($pmConfig['yookassa_default_tax_system'])) {
                $this->defaultTaxSystemCode = $pmConfig['yookassa_default_tax_system'];
            }

            if (!empty($pmConfig['yookassa_default_payment_mode'])) {
                $this->defaultPaymentMode = $pmConfig['yookassa_default_payment_mode'];
            }

            if (!empty($pmConfig['yookassa_default_payment_subject'])) {
                $this->defaultPaymentSubject = $pmConfig['yookassa_default_payment_subject'];
            }

            if (!empty($pmConfig['yookassa_default_delivery_payment_mode'])) {
                $this->defaultDeliveryPaymentMode = $pmConfig['yookassa_default_delivery_payment_mode'];
            }

            if (!empty($pmConfig['yookassa_default_delivery_payment_subject'])) {
                $this->defaultDeliveryPaymentSubject = $pmConfig['yookassa_default_delivery_payment_subject'];
            }

            if ($this->pmconfigs) {
                $this->taxRates = [];
                foreach ($pmConfig as $key => $value) {
                    if (strncmp('yookassa_tax_', $key, 13) === 0) {
                        $taxRateId = substr($key, 13);
                        $this->taxRates[$taxRateId] = $value;
                    }
                }
            }
            return;
        }

        //sbbol
        $this->descriptionTemplate = !empty($pmConfig['sbbol_purpose'])
            ? $pmConfig['sbbol_purpose']
            : _JSHOP_YOO_SBBOL_DESCRIPTION_DEFAULT_PLACEHOLDER;

        $this->defaultTaxRate = VatDataType::UNTAXED;

        if (isset($pmConfig['sbbol_default_tax'])) {
            $this->defaultTaxRate = $pmConfig['sbbol_default_tax'];
        }

        if ($this->pmconfigs) {
            $this->taxRates = [];
            foreach ($pmConfig as $key => $value) {
                if (strncmp('sbbol_tax_', $key, 10) === 0) {
                    $taxRateId = substr($key, 10);
                    $this->taxRates[$taxRateId] = $value;
                }
            }
        }
    }

    /**
     * Возвращает shop_id.
     *
     * @return string|null
     */
    public function getShopId(): ?string
    {
        return $this->pmconfigs['shop_id'] ?? null;
    }

    /**
     * Возвращает sbbol_shop_id.
     *
     * @return string|null
     */
    public function getSbbolShopId(): ?string
    {
        return $this->pmconfigs['sbbol_shop_id'] ?? null;
    }

    /**
     * Устанавливает shop_id.
     *
     * @param string $shopId
     *
     * @return void
     */
    public function setShopId(string $shopId): void
    {
        $this->pmconfigs['shop_id'] = $shopId;
    }

    /**
     * Возвращает shop_password.
     *
     * @return string|null
     */
    public function getPassword(): ?string
    {
        return $this->pmconfigs['shop_password'] ?? null;
    }

    /**
     * Возвращает sbbol_shop_password.
     *
     * @return string|null
     */
    public function getSbbolPassword(): ?string
    {
        return $this->pmconfigs['sbbol_shop_password'] ?? null;
    }

    /**
     * Возвращает access_token.
     *
     * @return string|null
     */
    public function getOauthToken(): ?string
    {
        return $this->pmconfigs['access_token'] ?? null;
    }

    /**
     * Устанавливает данные по oauth авторизации access_token и expires_in.
     *
     * @param string $token
     * @param int|null $expiresIn
     *
     * @return void
     */
    public function setOauthToken(string $token, int $expiresIn = null): void
    {
        $this->pmconfigs['access_token'] = $token;
        if ($expiresIn) {
            $this->pmconfigs['expires_in'] = $expiresIn;
        }
    }

    /**
     * Возвращает kassamode.
     *
     * @return string|null
     */
    public function getKassaMode(): ?string
    {
        return $this->pmconfigs['kassamode'] ?? null;
    }

    /**
     * Флаг на тестовый магазин.
     *
     * @return bool
     */
    public function isTest(): bool
    {
        return $this->pmconfigs['isTest'] ?? true;
    }

    /**
     * Флаг на включенность фискализации в магазине.
     *
     * @return bool
     */
    public function isFiscalizationEnabled(): bool
    {
        return $this->pmconfigs['isFiscalizationEnabled'] ?? false;
    }

    /**
     * Флаг доступность метода "Покупки в кредит от Сбера" в магазине
     *
     * @return bool
     */
    public function isSberLoanAvailable(): bool
    {
        return $this->pmconfigs['isSberLoanAvailable'] ?? false;
    }

    /**
     * Флаг на корректность подключения к Апи Кассы.
     *
     * @return bool
     */
    public function isConnectFailed(): bool
    {
        return $this->pmconfigs['isConnectFailed'] ?? true;
    }

    /**
     * Возвращает state.
     *
     * @return string|null
     */
    public function getState(): ?string
    {
        return $this->pmconfigs['state'] ?? null;
    }

    /**
     * Устанавливает state.
     *
     * @param string $state
     *
     * @return void
     */
    public function setState(string $state): void
    {
        $this->pmconfigs['state'] = $state;
    }

    /**
     * Возвращает notification_url.
     *
     * @return string|null
     */
    public function getNotificationUrl(): ?string
    {
        return $this->pmconfigs['notification_url'] ?? null;
    }

    /**
     * Возвращает модель для работы с платежами.
     *
     * @return PaymentMethodTable|null
     */
    public function getPaymentMethodModule(): ?PaymentMethodTable
    {
        return $this->module->pm_method;
    }

    /**
     * Возвращает модуль оплаты ЮМани или ЮКасса СББОЛ.
     *
     * @return pm_yoomoney|pm_yoomoney_sbbol
     */
    public function getModule(): pm_yoomoney_sbbol|pm_yoomoney
    {
        return $this->module;
    }

    /**
     * Возвращает настройки модуля оплаты.
     *
     * @return array
     */
    public function getParams(): array
    {
        return $this->pmconfigs;
    }

    /**
     * Создание платежа через модуль ЮМани.
     *
     * @param OrderModel $order Модель заказа
     * @param CartModel $cart Модель корзины
     * @param string $returnUrl URL, на который вернется пользователь после подтверждения или отмены платежа на веб-странице
     *
     * @return CreatePaymentResponse|null
     *
     * @throws Exception
     */
    public function createPayment(OrderModel $order, CartModel $cart, string $returnUrl): ?CreatePaymentResponse
    {
        try {
            $params  = unserialize($order->payment_params_data);
            $builder = CreatePaymentRequest::builder();
            $builder->setAmount($order->order_total)
                    ->setCapture($this->getCaptureValue($params['payment_type']))
                    ->setClientIp($_SERVER['REMOTE_ADDR'])
                    ->setDescription($this->createDescription($order))
                    ->setMetadata([
                        'order_id'       => $order->order_id,
                        'cms_name'       => 'yoo_api_joomla5_joomshopping',
                        'module_version' => pm_yoomoney::_JSHOP_YOO_VERSION,
                    ]);

            $confirmation = [
                'type'      => ConfirmationType::REDIRECT,
                'returnUrl' => $returnUrl,
            ];
            if (!empty($params['payment_type'])) {
                $paymentType = $params['payment_type'];
                if ($paymentType === self::PAYMENT_METHOD_WIDGET) {
                    $confirmation['type'] = ConfirmationType::EMBEDDED;
                }

                if ($paymentType !== self::PAYMENT_METHOD_WIDGET) {
                    $builder->setPaymentMethodData($paymentType);
                }
            }

            $builder->setConfirmation($confirmation);

            if (count($cart->products) && $this->isSendReceipt()) {
                $this->factoryReceipt($builder, $cart->products, $order);
            }

            $request = $builder->build();
            if ($request->hasReceipt()) {
                $request->getReceipt()->normalize($request->getAmount());
            }
        } catch (Exception $e) {
            $this->module->log('error', 'Failed to build request', ['exception' => $e->getMessage()]);

            return null;
        }

        try {
            $payment = $this->getClient()->createPayment($request);
        } catch (Exception $e) {
            $this->module->log('error', 'Failed to create payment', ['exception' => $e->getMessage()]);
            throw $e;
        }

        return $payment;
    }


    /**
     * Создание платежа через модуль ЮКасса СББОЛ.
     *
     * @param OrderModel $order Модель заказа
     * @param CartModel $cart Модель корзины
     * @param string $returnUrl URL, на который вернется пользователь после подтверждения или отмены платежа на веб-странице
     *
     * @return CreatePaymentResponse|null
     * @throws SbbolException
     */
    public function createSbbolPayment(OrderModel $order, CartModel $cart, string $returnUrl): ?CreatePaymentResponse
    {
        try {
            $pmconfigs = $this->pmconfigs;
            $builder   = CreatePaymentRequest::builder();
            $builder->setAmount($order->order_total)
                    ->setCapture(true)
                    ->setClientIp($_SERVER['REMOTE_ADDR'])
                    ->setDescription($this->createDescription($order))
                    ->setMetadata([
                        'order_id'       => $order->order_id,
                        'cms_name'       => 'yoo_api_joomla5_joomshopping',
                        'module_version' => pm_yoomoney_sbbol::_JSHOP_YOO_VERSION,
                    ]);

            $confirmation = [
                'type'      => ConfirmationType::REDIRECT,
                'returnUrl' => $returnUrl,
            ];

            $usedTaxes = [];
            if (count($cart->products)) {
                foreach ($cart->products as $product) {
                    if (isset($pmconfigs['sbbol_tax_'.$product['tax_id']])) {
                        $usedTaxes[] = $pmconfigs['sbbol_tax_'.$product['tax_id']];
                    } else {
                        $usedTaxes[] = $pmconfigs['sbbol_default_tax'];
                    }
                }
            }

            $usedTaxes = array_unique($usedTaxes);
            if (count($usedTaxes) !== 1) {
                throw new SbbolException();
            }

            $paymentMethodData = new PaymentDataB2bSberbank();
            $vatType           = reset($usedTaxes);
            if ($vatType !== VatDataType::UNTAXED) {
                $vatData = [
                    'type' => VatDataType::CALCULATED,
                    'rate' => $vatType,
                    'amount' => [
                        'value' => $order->order_total * $vatType / 100,
                        'currency' => CurrencyCode::RUB
                    ]
                ];
            } else {
                $vatData = ['type' => VatDataType::UNTAXED];
            }
            $vatData   = (new VatDataFactory())->factoryFromArray($vatData);
            $orderData = json_decode(json_encode($order), true);
            foreach ($orderData as $key => $value) {
                $orderData["%{$key}%"] = $value;
                unset($orderData[$key]);
            }

            $paymentPurpose = strtr($pmconfigs['sbbol_purpose'], $orderData);

            $paymentMethodData->setVatData($vatData);
            $paymentMethodData->setPaymentPurpose($paymentPurpose);
            $builder->setConfirmation($confirmation);
            $builder->setPaymentMethodData($paymentMethodData);
            $request = $builder->build();
        } catch (SbbolException $e) {
            throw $e;
        } catch (Exception $e) {
            $this->module->log('error', 'Failed to build request', ['exception' => $e->getMessage()]);

            return null;
        }

        try {
            $payment = $this->getClient()->createPayment($request);
        } catch (Exception $e) {
            $this->module->log('error', 'Failed to create payment', ['exception' => $e->getMessage()]);
            throw $e;
        }

        return $payment;
    }

    /**
     * Создание подтверждение оплаты.
     *
     * @param PaymentInterface $payment Модель платежа
     *
     * @return PaymentInterface|null
     */
    public function capturePayment(PaymentInterface $payment): ?PaymentInterface
    {
        try {
            $builder = CreateCaptureRequest::builder();
            $builder->setAmount($payment->getAmount());
            $request  = $builder->build();
            $response = $this->getClient()->capturePayment($request, $payment->getId());
        } catch (Exception $e) {
            $this->module->log('error', 'Failed to create capture payment', ['exception' => $e->getMessage()]);

            return null;
        }

        return $response;
    }

    /**
     * Получает по API Юkassa информации о платеже.
     *
     * @param string $paymentId Id платежа.
     *
     * @return PaymentInterface|null
     */
    public function fetchPayment(string $paymentId): ?PaymentInterface
    {
        $payment = null;
        try {
            $payment = $this->getClient()->getPaymentInfo($paymentId);
        } catch (Exception $e) {
            $this->module->log('error', 'Failed to fetch payment information from API', ['exception' => $e->getMessage()]);
        }

        return $payment;
    }

    /**
     * Получает по API Юkassa объект возврата по переданному id.
     *
     * @param string $refundId Id возврата
     *
     * @return RefundResponse|null
     */
    public function fetchRefund(string $refundId): ?RefundResponse
    {
        $refund = null;
        try {
            $refund = $this->getClient()->getRefundInfo($refundId);
        } catch (Exception $e) {
            $this->module->log('error', 'Failed to fetch refund information from API', ['exception' => $e->getMessage()]);
        }

        return $refund;
    }

    /**
     * Создание чека.
     *
     * @param AbstractPaymentRequestBuilder $builder Объект платежного запроса
     * @param array $products Массив товаров
     * @param OrderModel $order Модуль заказа
     *
     * @return void
     */
    public function factoryReceipt(
        AbstractPaymentRequestBuilder $builder,
        array $products,
        OrderModel $order
    ): void
    {
        $shippingModel   = \JSFactory::getTable('shippingMethod', 'jshop');
        $shippingMethods = $shippingModel->getAllShippingMethodsCountry($order->d_country, $order->payment_method_id);
        $defaultTaxRate  = $this->defaultTaxRate;
        if (!empty($order->email)) {
            $builder->setReceiptEmail($order->email);
        }
        if (!empty($order->phone)) {
            $builder->setReceiptPhone(preg_replace('/\D/', '', $order->phone));
        }
        $shipping = false;
        foreach ($shippingMethods as $tmp) {
            if ($tmp->shipping_id == $order->shipping_method_id) {
                $shipping = $tmp;
                break;
            }
        }

        $moduleTaxes = \JSFactory::getModel("taxes");
        $allTaxes    = $moduleTaxes ? $moduleTaxes->getAllTaxes() : array();
        foreach ($products as $product) {
            if (is_array($product)) {
                if (isset($product['tax_id']) && !empty($this->taxRates[$product['tax_id']])) {
                    $taxId = $this->taxRates[$product['tax_id']];
                } else {
                    $taxId = $defaultTaxRate;
                }
                $builder->addReceiptItem($product['product_name'], $product['price'], $product['quantity'], $taxId,
                    $this->defaultPaymentMode, $this->defaultPaymentSubject);
            } elseif (is_object($product)) {
                $taxId         = $defaultTaxRate;
                $suitableTaxes = array_filter($allTaxes, function ($tax) use ($product) {
                    return $product->product_tax == $tax->tax_value;
                });
                if (!empty($suitableTaxes)) {
                    $suitableTax = reset($suitableTaxes);
                    if (!empty($this->taxRates[$suitableTax->tax_id])) {
                        $taxId = $this->taxRates[$suitableTax->tax_id];
                    }
                }
                $builder->addReceiptItem($product->product_name, $product->product_item_price,
                    $product->product_quantity, $taxId, $this->defaultPaymentMode, $this->defaultPaymentSubject);
            }
        }

        if ($order->shipping_method_id && $shipping) {
            $shippingPrice = $order->order_shipping;
            if (!empty($this->taxRates[$shipping->shipping_tax_id])) {
                $taxId = $this->taxRates[$shipping->shipping_tax_id];
                $builder->addReceiptShipping($shipping->name, $shippingPrice, $taxId,
                    $this->defaultDeliveryPaymentMode, $this->defaultDeliveryPaymentSubject);
            } else {
                $builder->addReceiptShipping($shipping->name, $shippingPrice, $defaultTaxRate,
                    $this->defaultDeliveryPaymentMode, $this->defaultDeliveryPaymentSubject);
            }
        }

        if (!empty($this->defaultTaxSystemCode)) {
            $builder->setTaxSystemCode($this->defaultTaxSystemCode);
        }
    }

    /**
     * Возвращает клиента API.
     *
     * @return Client
     */
    public function getClient(): Client
    {
        return $this->getYookassaClientFactory()->getClient();
    }

    /**
     * Создает описание к платежу.
     *
     * @param OrderModel $order Модуль заказа
     *
     * @return string
     */
    private function createDescription(OrderModel $order): string
    {
        $descriptionTemplate = $this->descriptionTemplate;

        $replace = [];
        foreach ($order as $property => $value) {
            $replace['%'.$property.'%'] = $value;
        }

        $description = strtr($descriptionTemplate, $replace);

        return mb_substr($description, 0, Payment::MAX_LENGTH_DESCRIPTION);
    }

    /**
     * Флаг на включенность отложенной оплаты.
     *
     * @return bool
     */
    public function isEnableHoldMode(): bool
    {
        return isset($this->pmconfigs['yookassa_enable_hold_mode']) && $this->pmconfigs['yookassa_enable_hold_mode'] == '1';
    }

    /**
     * Возвращает значение на автоматическое принятия поступившей оплаты.
     *
     * @param string $paymentMethod Название метода оплаты
     *
     * @return bool
     */
    private function getCaptureValue(string $paymentMethod): bool
    {
        if (!$this->isEnableHoldMode()) {
            return true;
        }

        return !in_array($paymentMethod,
            [
                '',
                PaymentMethodType::BANK_CARD,
                PaymentMethodType::YOO_MONEY,
                PaymentMethodType::SBER_LOAN,
            ]
        );
    }

    /**
     * Флаг на включенность фискализации.
     *
     * @return bool
     */
    public function isSendReceipt(): bool
    {
        return isset($this->pmconfigs['yookassa_send_check']) && $this->pmconfigs['yookassa_send_check'] == '1';
    }

    /**
     * Флаг на включенность отправки второго чека.
     *
     * @return bool
     */
    public function isSendSecondReceipt(): bool
    {
        return isset($this->pmconfigs['send_second_receipt']) && $this->pmconfigs['send_second_receipt'] == '1';
    }

    /**
     * Возвращает статус заказа, при котором будет происходить отправка второго чека.
     *
     * @return string
     */
    public function getSecondReceiptStatus(): string
    {
        return $this->pmconfigs['kassa_second_receipt_status'];
    }

    /**
     * Запрос информации о магазине и его установленных вебхуках.
     *
     * @return void
     * @throws Exception
     */
    public function setShopAndWebhooksInfo(): void
    {
        if (!$this->getKassaMode()) {
            return;
        }

        if ($this->isAuthorization()) {
            $this->setShopInfo($this->getShopInfo());
        }

        if ($this->isOauthAuthorization() && !$this->isConnectFailed()) {
            $this->checkWebhooks();
        }
    }

    /**
     * Проверка на наличие вебхуков.
     *
     * @return void
     * @throws Exception
     */
    public function checkWebhooks(): void
    {
        $webhookHelper = $this->getOauthWebhooksHelper();
        $this->pmconfigs['notification_url'] = $webhookHelper->getCurrentWebhookUrl();

        if (!$webhookHelper->checkWebhooks() || !$this->getNotificationUrl()) {
            $this->pmconfigs['isConnectFailed'] = true;
        }
    }

    /**
     * Устанавливает настройки магазина из пришедших по Апи данных.
     *
     * @param array|null $shopInfo Массив с информацией о магазине
     * @return void
     */
    private function setShopInfo(?array $shopInfo = []): void
    {
        $this->pmconfigs['isTest'] = true;
        $this->pmconfigs['isFiscalizationEnabled'] = false;
        $this->pmconfigs['isSberLoanAvailable'] = false;

        if ($shopInfo) {
            $this->pmconfigs['isTest'] = isset($shopInfo[self::SHOP_INFO_TEST]) && $shopInfo[self::SHOP_INFO_TEST];
            $this->pmconfigs['isFiscalizationEnabled'] = isset($shopInfo[self::SHOP_INFO_FISCALIZATION_ENABLED]) && $shopInfo[self::SHOP_INFO_FISCALIZATION_ENABLED];
            $this->pmconfigs['isSberLoanAvailable'] = isset($shopInfo[self::SHOP_INFO_PAYMENT_METHODS]) && in_array(PaymentMethodType::SBER_LOAN, $shopInfo[self::SHOP_INFO_PAYMENT_METHODS]);
        }
    }

    /**
     * Проверка на подключение и получение информации о магазине.
     *
     * @return array
     * @throws Exception
     */
    public function getShopInfo(): array
    {
        $this->pmconfigs['isConnectFailed'] = false;

        try {
            $shopInfo = $this->getYookassaShopInfoHelper()->fetchShopInfo();
        } catch (Exception $e) {
            $this->module->log('error', 'Failed to fetch shop info', ['exception' => $e->getMessage()]);
            $this->pmconfigs['isConnectFailed'] = true;
            return [];
        }

        return $shopInfo;
    }

    /**
     * Возвращает класс для работы с oauth вебхуками.
     *
     * @return OauthWebhooksHelper
     */
    private function getOauthWebhooksHelper(): OauthWebhooksHelper
    {
        return new OauthWebhooksHelper(new LoggerHelper(), $this->getYookassaClientFactory());
    }

    /**
     * Возвращает класс для получения информации о магазине.
     *
     * @return YookassaShopInfoHelper
     */
    private function getYookassaShopInfoHelper(): YookassaShopInfoHelper
    {
        return new YookassaShopInfoHelper($this->getYookassaClientFactory());
    }

    /**
     * Возвращает экземпляр клиента API Юkassa.
     *
     * @return YookassaClientFactory
     */
    private function getYookassaClientFactory(): YookassaClientFactory
    {
        return new YookassaClientFactory(new LoggerHelper(), $this);
    }

    /**
     * Проверка на авторизацию по oauth.
     *
     * @return bool
     */
    public function isOauthAuthorization(): bool
    {
        return $this->getShopId() && $this->getOauthToken();
    }

    /**
     * Проверка, пройдена ли авторизация.
     *
     * @return bool
     */
    public function isAuthorization(): bool
    {
        return $this->isOauthAuthorization();
    }
}
