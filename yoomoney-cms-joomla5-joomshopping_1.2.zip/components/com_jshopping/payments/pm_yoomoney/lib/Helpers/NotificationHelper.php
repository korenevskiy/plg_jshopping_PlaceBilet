<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Helpers;

use Exception;
use YooKassa\Model\Notification\AbstractNotification;
use YooKassa\Model\Notification\NotificationEventType;
use YooKassa\Model\Payment\PaymentInterface;
use YooKassa\Model\Payment\PaymentMethod\AbstractPaymentMethod;
use YooKassa\Model\Payment\PaymentMethod\PaymentMethodSberLoan;
use YooKassa\Model\Payment\PaymentMethodType;
use YooKassa\Model\Payment\PaymentStatus;
use YooKassa\Model\Refund\Refund;
use YooKassa\Model\Refund\RefundStatus;
use YooMoney\Model\KassaPaymentMethod;
use YooMoney\Model\OrderModel;
use YooMoney\Updater\Tables\TableChecker;

/**
 * Класс методов для работы для обработки входящих уведомлений от Юkassa
 */
class NotificationHelper
{
    /** Id статуса заказа "Отменен" в системе JoomShopping */
    public const CANCELED_STATUS_ID = 3;

    /** Id статуса заказа "Возвращен" в системе JoomShopping */
    public const REFUNDED_STATUS_ID = 4;

    /** @var LoggerHelper Класс методов для работы с логами модуля */
    private LoggerHelper $logger;

    /** @var ReceiptHelper Класс методов для работы с чеками */
    private ReceiptHelper $receiptHelper;

    /** @var YookassaNotificationFactory Класс-фабрика для получения объекта уведомления от Юkassa */
    private YookassaNotificationFactory $yooNotificationHelper;

    /** @var DatabaseHelper Класс методов для запросов в БД */
    private DatabaseHelper $databaseHelper;

    /**
     * Конструктор NotificationHelper.
     */
    public function __construct()
    {
        $this->logger = new LoggerHelper();
        $this->yooNotificationHelper = new YookassaNotificationFactory();
        $this->receiptHelper = new ReceiptHelper();
        $this->databaseHelper = new DatabaseHelper();
    }

    /**
     * Обрабатывает уведомление от Юkassa в зависимости от статуса платежа в уведомлении.
     *
     * @param KassaPaymentMethod $kassa Класс методов для оплаты через ЮКассу
     * @param array $pmConfigs Настройки модуля оплаты
     * @param OrderModel $order Модель заказа
     *
     * @return bool|void
     * @throws Exception
     */
    public function processNotification(KassaPaymentMethod $kassa, array $pmConfigs, OrderModel $order)
    {
        $notificationObj = $this->yooNotificationHelper->getNotificationObject();
        $paymentId = $notificationObj->getObject()->getId();

        $refund = null;
        if ($notificationObj->getEvent() === NotificationEventType::REFUND_SUCCEEDED) {
            $refundId = $notificationObj->getObject()->getId();
            $refund = $kassa->fetchRefund($refundId);

            if (!$refund) {
                $this->logger->log('debug', 'Notification error: refund is not exist');
                header('HTTP/1.1 404 Refund is not exist');
                die();
            }
            $paymentId = $refund->getPaymentId();
        }

        $payment = $kassa->fetchPayment($paymentId);
        if (!$payment) {
            $this->logger->log('debug', 'Notification error: payment is not exist');
            header('HTTP/1.1 404 Payment not exists');
            die();
        }

        if (
            $notificationObj->getEvent() === NotificationEventType::PAYMENT_SUCCEEDED
            && $payment->getStatus() === PaymentStatus::SUCCEEDED
        ) {
            $this->processSucceedNotification($pmConfigs, $order, $payment, $kassa);
            return true;
        }

        if (
            $notificationObj->getEvent() === NotificationEventType::PAYMENT_WAITING_FOR_CAPTURE
            && $payment->getStatus() === PaymentStatus::WAITING_FOR_CAPTURE
        ) {
            $this->processWaitingForCaptureNtfctn($pmConfigs, $order, $payment, $kassa, $notificationObj);
            return true;
        }

        if (
            $notificationObj->getEvent() === NotificationEventType::PAYMENT_CANCELED
            && $payment->getStatus() === PaymentStatus::CANCELED
            && $kassa->isEnableHoldMode()
        ) {
            $this->processCanceledHoldPaymentNtfctn($pmConfigs, $order, $payment);
            return true;
        }

        if (
            $notificationObj->getEvent() === NotificationEventType::PAYMENT_CANCELED
            && $payment->getStatus() === PaymentStatus::CANCELED
            && !$kassa->isEnableHoldMode()
        ) {
            $this->logger->log('info', 'Canceled payment ' . $payment->getId());
            $this->processCanceledPaymentNtfctn($order, $payment);
            return true;
        }

        if (
            $notificationObj->getEvent() === NotificationEventType::REFUND_SUCCEEDED
            && $payment->getStatus() === PaymentStatus::SUCCEEDED
            && $refund->getStatus() == RefundStatus::SUCCEEDED
            && !$this->isRefundAlreadyGot($refund->getId())
        ) {
            $this->logger->log(
                'info', 'Refund payment ' . $payment->getId() . '. Refund ID ' . $refund->getId()
            );
            $this->processRefundNtfctn($order, $refund);
            return true;
        }

        if (
            $notificationObj->getEvent() === NotificationEventType::DEAL_CLOSED
            || $notificationObj->getEvent() === NotificationEventType::PAYOUT_CANCELED
            || $notificationObj->getEvent() === NotificationEventType::PAYOUT_SUCCEEDED
        ) {
            return true;
        }

        return false;
    }

    /**
     * Проверяет в БД было ли уже получено уведомление о возврате с таким id.
     *
     * @param string|null $refundId Id возврата
     *
     * @return bool
     */
    private function isRefundAlreadyGot(?string $refundId): bool
    {
        if ($refundId) {
            return false;
        }

        try {
            $refund = $this->databaseHelper->getRefundById($refundId);
        } catch (Exception $e) {
            $this->logger->log('debug', 'Failed to read a refund from DB: ' . $e->getMessage());
        }

        return !empty($refund);
    }

    /**
     * Выполняет действия, если получено уведомление о статусе payment.succeeded.
     *
     * @param array $pmConfigs Настройки модуля оплаты
     * @param OrderModel $order Модель заказа
     * @param PaymentInterface $payment Модель платежа
     * @param KassaPaymentMethod $kassa Модель для оплаты через ЮКассу
     *
     * @return void
     * @throws Exception
     */
    private function processSucceedNotification(
        array $pmConfigs,
        OrderModel $order,
        PaymentInterface $payment,
        KassaPaymentMethod $kassa
    ): void
    {
        $paymentMethod = $payment->getPaymentMethod();

        if ($paymentMethod->getType() === PaymentMethodType::SBER_LOAN && $paymentMethod->getDiscountAmount()) {
            /** @var PaymentMethodSberLoan $paymentMethod */
            $order = $this->tryToAddSberLoanDiscount($order->order_id, $paymentMethod->getDiscountAmount()->value);
        }

        $jshopConfig = \JSFactory::getConfig();

        /** @var jshopCheckout $checkout */
        $checkout             = \JSFactory::getModel('checkout', 'jshop');
        $endStatus            = $pmConfigs['transaction_end_status'];
        $order->order_created = 1;
        $order->order_status  = $endStatus;
        $order->store();

        try {
            if ($jshopConfig->send_order_email) {
                $checkout->sendOrderEmail($order->order_id);
            }
        } catch (Exception $exception) {
            $this->logger->log('debug', $exception->getMessage());
        }

        $product_stock_removed = true;
        if ($jshopConfig->order_stock_removed_only_paid_status) {
            $product_stock_removed = in_array($endStatus, $jshopConfig->payment_status_enable_download_sale_file);
        }

        if ($product_stock_removed) {
            $order->changeProductQTYinStock("-");
        }

        $this->receiptHelper->sendSecondReceipt($order->order_id, $kassa, $endStatus);

        $checkout->changeStatusOrder($order->order_id, $endStatus, 0);

        if($paymentMethod->getType() == PaymentMethodType::B2B_SBERBANK) {
            $message = $this->getSuccessOrderHistoryMessageForB2B($paymentMethod);
        }

        if (!empty($message)) {
            $this->getOrderModel($order->order_id)->saveOrderHistory(0, $message);
        }
    }

    /**
     * Возвращает сообщение для истории статусов заказа, если тип платежа b2b_sberbank.
     *
     * @param AbstractPaymentMethod $paymentMethod
     *
     * @return string
     */
    private function getSuccessOrderHistoryMessageForB2B(AbstractPaymentMethod $paymentMethod): string
    {
        $payerBankDetails = $paymentMethod->getPayerBankDetails();

        $fields  = [
            'fullName'   => 'Полное наименование организации',
            'shortName'  => 'Сокращенное наименование организации',
            'adress'     => 'Адрес организации',
            'inn'        => 'ИНН организации',
            'kpp'        => 'КПП организации',
            'bankName'   => 'Наименование банка организации',
            'bankBranch' => 'Отделение банка организации',
            'bankBik'    => 'БИК банка организации',
            'account'    => 'Номер счета организации',
        ];
        $message = '';
        foreach ($fields as $field => $caption) {
            if (isset($requestData[$field])) {
                $message .= $caption.': '.$payerBankDetails->offsetGet($field).'\n';
            }
        }
        return $message;
    }

    /**
     * Выполняет действия, если получено уведомление о статусе payment.waiting_for_capture.
     *
     * @param array $pmConfigs Настройки модуля оплаты
     * @param OrderModel $order Модель заказа
     * @param PaymentInterface $payment Модель платежа
     * @param KassaPaymentMethod $kassa Модель для оплаты через ЮКассу
     * @param AbstractNotification $notificationObj Объект уведомления от Юkassa
     *
     * @return void
     */
    private function processWaitingForCaptureNtfctn(
        array $pmConfigs,
        OrderModel $order,
        PaymentInterface $payment,
        KassaPaymentMethod $kassa,
        AbstractNotification $notificationObj
    ): void
    {
        if ($kassa->isEnableHoldMode()) {
            $this->logger->log('info', 'Hold payment '.$payment->getId());

            /** @var jshopCheckout $checkout */
            $checkout             = \JSFactory::getModel('checkout', 'jshop');
            $onHoldStatus         = $pmConfigs['yookassa_hold_mode_on_hold_status'];
            $order->order_created = 1;
            $order->order_status  = $onHoldStatus;
            $order->store();

            $jshopConfig = \JSFactory::getConfig();

            try {
                if ($jshopConfig->send_order_email) {
                    $checkout->sendOrderEmail($order->order_id);
                }
            } catch (Exception $exception) {
                $this->logger->log('debug', $exception->getMessage());
            }

            $checkout->changeStatusOrder($order->order_id, $onHoldStatus, 0);
            $this->getOrderModel($order->order_id)->saveOrderHistory(
                0,
                sprintf(_JSHOP_YOO_HOLD_MODE_COMMENT_ON_HOLD,
                $payment->getExpiresAt()->format('d.m.Y H:i'))
            );

        } else {
            $payment = $kassa->capturePayment($notificationObj->getObject());
            if (!$payment || $payment->getStatus() !== PaymentStatus::SUCCEEDED) {
                $this->logger->log('debug', 'Capture payment error');
                header('HTTP/1.1 400 Bad Request');
            }
        }
    }

    /**
     * Выполняет действия, если получено уведомление о статусе payment.canceled и включен режим холдирования.
     *
     * @param array $pmConfigs Настройки модуля оплаты
     * @param OrderModel $order Модель заказа
     * @param PaymentInterface $payment Модель платежа
     *
     * @return void
     */
    private function processCanceledHoldPaymentNtfctn(array $pmConfigs, OrderModel $order, PaymentInterface $payment): void
    {
        $this->logger->log('info', 'Canceled hold payment ' . $payment->getId());

        /** @var jshopCheckout $checkout */
        $checkout             = \JSFactory::getModel('checkout', 'jshop');
        $cancelHoldStatus         = $pmConfigs['yookassa_hold_mode_cancel_status'];
        $paymentMethod = $payment->getPaymentMethod();

        if ($paymentMethod->getType() === PaymentMethodType::SBER_LOAN && $paymentMethod->getDiscountAmount()) {
            /** @var PaymentMethodSberLoan $paymentMethod */
            $order = $this->tryToAddSberLoanDiscount($order->order_id, $paymentMethod->getDiscountAmount()->value);
        }

        $order->order_created = 1;
        $order->order_status  = $cancelHoldStatus;
        $order->store();
        $checkout->changeStatusOrder($order->order_id, $cancelHoldStatus, 0);
    }

    /**
     * Выполняет действия, если получено уведомление о статусе payment.canceled.
     *
     * @param OrderModel $order Модель заказа
     * @param PaymentInterface $payment Модель платежа
     *
     * @return void
     */
    private function processCanceledPaymentNtfctn(OrderModel $order, PaymentInterface $payment): void
    {
        /** @var jshopCheckout $checkout */
        $checkout             = \JSFactory::getModel('checkout', 'jshop');
        $paymentMethod = $payment->getPaymentMethod();

        if ($paymentMethod->getType() === PaymentMethodType::SBER_LOAN && $paymentMethod->getDiscountAmount()) {
            /** @var PaymentMethodSberLoan $paymentMethod */
            $order = $this->tryToAddSberLoanDiscount($order->order_id, $paymentMethod->getDiscountAmount()->value);
        }

        $order->order_created = 1;
        $order->order_status  = self::CANCELED_STATUS_ID;
        $order->store();
        $checkout->changeStatusOrder($order->order_id, self::CANCELED_STATUS_ID, 0);
    }

    /**
     * Выполняет действия, если получено уведомление о статусе refund.succeeded.
     *
     * @param OrderModel $order Модель заказа
     * @param Refund $refund Модель возврата
     *
     * @return void
     */
    private function processRefundNtfctn(OrderModel $order, Refund $refund): void
    {
        try {
            $this->databaseHelper->insertRefund($order->getId(), $refund);
        } catch (Exception $e) {
            $this->logger->log('debug', 'Failed to save a refund to DB: ' . $e->getMessage());

            $this->logger->log('debug', 'Will create the refund table.');
            try {
                $tableChecker = new TableChecker();
                $tableChecker->checkYoomoneyRefunds();
            } catch (Exception $e) {
                $this->logger->log('debug', 'Failure to create the refund table: ' . $e->getMessage());

                return;
            }

            $this->databaseHelper->insertRefund($order->getId(), $refund);
        }

        /** @var jshopCheckout $checkout */
        $checkout = \JSFactory::getModel('checkout', 'jshop');

        $order->order_created = 1;
        $order->order_status  = self::REFUNDED_STATUS_ID;
        $order->store();
        $checkout->changeStatusOrder($order->order_id, self::REFUNDED_STATUS_ID, 0);
        $this->getOrderModel($order->order_id)->saveOrderHistory(
            0,
            sprintf(_JSHOP_YOO_KASSA_REFUND_SUCCEDED_ORDER_HISTORY,
                $refund->getAmount()->getValue())
        );
    }

    /**
     * Возвращает класс методов для работы с заказами.
     *
     * @param int $orderId Id заказа
     *
     * @return OrderModel
     */
    private function getOrderModel(int $orderId): OrderModel
    {
        return new OrderModel($orderId);
    }

    /**
     * Добавляет скидку к заказу
     *
     * @param int $orderId Id заказа
     * @param float $discountAmount Сумма скидки
     *
     * @return OrderModel
     */
    public function tryToAddSberLoanDiscount(int $orderId, float $discountAmount): OrderModel
    {
        try {
            $this->logger->log('info', 'Adding discount to order. Discount amount: ' . $discountAmount);
            return $this->getOrderModel($orderId)->orderAddDiscount(
                _JSHOP_YOO_SBER_LOAN_NAME_DISCOUNT,
                $discountAmount
            );
        } catch (Exception $e) {
            $this->logger->log(
                'error',
                'Error adding discount to order',
                ['exception' => $e->getMessage()]
            );
            header('HTTP/1.1 500 Server error');
            die();
        }
    }
}