<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Helpers;

/**
 * Класс методов для подготовки и работы с данными
 */
class StorageHelper
{
    /** @var JVersionDependenciesHelper Класс для совместимости модуля */
    public JVersionDependenciesHelper $versionHelper;

    /**
     * Конструктор StorageHelper.
     */
    public function __construct()
    {
        $this->versionHelper = new JVersionDependenciesHelper();
    }
    /**
     * Подготовка данных в нужный формат (строка или json) для сохранения.
     *
     * @param string|null $paramsRow - строка с параметрами из БД
     * @param array $paramsArray - массив с параметрами из формы
     *
     * @return false|string
     */
    public function prepareQueryParams(?string $paramsRow, array $paramsArray): bool|string
    {
        return $this->isJsonString($paramsRow) || $this->versionHelper->getJoomShoppingVersion() == 5
            ? json_encode($paramsArray)
            : (new \parseString($paramsArray))->splitParamsToString();
    }

    /**
     * Проверка строки на json формат.
     *
     * @param string $string
     *
     * @return bool
     */
    public function isJsonString(string $string): bool
    {
        json_decode($string, false);
        return json_last_error() === JSON_ERROR_NONE;
    }

    /**
     * Парсинг строки в массив
     * и передача конкретной части массива, если требуется.
     *
     * @param string $string Строка, которую необходимо распарсить
     * @param string|null $arrayName Название ключа массива, который необходимо вернуть из строки
     *
     * @return array
     */
    public function stringToArray(string $string, string $arrayName = null): array
    {
        parse_str($string, $result);
        return $arrayName && isset($result[$arrayName]) ? $result[$arrayName] : $result;
    }
}