<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Helpers;

use YooKassa\Client;
use YooMoney\Model\KassaPaymentMethod;
use Psr\Log\LoggerInterface;

/**
 * Фабрика для получения единственного экземпляра клиента API Юkassa.
 */
class YookassaClientFactory
{
    /** @var LoggerInterface Класс методов для работы с логами модуля */
    private LoggerInterface $logger;

    /** @var KassaPaymentMethod Класс методов для оплаты через ЮКассу */
    private KassaPaymentMethod $kassaModel;

    /** @var Client|null Класс клиента API */
    private ?Client $client = null;

    /** Название CMS */
    public const CMS_NAME = 'Joomla';

    /** Название модуля */
    public const MODULE_NAME = 'yoo_api_joomla5_joomshopping';

    /**
     * YookassaClientFactory конструктор.
     *
     * @param LoggerInterface $logger
     * @param KassaPaymentMethod $kassaModel
     */
    public function __construct(LoggerInterface $logger, KassaPaymentMethod $kassaModel)
    {
        $this->logger = $logger;
        $this->kassaModel = $kassaModel;
    }

    /**
     * Установка свойств для user-agent
     * и получение клиента по токену.
     *
     * @param string $token Токен
     *
     * @return Client
     */
    public function getClientWithGivenToken(string $token): Client
    {
        return $this->getClientSkeleton()->setAuthToken($token);
    }

    /**
     * Установка свойств для user-agent
     * и получение клиента в зависимости от пройденной авторизации.
     *
     * @return Client
     */
    public function getClient(): Client
    {
        if (!$this->client) {
            $this->client = $this->getClientSkeleton();
            $this->setClientAuth();
        }
        return $this->client;
    }

    /**
     * Устанавливает значение свойств для user-agent.
     *
     * @return Client
     */
    private function getClientSkeleton(): Client
    {
        $client = new Client();
        $client->setLogger($this->logger);
        $userAgent = $client->getApiClient()->getUserAgent();
        $userAgent->setCms(self::CMS_NAME, JVERSION);
        $userAgent->setModule(self::MODULE_NAME, $this->kassaModel->getModule()::_JSHOP_YOO_VERSION);

        return $client;
    }

    /**
     * Установка данных по авторизации в зависимости от модуля, через который проходит оплата.
     *
     * @return void
     */
    private function setClientAuth(): void
    {
        if ($this->kassaModel->getModule() instanceof \pm_yoomoney_sbbol) {
            $this->client->setAuth(
                $this->kassaModel->getSbbolShopId(),
                $this->kassaModel->getSbbolPassword()
            );
            return;
        }

        if ($this->kassaModel->getOauthToken()) {
            $this->client->setAuthToken($this->kassaModel->getOauthToken());
            return;
        }

        $this->client->setAuth(
            $this->kassaModel->getShopId(),
            $this->kassaModel->getPassword()
        );
    }
}
