<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Helpers\OauthHelpers;

/**
 * Интерфейс класса-адаптера для отправки запросов
 */
interface HttpClientInterface
{
    /**
     * Отправка POST запроса и получение данных
     *
     * @param string $url
     * @param array $parameters
     *
     * @return string
     */
    public function sendRequest(string $url, array $parameters): string;
}