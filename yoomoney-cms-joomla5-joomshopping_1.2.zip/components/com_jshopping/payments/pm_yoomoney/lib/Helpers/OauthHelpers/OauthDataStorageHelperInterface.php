<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Helpers\OauthHelpers;

\defined('JPATH_PLATFORM') or die;

/**
 * Интерфейс класса-адаптера для работы с параметрами платежного метода
 */
interface OauthDataStorageHelperInterface
{
    /**
     * Получение account.
     *
     * @return string|null
     */
    public function getShopId(): ?string;

    /**
     * Установка значения account.
     *
     * @param int $shopId
     *
     * @return bool
     */
    public function saveShopId(int $shopId): bool;

    /**
     * Получение state.
     *
     * @return string|null
     */
    public function getState(): ?string;

    /**
     * Установка значения state.
     *
     * @param string $state
     *
     * @return bool
     */
    public function saveState(string $state): bool;

    /**
     * Получение access_token.
     *
     * @return string|null
     */
    public function getToken(): ?string;

    /**
     * Установка значения access_token и expires_in.
     *
     * @param string $token
     * @param string $expiresIn
     * @return bool
     */
    public function saveToken(string $token, string $expiresIn): bool;
}