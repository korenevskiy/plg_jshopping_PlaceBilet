<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Helpers\OauthHelpers;

/**
 * Интерфейс класса-адаптера для получения информации по магазину
 */
interface YookassaShopInfoHelperInterface
{
    /**
     * Подключение и получение информации о магазине
     *
     * @return array
     */
    public function fetchShopInfo(): array;

    /**
     * Получение account_id
     *
     * @param string $token
     *
     * @return string
     */
    public function fetchShopIdWithGivenToken(string $token): string;
}