<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Helpers\OauthHelpers;

/**
 * Интерфейс класса-адаптера для работы с oauth вебхуками
 */
interface OauthWebhooksHelperInterface
{
    /**
     * Получение ссылки на уведомления.
     *
     * @return string
     */
    public function getNotificationUrl(): string;

    /**
     * Создание вебхуков по токену.
     *
     * @param string $token
     * @param string $notificationUrl
     * @return void
     */
    public function addWebhooksWithGivenToken(string $token, string $notificationUrl);

    /**
     * Удаление вебхуков по токену.
     *
     * @param string $token
     * @return void
     */
    public function removeWebhooksWithGivenToken(string $token): void;
}