<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Helpers\OauthHelpers;

use Exception;
use YooKassa\Client;
use YooMoney\Helpers\YookassaClientFactory;

/**
 * Класс методов для получения информации о магазине.
 */
class YookassaShopInfoHelper implements YookassaShopInfoHelperInterface
{
    /** Id аккаунта полученный из данных по магазину */
    public const SHOP_INFO_ACCOUNT_ID = 'account_id';

    /** Признак тестового магазина полученный из данных по магазину */
    public const SHOP_INFO_TEST = 'test';

    /** Флаг включенной фискализации полученный из данных по магазину */
    public const SHOP_INFO_FISCALIZATION_ENABLED = 'fiscalization_enabled';

    /*** @var YookassaClientFactory Фабрика для получения экземпляра клиента API Юkassa */
    private YookassaClientFactory $clientFactory;

    /**
     * YookassaShopInfoHelper конструктор.
     *
     * @param YookassaClientFactory $clientFactory
     */
    public function __construct(YookassaClientFactory $clientFactory)
    {
        $this->clientFactory = $clientFactory;
    }

    /**
     * Подключение и получение информации о магазине.
     *
     * @return array
     * @throws Exception
     */
    public function fetchShopInfo(): array
    {
        $client = $this->clientFactory->getClient();
        $shopInfo = $this->tryGetShopInfo($client);
        return $this->checkShopInfo($shopInfo);
    }

    /**
     * Проверка на подключение и получение информации о магазине по токену.
     *
     * @param string $token Токен
     *
     * @return array
     * @throws Exception
     */
    public function fetchShopInfoWithGivenToken(string $token): array
    {
        $client = $this->clientFactory->getClientWithGivenToken($token);
        $shopInfo = $this->tryGetShopInfo($client);
        return $this->checkShopInfo($shopInfo);
    }

    /**
     * Попытка получить информацию о магазине.
     *
     * @param Client $client Класс клиента API
     *
     * @return array|null
     * @throws Exception
     */
    private function tryGetShopInfo(Client $client): ?array
    {
        try {
            return $client->me();
        } catch (Exception $e) {
            throw new Exception('Failed to get information about shop. ' . $e->getMessage());
        }
    }

    /**
     * Проверка на наличие обязательных параметров в информации о магазине.
     *
     * @param array|null $shopInfo Массив с информацией о магазине
     *
     * @return array
     * @throws Exception
     */
    private function checkShopInfo(?array $shopInfo = []): array
    {
        if (!isset(
            $shopInfo[self::SHOP_INFO_ACCOUNT_ID],
            $shopInfo[self::SHOP_INFO_TEST],
            $shopInfo[self::SHOP_INFO_FISCALIZATION_ENABLED])
        ) {
            throw new Exception('Information about shop is empty!');
        }

        return $shopInfo;
    }

    /**
     * Получение account_id.
     *
     * @param string $token Токен
     *
     * @return string
     * @throws Exception
     */
    public function fetchShopIdWithGivenToken(string $token): string
    {
        $shopInfo = $this->fetchShopInfoWithGivenToken($token);
        return $shopInfo[self::SHOP_INFO_ACCOUNT_ID];
    }
}