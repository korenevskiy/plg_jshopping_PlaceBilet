<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Helpers\OauthHelpers;

use Exception;
use Joomla\Component\Jshopping\Site\Table\PaymentMethodTable;
use YooMoney\Helpers\LoggerHelper;
use YooMoney\Helpers\StorageHelper;
use YooMoney\Model\KassaPaymentMethod;

/**
 * Класс-адаптер методов для работы с параметрами платежного метода
 */
class OauthDataStorageHelper implements OauthDataStorageHelperInterface
{
    /** Название таблицы для создания запросов */
    public const TABLE_NAME = '#__jshopping_payment_method';

    /*** @var PaymentMethodTable Класс для работы с моделью платежного метода */
    private PaymentMethodTable $paymentMethodModule;

    /*** @var KassaPaymentMethod Класс методов для оплаты через ЮКассу */
    private KassaPaymentMethod $kassaModel;

    /*** @var StorageHelper Класс методов для подготовки и работы с данными */
    private StorageHelper $storageHelper;

    /*** @var LoggerHelper Класс методов для работы с логами модуля */
    private LoggerHelper $loggerHelper;

    /**
     * OauthDataStorageHelper конструктор.
     *
     * @param KassaPaymentMethod $kassaModel
     */
    public function __construct(KassaPaymentMethod $kassaModel)
    {
        $this->paymentMethodModule = $kassaModel->getPaymentMethodModule();
        $this->kassaModel = $kassaModel;
        $this->storageHelper = new StorageHelper();
        $this->loggerHelper = new LoggerHelper();
    }

    /**
     * Получение id платежного метода.
     *
     * @return int
     */
    public function getPaymentId(): int
    {
        return $this->paymentMethodModule->payment_id;
    }

    /**
     * Получение строки параметров из БД.
     *
     * @return string|null
     */
    public function getPaymentParamsDB(): ?string
    {
        return $this->paymentMethodModule->payment_params;
    }

    /**
     * Получение shop_id.
     *
     * @return string|null
     */
    public function getShopId(): ?string
    {
        return $this->kassaModel->getShopId();
    }

    /**
     * Установка значения shop_id.
     *
     * @param int $shopId
     *
     * @return bool
     * @throws Exception
     */
    public function saveShopId(int $shopId): bool
    {
        $this->kassaModel->setShopId($shopId);
        return $this->save();
    }

    /**
     * Получение state.
     *
     * @return string|null
     */
    public function getState(): ?string
    {
        return $this->kassaModel->getState();
    }

    /**
     * Установка значения state.
     *
     * @param string $state
     *
     * @return bool
     * @throws Exception
     */
    public function saveState(string $state): bool
    {
        $this->kassaModel->setState($state);
        return $this->save();
    }

    /**
     * Получение access_token.
     *
     * @return string|null
     */
    public function getToken(): ?string
    {
        return $this->kassaModel->getOauthToken();
    }

    /**
     * Установка значения access_token и expires_in.
     *
     * @param string $token
     * @param string $expiresIn
     *
     * @return bool
     * @throws Exception
     */
    public function saveToken(string $token, string $expiresIn): bool
    {
        $this->kassaModel->setOauthToken($token, $expiresIn);
        return $this->save();
    }


    /**
     * Сохранение параметров платежного метода в БД.
     *
     * @return bool
     * @throws Exception
     */
    public function save(): bool
    {
        $id = $this->getPaymentId();
        $params = $this->storageHelper->prepareQueryParams(
            $this->getPaymentParamsDB(),
            $this->kassaModel->getParams()
        );
        try {
            $db = \JFactory::getDBO();
            $query = $db->getQuery(true)
                ->update($db->quoteName(self::TABLE_NAME))
                ->set($db->quoteName('payment_params') . ' = ' . $db->quote($params))
                ->where($db->quoteName('payment_id') . ' = ' . $db->quote($id));
            $db->setQuery($query);
            return $db->execute();
        } catch (Exception $e) {
            $this->loggerHelper->log('error', 'Error to update payment method. Error: ' . $e->getMessage());
            return false;
        }
    }
}