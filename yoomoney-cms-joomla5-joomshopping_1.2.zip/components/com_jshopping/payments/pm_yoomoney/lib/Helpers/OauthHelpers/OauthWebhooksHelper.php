<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Helpers\OauthHelpers;

use Exception;
use JUri;
use Psr\Log\LoggerInterface;
use YooKassa\Client;
use YooKassa\Common\ListObjectInterface;
use YooKassa\Model\Notification\NotificationEventType;
use YooMoney\Helpers\YookassaClientFactory;

/**
 * Класс методов для работы с oauth вебхуками
 */
class OauthWebhooksHelper implements OauthWebhooksHelperInterface
{
    /** @var LoggerInterface Класс методов для работы с логами модуля */
    private LoggerInterface $logger;

    /** @var YookassaClientFactory Фабрика для получения экземпляра клиента API Юkassa */
    private YookassaClientFactory $clientFactory;

    /** @var Client Класс клиента API */
    private Client $client;

    /**
     * OauthWebhooksHelper конструктор.
     *
     * @param LoggerInterface $logger
     * @param YookassaClientFactory $clientFactory
     */
    public function __construct(
        LoggerInterface $logger,
        YookassaClientFactory $clientFactory
    )
    {
        $this->logger = $logger;
        $this->clientFactory = $clientFactory;
    }

    /**
     * Создание вебхуков по токену.
     *
     * @param string $token Токен
     * @param string $notificationUrl Url для уведомления
     *
     * @return void
     * @throws Exception
     */
    public function addWebhooksWithGivenToken(string $token, string $notificationUrl): void
    {
        $this->client = $this->clientFactory->getClientWithGivenToken($token);
        $this->logger->log('info', 'Going to create webhooks for token: ' . $token);
        $this->addWebhooksWithSetClient($notificationUrl);
    }

    /**
     * Удаление вебхуков по токену.
     *
     * @param string $token Токен
     *
     * @return void
     * @throws Exception
     */
    public function removeWebhooksWithGivenToken(string $token): void
    {
        $this->client = $this->clientFactory->getClientWithGivenToken($token);
        $this->logger->log('info', 'Going to remove webhooks for token: ' . $token);
        $this->removeWebhooksWithSetClient();
    }

    /**
     * Изменение url для вебхуков путем удаления, а потом создания новых вебхуков.
     *
     * @param string $notificationUrl Url для уведомления
     *
     * @return void
     * @throws Exception
     */
    public function replaceWebhooksWithNewUrl(string $notificationUrl): void
    {
        $this->client = $this->clientFactory->getClient();
        $this->removeWebhooksWithSetClient();
        $this->addWebhooksWithSetClient($notificationUrl);
    }

    /**
     * Создание вебхуков.
     *
     * @param string $notificationUrl Url для уведомления
     *
     * @return void
     * @throws Exception
     */
    private function addWebhooksWithSetClient(string $notificationUrl): void
    {
        $webHookUrl = str_replace(
            'http://',
            'https://',
            $notificationUrl
        );

        foreach ($this->getNotificationEventList() as $event) {
            try {
                $this->client->addWebhook(['event' => $event, 'url' => $webHookUrl]);
                $this->logger->log('info', 'Webhook created: ' . $event . ':' . $webHookUrl);
            } catch (Exception $e) {
                $this->logger->log('error', 'Webhook creation failed: ' . $event . ':' . $webHookUrl);
                throw $e;
            }
        }
    }

    /**
     * Удаление вебхуков.
     *
     * @return void
     * @throws Exception
     */
    public function removeWebhooksWithSetClient(): void
    {
        $currentWebHookList = $this->client->getWebhooks()->getItems();

        if (!$currentWebHookList) {
            $this->logger->log('info', 'Webhooks not found');
            return;
        }

        foreach ($currentWebHookList as $webHook) {
            try {
                $this->client->removeWebhook($webHook->getId());
                $this->logger->log('info', 'Webhook was removed: ' . $webHook->getId());
            } catch (Exception $e) {
                $this->logger->log('error', 'Failed remove webhook: ' . $webHook->getId());
                throw $e;
            }
        }

    }

    /**
     * Проверка на наличие вебхуков и их типов.
     *
     * @return bool
     * @throws Exception
     */
    public function checkWebhooks(): bool
    {
        $currentWebHookList = $this->getCurrentWebhooks();

        if (empty($currentWebHookList)) {
            $this->logger->log('error', 'Webhooks not found');
            return false;
        }

        $countWebhook = 0;
        $webhookEvents = [];
        foreach ($currentWebHookList as $webHook) {
            if (
                in_array($webHook->getEvent(), $this->getNotificationEventList())
                && !in_array($webHook->getEvent(), $webhookEvents)
            ) {
                $countWebhook++;
                $webhookEvents[] = $webHook->getEvent();
            }
        }

        if ($countWebhook != 4) {
            $this->logger->log('error', 'Webhooks count less then 4');
            return false;
        }

        return true;
    }

    /**
     * Получение списка установленных вебхуков.
     *
     * @return ListObjectInterface|null
     */
    public function getCurrentWebhooks(): ?ListObjectInterface
    {
        try {
            return $this->clientFactory->getClient()->getWebhooks()->getItems();
        } catch (Exception $e) {
            $this->logger->error('Failed to get current webhooks: ' . $e->getMessage());
        }
        return null;
    }

    /**
     * Получение ссылки, которая установлена в вебхуках.
     *
     * @return string
     */
    public function getCurrentWebhookUrl(): string
    {
        $currentWebHookList = $this->getCurrentWebhooks();
        if (!isset($currentWebHookList[0])) {
            return '';
        }
        return $currentWebHookList[0]->getUrl();
    }

    /**
     * Список типов уведомлений.
     *
     * @return array
     */
    private function getNotificationEventList(): array
    {
        return [
            NotificationEventType::PAYMENT_SUCCEEDED,
            NotificationEventType::PAYMENT_CANCELED,
            NotificationEventType::PAYMENT_WAITING_FOR_CAPTURE,
            NotificationEventType::REFUND_SUCCEEDED,
        ];
    }

    /**
     * Получение ссылки на уведомления.
     *
     * @return string
     */
    public function getNotificationUrl(): string
    {
        $uri = JURI::getInstance();
        $sslurlhost = 'https://' . $uri->toString(['host', 'port']);

        $notify_url = $sslurlhost . \JSHelper::SEFLink(
                "index.php?option=com_jshopping&controller=checkout&task=step7&act=notify&js_paymentclass=pm_yoomoney&no_lang=1"
            );
        return htmlspecialchars_decode($notify_url);
    }
}
