<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Helpers;

use Exception;
use YooKassa\Model\Notification\NotificationFactory;
use YooKassa\Model\Notification\AbstractNotification;

/**
 * Класс-фабрика для получения объекта уведомления от Юkassa
 */
class YookassaNotificationFactory
{
    /** @var LoggerHelper Класс методов для работы с логами модуля */
    private LoggerHelper $logger;

    /** @var AbstractNotification|null Объект уведомления от Юkassa */
    private ?AbstractNotification $notificationObject = null;

    /**
     * YookassaNotificationFactory конструктор.
     */
    public function __construct()
    {
        $this->logger = new LoggerHelper();
    }

    /**
     * Возвращает объект уведомления от Юkassa, если он был получен ранее, или сначала
     * преобразует уведомление от Юkassa в объект.
     *
     * @return AbstractNotification
     * @throws Exception
     */
    public function getNotificationObject(): AbstractNotification
    {
        if ($this->notificationObject) {
            return $this->notificationObject;
        }

        $source = file_get_contents('php://input');
        $this->logger->log('debug', 'Notification body source: '.$source);
        if (empty($source)) {
            $this->logger->log('debug', 'Notification error: body is empty!');
            header('HTTP/1.1 400 Body is empty');
            die();
        }

        $data = json_decode($source, true);
        if (empty($data)) {
            $this->logger->log('debug', 'Notification error: invalid body!');
            header('HTTP/1.1 400 Invalid body');
            die();
        }

        $factory = new NotificationFactory();
        $notification = $factory->factory($data);
        $this->setNotificationObj($notification);

        return $notification;
    }

    /**
     * Сеттер для объекта уведомления.
     *
     * @param AbstractNotification $object Объект уведомления от Юkassa
     */
    private function setNotificationObj(AbstractNotification $object): void
    {
        $this->notificationObject = $object;
    }
}