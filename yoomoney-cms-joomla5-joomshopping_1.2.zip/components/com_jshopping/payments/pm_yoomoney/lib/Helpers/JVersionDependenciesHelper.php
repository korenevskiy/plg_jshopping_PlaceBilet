<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Helpers;

use Joomla\CMS\Table\Table;

/**
 * В данный класс вынесены функции, для совместимости модуля Yoomoney с версиями JoomShopping 4.* и 5.*
 */
class JVersionDependenciesHelper
{
    /** @var int Версия joomshopping */
    private int $joomshoppingVersion;

    /**
     * JVersionDependenciesHelper конструктор.
     */
    public function __construct()
    {
        $this->joomshoppingVersion = (version_compare(\JSFactory::getConfig()->getVersion(), '5.0', '<') == 1) ? 4 : 5;
    }

    /**
     * Возвращает версию JoomShopping от 4 до 5 версии.
     *
     * @return int
     */
    public function getJoomShoppingVersion(): int
    {
        return $this->joomshoppingVersion;
    }

    /**
     * Функция для получения инстанса \Joomla\Component\Jshopping\Site\Table\AddonTable.
     *
     * @return mixed
     */
    public function getAddonTableObj()
    {
        $app = \JFactory::getApplication();

        /** @var MVCFactoryInterface $factory */
        $factory = $app->bootComponent('com_jshopping')->getMVCFactory();
        return $factory->createTable('addon', 'Site');
    }
}