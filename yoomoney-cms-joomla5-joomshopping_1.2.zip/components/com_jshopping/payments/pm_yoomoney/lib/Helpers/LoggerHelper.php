<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Helpers;

use Psr\Log\LoggerInterface;
use Psr\Log\LogLevel;

/**
 * Класс методов для работы с логами модуля
 */
class LoggerHelper implements LoggerInterface
{
    /**
     * Выполняет подготовку данных и запись лога в файл.
     *
     * @param string $level Уровень
     * @param string $message Сообщение
     * @param array $context Контекст ошибки
     *
     * @return void
     */
    public function log($level, $message, array $context = []): void
    {
        $replace = $this->prepareContext($context);

        $message = strip_tags($message);

        if (!empty($replace)) {
            $message = $this->prepareMessage($replace, $message);
        }

        $this->write($this->getLogFileName(), ' [' . $level . '] ' . $message);
    }

    /**
     * Возвращает путь к файлу лога.
     *
     * @return string
     */
    public function getLogFileName(): string
    {
        return realpath(JSH_DIR).'/log/pm_yoomoney.log';
    }

    /**
     * Подготовка данных из контекста сообщения.
     *
     * @param array $context Массив с данными
     *
     * @return array|void
     */
    private function prepareContext(array $context)
    {
        if (!$context) {
            return;
        }

        $replace = [];
        foreach ($context as $key => $value) {
            $replace['{'.$key.'}'] = (is_array($value) || is_object($value)) ? json_encode($value, JSON_PRETTY_PRINT) : $value;
        }

        return $replace;
    }

    /**
     * Разбивка данных и формирование сообщения.
     *
     * @param array $replace
     * @param string $message
     *
     * @return string
     */
    private function prepareMessage(array $replace, string $message): string
    {
        foreach ($replace as $key => $object) {
            $label = trim($key, "{}");
            $message .= " \n{$label}: {$object}";
        }

        return $message;
    }

    /**
     * Открытие файла для записи, запись и закрытие файла.
     *
     * @param string $fileName Файл в котором необходимо произвести запись
     * @param string $message Сообщение которое нужно записать в файл
     *
     * @return void
     */
    private function write(string $fileName, string $message): void
    {
        $fd = @fopen($fileName, 'a');

        if (!$fd) {
            return;
        }

        flock($fd, LOCK_EX);
        fwrite($fd, date(DATE_ATOM). $message ."\r\n");
        flock($fd, LOCK_UN);
        fclose($fd);
    }

    /**
     * @param string $message
     * @param array $context
     *
     * @return void
     */
    public function emergency($message, array $context = []): void
    {
        $this->log(LogLevel::EMERGENCY, $message, $context);
    }

    /**
     * @param string $message
     * @param array $context
     *
     * @return void
     */
    public function alert($message, array $context = []): void
    {
        $this->log(LogLevel::ALERT, $message, $context);
    }

    /**
     * @param string $message
     * @param array $context
     *
     * @return void
     */
    public function critical($message, array $context = []): void
    {
        $this->log(LogLevel::CRITICAL, $message, $context);
    }

    /**
     * @param string $message
     * @param array $context
     *
     * @return void
     */
    public function error($message, array $context = []): void
    {
        $this->log(LogLevel::ERROR, $message, $context);
    }

    /**
     * @param string $message
     * @param array $context
     *
     * @return void
     */
    public function warning($message, array $context = []): void
    {
        $this->log(LogLevel::WARNING, $message, $context);
    }

    /**
     * @param string $message
     * @param array $context
     *
     * @return void
     */
    public function notice($message, array $context = []): void
    {
        $this->log(LogLevel::NOTICE, $message, $context);
    }

    /**
     * @param string $message
     * @param array $context
     *
     * @return void
     */
    public function info($message, array $context = []): void
    {
        $this->log(LogLevel::INFO, $message, $context);
    }

    /**
     * @param string $message
     * @param array $context
     *
     * @return void
     */
    public function debug($message, array $context = []): void
    {
        $this->log(LogLevel::DEBUG, $message, $context);
    }
}