<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Helpers;

use Exception;
use YooMoney\Model\KassaPaymentMethod;
use YooMoney\Model\KassaSecondReceiptModel;
use YooMoney\Model\OrderModel;

/**
 * Класс методов для работы с чеками
 */
class ReceiptHelper
{
    /** @var LoggerHelper Класс методов для работы с логами модуля */
    private LoggerHelper $logger;

    /**
     * Конструктор ReceiptHelper.
     */
    public function __construct()
    {
        $this->logger = new LoggerHelper();
    }

    /**
     * Выполняет отправку второго чека.
     *
     * @param int $orderId Id заказа
     * @param KassaPaymentMethod $kassa Класс методов для оплаты через ЮКассу
     * @param string $status Текущий статус заказа
     *
     * @return void
     */
    public function sendSecondReceipt(int $orderId, KassaPaymentMethod $kassa, string $status): void
    {
        if (
            !$this->isNeedSecondReceipt(
                $status,
                $kassa->isSendReceipt(),
                $kassa->isSendSecondReceipt(),
                $kassa->getSecondReceiptStatus()
            )
        ) {
            return;
        }

        $order = \JSFactory::getTable('order', 'jshop');
        $order->load($orderId);

        $apiClient = $kassa->getClient();

        $orderInfo = [
            'orderId'    => $order->order_id,
            'user_email' => $order->email,
            'user_phone' => $order->phone,
        ];

        $databaseHelper = new DatabaseHelper();

        try {
            $paymentInfo = $apiClient->getPaymentInfo($databaseHelper->getPaymentIdByOrderId($order->order_id));
        } catch (Exception $e) {
            $this->logger->log('error', 'Fail get payment info', ['exception' => $e->getMessage()]);
            return;
        }

        $secondReceipt = new KassaSecondReceiptModel($paymentInfo, $orderInfo, $apiClient);
        if (!$secondReceipt->sendSecondReceipt()) {
            return;
        }

        $orderModel = new OrderModel($orderId);
        $orderModel->saveOrderHistory(
            0,
            sprintf(
                _JSHOP_YOO_KASSA_SEND_SECOND_RECEIPT_HISTORY,
                number_format($secondReceipt->getSettlementsSum(), 2, '.', ' ')
            )
        );
    }

    /**
     * Проверка условий необходимости отправки второго чека.
     *
     * @param string $status Текущий статус заказа
     * @param bool $isSendReceipt Флаг указывающий включена ли фискализация в модуле
     * @param bool $isSendSecondReceipt Флаг указывающий включена ли отправка второго чека в модуле
     * @param string $secondReceiptStatus Статус, при котором должна производится отправка второго чека
     *
     * @return bool
     */
    private function isNeedSecondReceipt(
        string $status,
        bool $isSendReceipt,
        bool $isSendSecondReceipt,
        string $secondReceiptStatus
    ): bool
    {
        if (!$isSendReceipt) {
            return false;
        } elseif (!$isSendSecondReceipt) {
            return false;
        } elseif ($status !== $secondReceiptStatus) {
            return false;
        }

        return true;
    }
}