<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Helpers;

use Joomla\Database\DatabaseInterface;
use YooKassa\Model\Payment\PaymentInterface;
use YooKassa\Model\Refund\RefundInterface;

/**
 * Класс методов для запросов в БД
 */
class DatabaseHelper
{
    /** @var DatabaseInterface Драйвер для работы с БД */
    private DatabaseInterface $_db;

    /**
     * DatabaseHelper конструктор.
     */
    public function __construct()
    {
        $this->_db = \JFactory::getDbo();
    }

    /**
     * Сохранение или обновление данных о платеже в БД.
     *
     * @param int $orderId Id заказа
     * @param PaymentInterface $payment Модель платежа
     *
     * @return void
     */
    public function savePayment(int $orderId, PaymentInterface $payment): void
    {
        $query = $this->_db->getQuery(true);
        $query->select('payment_id')
            ->from('#__yoomoney_payments')
            ->where($this->_db->quoteName('order_id') . ' = ' . (int)$orderId);
        $this->_db->setQuery($query);
        $record = $this->_db->loadRow();
        if (empty($record)) {
            $this->insertPayment($orderId, $payment);
        } else {
            $this->updatePayment($orderId, $payment);
        }
    }

    /**
     * Возвращает payment id по id заказа.
     *
     * @param int $orderId Id заказа
     *
     * @return null|string
     */
    public function getPaymentIdByOrderId(int $orderId): ?string
    {
        $query = $this->_db->getQuery(true);
        $query->select('payment_id')
            ->from('#__yoomoney_payments')
            ->where($this->_db->quoteName('order_id') . ' = ' . (int)$orderId);
        $this->_db->setQuery($query);
        $record = $this->_db->loadRow();
        if (empty($record)) {
            return null;
        }
        return $record[0];
    }

    /**
     * Возвращает id заказа по payment id.
     *
     * @param string $paymentId Id платежа
     *
     * @return null|string
     */
    public function getOrderIdByPaymentId(string $paymentId): ?string
    {
        $query = $this->_db->getQuery(true);
        $query->select('order_id')
            ->from('#__yoomoney_payments')
            ->where(
                $this->_db->quoteName('payment_id') . ' = \'' . $paymentId . '\''
            );
        $this->_db->setQuery($query);
        $record = $this->_db->loadRow();
        if (empty($record)) {
            return null;
        }
        return $record[0];
    }

    /**
     * Создает новую запись о платеже в БД.
     *
     * @param int $orderId Id заказа
     * @param PaymentInterface $payment Модель платежа
     *
     * @return void
     */
    private function insertPayment(int $orderId, PaymentInterface $payment): void
    {
        $paymentMethodId = '';
        if ($payment->getPaymentMethod() !== null) {
            $paymentMethodId = $payment->getPaymentMethod()->getId();
        }

        $query = $this->_db->getQuery(true);
        $query->clear()->insert('#__yoomoney_payments')
            ->columns(
                [
                    $this->_db->quoteName('order_id'), $this->_db->quoteName('payment_id'),
                    $this->_db->quoteName('status'), $this->_db->quoteName('amount'),
                    $this->_db->quoteName('currency'), $this->_db->quoteName('payment_method_id'),
                    $this->_db->quoteName('paid'), $this->_db->quoteName('created_at')
                ]
            )
            ->values(
                $orderId . ','
                . $this->_db->quote($payment->getId()) . ","
                . $this->_db->quote($payment->getStatus()) . ","
                . $this->_db->quote($payment->getAmount()->getValue()) . ","
                . $this->_db->quote($payment->getAmount()->getCurrency()) . ","
                . $this->_db->quote($paymentMethodId) . ","
                . "'" . ($payment->getPaid() ? 'Y' : 'N') . "',"
                . $this->_db->quote($payment->getCreatedAt()->format('Y-m-d H:i:s'))
            );
        $this->_db->setQuery($query);
        try {
            $this->_db->execute();
        }
        catch (\JDatabaseExceptionExecuting $e) {
            \JError::raiseError(500, $e->getMessage());
        }
    }

    /**
     * Обновляет запись о платеже в БД.
     *
     * @param int $orderId Id заказа
     * @param PaymentInterface $payment Модель платежа
     *
     * @return void
     */
    private function updatePayment(int $orderId, PaymentInterface $payment): void
    {
        $paymentMethodId = '';
        if ($payment->getPaymentMethod() !== null) {
            $paymentMethodId = $payment->getPaymentMethod()->getId();
        }

        $query = $this->_db->getQuery(true);
        $query->update('#__yoomoney_payments')
            ->set(
                $this->_db->quoteName('payment_id') . ' = ' . $this->_db->quote($payment->getId()) . ',' .
                $this->_db->quoteName('status') . ' = ' . $this->_db->quote($payment->getStatus()) . ',' .
                $this->_db->quoteName('amount') . ' = ' . $this->_db->quote($payment->getAmount()->getValue()) . ',' .
                $this->_db->quoteName('currency') . ' = ' . $this->_db->quote($payment->getAmount()->getCurrency()) . ',' .
                $this->_db->quoteName('payment_method_id') . ' = ' . $this->_db->quote($paymentMethodId) . ',' .
                $this->_db->quoteName('paid') . ' = \'' . ($payment->getPaid() ? 'Y' : 'N') . '\',' .
                $this->_db->quoteName('created_at') . ' = ' . $this->_db->quote($payment->getCreatedAt()->format('Y-m-d H:i:s'))
            )
            ->where($this->_db->quoteName('order_id') . ' = ' . (int)$orderId);
        $this->_db->setQuery($query);
        try {
            $this->_db->execute();
        }
        catch (\JDatabaseExceptionExecuting $e) {
            \JError::raiseError(500, $e->getMessage());
        }
    }

    /**
     * Возвращает запись из таблицы возвратов.
     *
     * @param string $refundId Id возврата
     *
     * @return null|array
     */
    public function getRefundById(string $refundId): ?array
    {
        $query = $this->_db->getQuery(true);
        $query->select('*')
            ->from('#__yoomoney_refunds')
            ->where(
                $this->_db->quoteName('refund_id') . ' = \'' . $refundId . '\''
            );
        $this->_db->setQuery($query);
        $record = $this->_db->loadRow();
        if (empty($record)) {
            return null;
        }
        return $record;
    }

    /**
     * Добавляет запись в таблицу возвратов.
     *
     * @param int $orderId Id заказа
     * @param RefundInterface $refund Модель возврата
     *
     * @return void
     */
    public function insertRefund(int $orderId, RefundInterface $refund): void
    {
        $query = $this->_db->getQuery(true);
        $query->clear()->insert('#__yoomoney_refunds')
            ->columns(
                [
                    $this->_db->quoteName('refund_id'),
                    $this->_db->quoteName('order_id'),
                    $this->_db->quoteName('created_at')
                ]
            )
            ->values(
                $this->_db->quote($refund->getId()) . ","
                . $orderId . ','
                . $this->_db->quote($refund->getCreatedAt()->format('Y-m-d H:i:s'))
            );
        $this->_db->setQuery($query);
        $this->_db->execute();
    }

    /**
     * Возвращает список товаров из заказа.
     *
     * @param int $orderId Id заказа
     *
     * @return array|null
     */
    public function getOrderItemsByOrderId(int $orderId): ?array
    {
        $query = $this->_db->getQuery(true);
        $query->select('*')
            ->from('#__jshopping_order_item')
            ->where(
                $this->_db->quoteName('order_id') . ' = \'' . $orderId . '\''
            );
        $this->_db->setQuery($query);
        $record = $this->_db->loadObJectList();
        return !empty($record) ? $record : null;
    }

    /**
     * Обновляет значения полей в табличке товаров.
     *
     * @param int $orderItemId Id связанных сущностей заказа
     * @param array $fieldsData Массив с данными для обновления
     *
     * @return void
     */
    public function updateOrderItemByOrderItemId(int $orderItemId, array $fieldsData): void
    {
        $query = $this->_db->getQuery(true);
        $query->update('#__jshopping_order_item');
        foreach ($fieldsData as $name => $value) {
            $query->set($this->_db->quoteName($name) . ' = ' . $this->_db->quote($value));
        }
        $query->where($this->_db->quoteName('order_item_id') . ' = ' . (int)$orderItemId);
        $this->_db->setQuery($query);
        $this->_db->execute();
    }
}