<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Updater\ProjectStructure;

/**
 * Класс для записи настроек файлов и директорий проекта
 *
 * @package YooMoney\Updater\ProjectStructure
 */
class ProjectStructureWriter
{
    /**
     * Записывает структуру модуля в виде строки.
     *
     * @param DirectoryEntryInterface $directory Класс корневой директории с настройками файлов и директорий проекта
     * @return string
     */
    public function writeToString(DirectoryEntryInterface $directory): string
    {
        $result = [];
        foreach ($directory->getDirectoryEntries() as $entry) {
            $result[] = 'd:' . $entry->getProjectPath() . ':' . $entry->getRelativePath();
        }
        foreach ($directory->getFileEntries() as $entry) {
            $result[] = 'f:' . $entry->getProjectPath() . ':' . $entry->getRelativePath();
        }
        return implode("\n", $result);
    }
}
