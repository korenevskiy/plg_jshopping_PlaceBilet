<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Updater\ProjectStructure;

/**
 * Абстрактный класс файла или директории в проекте
 *
 * @package YooMoney\Updater\ProjectStructure
 */
abstract class AbstractEntry implements EntryInterface
{
    /** @var DirectoryEntryInterface|null Базовая директория проекта */
    private ?DirectoryEntryInterface $base;

    /** @var string Относительный путь до файла или директории внутри CMS */
    private string $relativePath;

    /** @var string Относительный путь до файла или директории внутри проекта */
    private string $projectPath;

    /**
     * Конструктор устанавливает базовую директорию и относительные пути
     *
     * @param DirectoryEntryInterface $base Базовая директория
     * @param string $relativePath Относительный путь до файла или дериктории внутри CMS
     * @param string $projectPath Относительный путь до файла или директории внутри проекта
     */
    public function __construct(DirectoryEntryInterface $base, string $relativePath, string $projectPath)
    {
        $this->base = $base;
        $this->relativePath = $relativePath;
        $this->projectPath = $projectPath;
    }

    /**
     * Проверяет, является ли текущий элемент файлом.
     *
     * @return bool True если текущий элемент файл, false если директория
     */
    public function isFile(): bool
    {
        return !$this->isDir();
    }

    /**
     * Возвращает полный путь до текущего элемента.
     *
     * @return string Полный путь до файла или директории в структуре CMS
     */
    public function getAbsolutePath(): string
    {
        return $this->base->getAbsolutePath() . '/' . $this->relativePath;
    }

    /**
     * Возвращает относительный путь до текущего элемента относительно корня CMS.
     *
     * @return string Относительный путь до файла или директории
     */
    public function getRelativePath(): string
    {
        return $this->relativePath;
    }

    /**
     * Возвращает относительный путь до файла относительно корня проекта в гитхабе.
     *
     * @return string Относительный путь в структуре проекта на гитхабе
     */
    public function getProjectPath(): string
    {
        return $this->projectPath;
    }
}
