<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Updater\ProjectStructure;

use RuntimeException;

/**
 * Класс для чтения настроек файлов и директорий проекта
 *
 * @package YooMoney\Updater\ProjectStructure
 */
class ProjectStructureReader
{
    /**
     * Читает настройки директорий и файлов проекта из файла.
     *
     * @param string $fileName Имя файла с настройками директорий и файлов
     * @param string $sourceDirectory Директория в которую данные загружаются в CMS
     *
     * @return RootDirectory Информация о директориях и файлах проекта
     */
    public function readFile(string $fileName, string $sourceDirectory): RootDirectory
    {
        $fd = fopen($fileName, 'rb');
        if (!$fd) {
            throw new RuntimeException('Failed to open file "' . $fileName . '"');
        }
        $root = $this->readContent(fread($fd, filesize($fileName)), $sourceDirectory);
        fclose($fd);
        return $root;
    }

    /**
     * Парсит настройки директорий и файлов проекта из строки.
     *
     * @param string $content Строка с настройками проекта
     * @param string $sourceDirectory Директория в которую данные загружаются в CMS
     *
     * @return RootDirectory Информация о директориях и файлах проекта
     */
    public function readContent(string $content, string $sourceDirectory): RootDirectory
    {
        $root = new RootDirectory($sourceDirectory);
        foreach (explode("\n", $content) as $line) {
            $line = rtrim($line, "\r");
            $entry = explode(':', $line);
            if ($entry[0] == 'b') {
                $root->setProjectPath($entry[1]);
                continue;
            }
            if (count($entry) < 2) {
                continue;
            }
            if (count($entry) == 2) {
                $entry[2] = $entry[1];
            }
            $entries = $this->parsePlaceholders($entry);
            $this->addEntries($root, $entries);
        }
        return $root;
    }

    /**
     * Добавляет в настройки проекта директории и файлы из массива настроек.
     *
     * @param RootDirectory $root Объект с информацией о директориях и файлах проекта
     * @param array $entries Массив с директориями и файлами проекта
     *
     * @return void
     */
    private function addEntries(RootDirectory $root, array $entries): void
    {
        foreach ($entries as $entry) {
            if (str_ends_with($entry[2], '/')) {
                $entry[2] .= pathinfo($entry[1], PATHINFO_BASENAME);
            }
            if ($entry[0] == 'f') {
                $root->factoryFile($entry[1], $entry[2]);
            } elseif ($entry[0] == 'd') {
                $root->factoryDirectory($entry[1], $entry[2]);
            }
        }
    }

    /**
     * На вход получает массив вида [<type>, <project_path>, <cms_path>], преобразует шаблоны вида {<path1>,<path2>} и
     * возвращает массив настроек файлов и директорий с готовыми именами файлов.
     *
     * @param array $entry Массив с настройками файла или директории
     *
     * @return array Массив с настройками файлов и директорий
     */
    private function parsePlaceholders(array $entry): array
    {
        if (!preg_match_all('/\{([^\}]+)\}/', $entry[1], $matches)) {
            return [$entry];
        }

        $previous = [];
        $replace = [];
        for ($index = count($matches[0]) - 1; $index >= 0; $index--) {
            $match = $matches[0][$index];
            $tmp = explode(',', $matches[1][$index]);
            $replace = [];
            foreach ($tmp as $rep) {
                if (!empty($previous)) {
                    foreach ($previous as $prev) {
                        $prev[$match] = $rep;
                        $replace[] = $prev;
                    }
                } else {
                    $replace[] = [
                        $match => $rep,
                    ];
                }
            }
            $previous = $replace;
        }
        $entries = [];
        foreach ($replace as $rep) {
            $entries[] = [
                $entry[0],
                strtr($entry[1], $rep),
                strtr($entry[2], $rep),
            ];
        }

        return $entries;
    }
}