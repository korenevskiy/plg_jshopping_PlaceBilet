<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Updater\ProjectStructure;

use RuntimeException;

/**
 * Класс вхождения директории в проект
 *
 * @package YooMoney\Updater\ProjectStructure
 */
class DirectoryEntry extends AbstractEntry implements DirectoryEntryInterface
{
    /** @var DirectoryEntryInterface[]|null Список поддиректории внутри текущей директории */
    private ?array $directories = [];

    /** @var FileEntryInterface[]|null Список файлов внутри текущей директории */
    private ?array $files = [];

    /**
     * Проверяет, является ли текущий элемент директорией.
     *
     * @return bool Возвращает true
     */
    public function isDir(): bool
    {
        return true;
    }

    /**
     * Возвращает список директорий внутри текущей директории.
     *
     * @return DirectoryEntryInterface[] Список поддиректорий
     */
    public function getDirectoryEntries(): array
    {
        if ($this->directories === null) {
            $this->walk($this->getAbsolutePath());
        }
        return $this->directories;
    }

    /**
     * Возвращает список файлов внутри текущей директории.
     *
     * @return FileEntryInterface[] Список файлов внутри директории
     */
    public function getFileEntries(): array
    {
        if ($this->files === null) {
            $this->walk($this->getAbsolutePath());
        }
        return $this->files;
    }

    /**
     * Осуществляет рекурсивный обход всех поддиректорий и заполняет списки директорий и файлов.
     *
     * @param string $directory Имя директории которую сканим
     * @param string $relativePath Относительный путь до директории
     * @param DirectoryEntry|null $parentDirectory Родительская директория в которой происходит парсин списка файлов
     *
     * @return void
     */
    private function walk(string $directory, string $relativePath = '', DirectoryEntry $parentDirectory = null): void
    {
        if (!file_exists($directory)) {
            throw new RuntimeException('Directory not exists: ' . $directory);
        }
        $dirHandle = opendir($directory);
        while (($entry = readdir($dirHandle)) !== false) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }
            $path = $directory . '/' . $entry;

            if (is_file($path)) {
                $file = new FileEntry($this, $relativePath . $entry, $this->getProjectPath() . '/' . $relativePath . $entry);
                if ($parentDirectory !== null) {
                    $parentDirectory->files[] = $file;
                }
                $this->files[] = $file;
            }

            if (is_dir($path)) {
                $dir = new DirectoryEntry($this, $relativePath . $entry, $this->getProjectPath() . '/' . $relativePath . $entry);
                if ($parentDirectory !== null) {
                    $parentDirectory->directories[] = $dir;
                }
                $this->directories[] = $dir;
                $this->walk($path, $relativePath . $entry . '/', $dir);
            }
        }
        closedir($dirHandle);
    }
}