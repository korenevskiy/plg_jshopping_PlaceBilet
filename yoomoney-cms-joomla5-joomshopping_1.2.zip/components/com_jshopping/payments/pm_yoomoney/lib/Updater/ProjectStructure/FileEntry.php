<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Updater\ProjectStructure;

/**
 * Класс вхождения файла в проект
 *
 * @package YooMoney\Updater\ProjectStructure
 */
class FileEntry extends AbstractEntry implements FileEntryInterface
{
    /** @var int|null Размер файла в байтах. */
    private ?int $fileSize = null;

    /**
     * Проверяет, является ли текущий элемент директорией.
     *
     * @return bool Возвращает false
     */
    public function isDir(): bool
    {
        return false;
    }

    /**
     * Возвращает размер файла в байтах.
     *
     * @return int Размер файла в байтах
     */
    public function getSize(): int
    {
        if ($this->fileSize === null) {
            $this->fileSize = filesize($this->getAbsolutePath());
        }
        return $this->fileSize;
    }
}
