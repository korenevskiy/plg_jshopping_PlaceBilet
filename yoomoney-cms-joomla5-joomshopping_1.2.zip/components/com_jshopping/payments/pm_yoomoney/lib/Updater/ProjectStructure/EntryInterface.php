<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Updater\ProjectStructure;

/**
 * Интерфейс файла или каталога проекта
 *
 * @package YooMoney\Updater\ProjectStructure
 */
interface EntryInterface
{
    /**
     * Проверяет, является ли текущий элемент директорией.
     *
     * @return bool True если текущий элемент директория, false если файл
     */
    function isDir(): bool;

    /**
     * Проверяет, является ли текущий элемент файлом.
     *
     * @return bool True если текущий элемент файл, false если директория
     */
    function isFile(): bool;

    /**
     * Возвращает полный путь до текущего элемента.
     *
     * @return string Полный путь до файла или директории в структуре CMS
     */
    function getAbsolutePath(): string;

    /**
     * Возвращает относительный путь до текущего элемента относительно корня CMS.
     *
     * @return string Относительный путь до файла или директории
     */
    function getRelativePath(): string;

    /**
     * Возвращает относительный путь до файла относительно корня проекта в гитхабе.
     *
     * @return string Относительный путь в структуре проекта на гитхабе
     */
    function getProjectPath(): string;
}
