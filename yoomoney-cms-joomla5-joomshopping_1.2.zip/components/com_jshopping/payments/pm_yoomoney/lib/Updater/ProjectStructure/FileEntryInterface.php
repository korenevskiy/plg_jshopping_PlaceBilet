<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Updater\ProjectStructure;

/**
 * Интерфейс файла проекта
 *
 * @package YooMoney\Updater\ProjectStructure
 */
interface FileEntryInterface extends EntryInterface
{
    /**
     * Возвращает размер файла в байтах.
     *
     * @return int Размер файла в байтах
     */
    function getSize(): int;
}
