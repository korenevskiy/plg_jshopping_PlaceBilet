<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Updater\Archive;

use Psr\Log\LoggerInterface;
use RuntimeException;
use YooMoney\Updater\ProjectStructure\DirectoryEntryInterface;
use YooMoney\Updater\ProjectStructure\EntryInterface;
use YooMoney\Updater\ProjectStructure\FileEntryInterface;
use YooMoney\Updater\ProjectStructure\ProjectStructureReader;
use YooMoney\Updater\ProjectStructure\RootDirectory;
use ZipArchive;

/**
 * Класс распаковки архива и встраивания его в CMS
 *
 * @package YooMoney\Updater\Archive
 */
class RestoreZip
{
    /** @var ZipArchive|null Инстанс архива */
    private ?ZipArchive $zip = null;

    /** @var LoggerInterface */
    private LoggerInterface $logger;

    /**
     * Конструктор, открывает архив
     *
     * @param string $fileName Имя файла архива
     * @param LoggerInterface|null $logger
     */
    public function __construct(string $fileName, LoggerInterface $logger = null)
    {
        if (!file_exists($fileName)) {
            throw new RuntimeException('Archive file "' . $fileName . '" not exists');
        }

        if (!is_file($fileName)) {
            throw new RuntimeException('Invalid archive file "' . $fileName . '"');
        }

        if (!is_readable($fileName)) {
            throw new RuntimeException('Archive file "' . $fileName . '" not readable');
        }
        $this->zip = new ZipArchive();
        $result = $this->zip->open($fileName);
        if ($result !== true) {
            throw new RuntimeException('Failed to open zip archive "' . $fileName . '"', $result);
        }
        $this->logger = $logger;
    }

    /**
     * Деструктор, закрывает файл архива, если он не закрыт.
     */
    public function __destruct()
    {
        if ($this->zip !== null) {
            $this->close();
        }
    }

    /**
     * Закрывает файл архива, если он не закрыт
     */
    public function close(): void
    {
        $this->zip->close();
        $this->zip = null;
    }

    /**
     * Восстанавливает файлы из архива.
     *
     * @param string $mapFileName Имя файла с настройками проекта внутри архива
     * @param string $destinationDirectory Корневая директория CMS в которую происходит распаковка файлов
     *
     * @return void
     */
    public function restore(string $mapFileName, string $destinationDirectory): void
    {
        if (!file_exists($destinationDirectory)) {
            $message = 'Create directory ' . $destinationDirectory . ' ... ';
            if (!mkdir($destinationDirectory)) {
                $this->logger->log('error', $message . ' failed');
                throw new RuntimeException('Failed to create destination directory "' . $destinationDirectory . '"');
            }
            $this->logger->log('info', $message . ' succeeded');
        }

        if (!is_dir($destinationDirectory)) {
            $this->logger->log('error', 'Invalid directory ' . $destinationDirectory . '"');
            throw new RuntimeException('Invalid destination directory "' . $destinationDirectory . '"');
        }

        if (!is_writable($destinationDirectory)) {
            $this->logger->log('error', 'Directory ' . $destinationDirectory . ' not writable');
            throw new RuntimeException('Destination directory "' . $destinationDirectory . '" not writable');
        }

        $directoryName = $mapFileName === 'file_map.map' ? $this->zip->getNameIndex(0) : '';
        $root = $this->factoryProject($mapFileName, $destinationDirectory);

        $directories = $this->prepareDirectories($root, $directoryName);
        if (!empty($directories)) {
            $this->restoreDirectories($directories);
        }

        foreach ($root->getFileEntries() as $entry) {
            $this->restoreFile($directoryName, $entry);
        }
    }

    /**
     * Создаёт из файла с настройками объект с настройками файлов и директорий.
     *
     * @param string $mapFileName Имя файла с настройками, который находится в архиве
     * @param string $destinationDirectory Корневая директория CMS
     *
     * @return DirectoryEntryInterface Объект с настройками файлов и директорий проекта
     */
    private function factoryProject(string $mapFileName, string $destinationDirectory): DirectoryEntryInterface
    {
        $content = '';
        for ($i = 0; $i < $this->zip->numFiles; $i++) {
            $name = $this->zip->getNameIndex($i);
            if ($mapFileName === pathinfo($name, PATHINFO_BASENAME)) {
                $content = $this->zip->getFromIndex($i);
                break;
            }
        }
        if (empty($content)) {
            throw new RuntimeException('Map file "' . $mapFileName . '" not found in archive');
        }
        $reader = new ProjectStructureReader();
        return $reader->readContent($content, $destinationDirectory);
    }

    /**
     * Пробегается по всем директориям проекта, проверяет их налилчие в архиве, создаёт в структуре проекта, если их
     * нет и возвращает массив всех директорий проекта в виде {"<archive_path>": DirectoryEntryInterface, ...}.
     *
     * @param DirectoryEntryInterface $root Настройки проекта
     * @param string $directoryName Имя корневой директории внутри архива
     *
     * @return DirectoryEntryInterface[] Список всех директорий проекта
     */
    private function prepareDirectories(DirectoryEntryInterface $root, string $directoryName): array
    {
        $directories = [];
        foreach ($root->getDirectoryEntries() as $entry) {
            if (DIRECTORY_SEPARATOR === '\\') {
                $path = str_replace(DIRECTORY_SEPARATOR, '/', $directoryName . $entry->getProjectPath()) . '/';
            } else {
                $path = $directoryName . $entry->getProjectPath() . '/';
            }
            $tmp = $this->zip->getFromName($path);
            if ($tmp === false) {
                throw new RuntimeException('Directory "' . $path . '" not exists in archive');
            }
            $this->prepareDirectory($entry->getAbsolutePath());
            $directories[$path] = $entry;
        }
        return $directories;
    }

    /**
     * Подготавливает директорию - создаёт рекурсивно нужные директории в структуре CMS.
     *
     * @param string $directory Полный путь до нужной директории
     *
     * @throws RuntimeException Выбрасывается если не удалось создать какую-либо директорию
     */
    private function prepareDirectory(string $directory): void
    {
        if (file_exists($directory)) {
            return;
        }

        $this->prepareDirectory(dirname($directory));
        $this->logger->log('info', 'Create directory ' . $directory);
        if (!mkdir($directory)) {
            $this->logger->log('error', 'Failed to create directory ' . $directory);
            throw new RuntimeException('Failed to create directory "' . $directory . '"');
        }
    }

    /**
     * Копирует содержимое переданных директорий в структуру CMS.
     *
     * @param DirectoryEntryInterface[] $directories Массив копируемых директорий
     */
    private function restoreDirectories(array $directories): void
    {
        for ($i = 0; $i < $this->zip->numFiles; $i++) {
            $name = $this->zip->getNameIndex($i);
            foreach ($directories as $dir => $entry) {
                if (strncmp($dir, $name, strlen($dir)) === 0 && $name !== $dir) {
                    $this->restoreDirectory($entry, $name, $dir, $i);
                }
            }
        }
    }

    /**
     * Восстанавливает поддиректорию или файл внутри директории.
     *
     * @param EntryInterface $entry Инстанс восстанавливаемого файла или директории
     * @param string $name Имя файла или директоии внутри архива
     * @param string $dir Имя директории в которой происходит работа
     * @param int $index Индекст текущего файла или директории в zip архиве
     *
     * @return void
     */
    private function restoreDirectory(EntryInterface $entry, string $name, string $dir, int $index): void
    {
        $path = substr($name, strlen($dir));
        $fileName = $entry->getAbsolutePath() . DIRECTORY_SEPARATOR . $path;

        if (str_ends_with($name, '/')) {
            $this->prepareDirectory($fileName);
            return;
        }

        $this->logger->log('info', 'Restore file ' . $fileName);
        $tmp = $this->zip->getFromIndex($index);
        if (!is_writable(dirname($fileName))) {
            throw new RuntimeException('Failed to create or open file "' . $fileName . '"');
        }
        $out = fopen($fileName, 'wb');
        if (!$out) {
            $this->logger->log('error', 'Restoration file ' . $fileName . ' failed');
            throw new RuntimeException('Failed to create or open file "' . $fileName . '"');
        }
        fwrite($out, $tmp);
        fclose($out);
    }

    /**
     * Восстанавливает файл из архива.
     *
     * @param string $rootDirectory Путь к корневой директории проекта внутри архива
     * @param FileEntryInterface $entry Восстанавливаемый файл
     *
     * @return void
     */
    private function restoreFile(string $rootDirectory, FileEntryInterface $entry): void
    {
        if (DIRECTORY_SEPARATOR === '\\') {
            $path = str_replace(DIRECTORY_SEPARATOR, '/', $rootDirectory . $entry->getProjectPath());
        } else {
            $path = $rootDirectory . $entry->getProjectPath();
        }
        $tmp = $this->zip->getFromName($path);
        if ($tmp === false) {
            throw new RuntimeException('File "' . $entry->getProjectPath() . '" not exists in archive');
        }
        $filePath = $entry->getAbsolutePath();
        if (file_exists($filePath)) {
            if (!is_file($filePath)) {
                throw new RuntimeException('Invalid file "' . $filePath . '"');
            } elseif (!is_writable($filePath)) {
                throw new RuntimeException('File "' . $filePath . '" not writable');
            }
        } else {
            $this->prepareDirectory(dirname($filePath));
        }
        $out = fopen($filePath, 'wb');
        if (!$out) {
            throw new RuntimeException('Failed to open file "' . $filePath . '"');
        }
        if (strlen($tmp) > 0) {
            fwrite($out, $tmp);
        }
        fclose($out);
    }
}
