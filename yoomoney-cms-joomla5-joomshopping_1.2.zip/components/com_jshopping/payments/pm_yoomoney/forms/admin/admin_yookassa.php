<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

use YooMoney\Model\KassaPaymentMethod;

defined('_JEXEC') or die('Restricted access');

/** @var array $params Настройки модуля оплаты */
/** @var string $yookassaNotifyUrl Новый адрес для уведомлений */
/** @var string $notifyUrl Дефолтный адрес для уведомлений */
/** @var \JModelLegacy $orders Модель заказа */
/** @var array $taxes Массив с налогами */
/** @var KassaPaymentMethod $kassa Класс методов для оплаты через ЮКассу */

JHtml::_('script', 'com_jshopping/yoomoney_oauth.js', ['version' => 'auto', 'relative' => true]);
JHtml::_('stylesheet', 'com_jshopping/yoomoney_oauth.css', ['version' => 'auto', 'relative' => true]);

echo JHtml::_('uitab.addTab', 'yamTab', 'kassa-tab', _JSHOP_YOO_TAB_KASSA);

?>
    <div class="row">
        <div class="col">
            <p><?php echo _JSHOP_YOO_LICENSE_TEXT; ?></p>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-3">
            <label class="form-check-label" for="kassa">
                <?php echo _JSHOP_YOO_KASSA_ON; ?>
            </label>
        </div>
        <div class="col-3">
            <div class="form-check">
                <input class="form-check-input pay-mode qa-enable-yookassa-checkbox"
                       type="checkbox"
                       id="kassa"
                       name="pm_params[kassamode]"
                       value="1"
                    <?php if (isSelected($params, 'kassamode')) {
                        echo "checked";
                    } ?> >
            </div>
        </div>
    </div>

    <div class="row  mb-3">
        <div class="col">
            <h4><?php echo _JSHOP_YOO_KASSA_HEAD_LK; ?></h4>
        </div>
    </div>

    <?php include(__DIR__ . '/oauth/oauth.php');

    if (isSelected($params, 'kassamode') && $kassa->isOauthAuthorization() && !$kassa->isConnectFailed()) : ?>
        <div class="row mb-3">
            <div class="col-3">
                <label for="pm_params[notification_url]">
                    <?php echo _JSHOP_YOO_NOTIFICATION_URL_LABEL; ?>
                </label>
            </div>

            <div class="col-9">
                <span><strong><?php echo _JSHOP_YOO_KASSA_URL_HELP_HEAD ?></strong><br>
                    <?php echo _JSHOP_YOO_KASSA_URL_HELP_TEXT ?>
                </span>
                <div class="input-group has-success">
                    <input type="text"
                           class="form-control valid form-control-success yookassa-notify-url"
                           name="pm_params[notification_url]"
                           id="pm_params[notification_url]"
                           value="<?= escapeValue($yookassaNotifyUrl) ?>"
                           aria-invalid="false"
                           <?php echo !isSelected($params, 'kassamode') ? 'disabled' : '' ?>
                    >
                </div>
                <span class="change_url_helper <?php echo $yookassaNotifyUrl !== $notifyUrl ? 'd-block' : 'd-none'?>">
                    <?php echo _JSHOP_YOO_KASSA_URL_DEFAULT . escapeValue($notifyUrl); ?>
                </span>
            </div>
            <div>
                <input type="hidden"
                        name="pm_params[yookassa_new_url]"
                        id="yookassa_new_url"
                        value="0"
                >
            </div>
        </div>
    <?php endif; ?>

    <div class="row  mb-3">
        <div class="col">
            <h4><?php echo _JSHOP_YOO_KASSA_PAYMODE_HEAD; ?></h4>
        </div>
    </div>

    <fieldset  class="row  mb-3">
        <legend class="col-form-label col-3 pt-0"><?php echo _JSHOP_YOO_KASSA_PAYMODE_LABEL; ?></legend>
        <div class="col-9">
            <div class="form-check">
                <input class="form-check-input paymode qa-payment-scenario-select"
                       type="radio"
                       name="pm_params[paymode]"
                       id="paymode-yookassa"
                       value="1"
                       onclick="yoomoney_validate_mode(1);"
                    <?php echo $params['paymode'] == 1 ? "checked" : '' ?>
                >
                <label class="form-check-label" for="paymode-yookassa">
                    <?php echo _JSHOP_YOO_KASSA_PAYMODE_KASSA; ?>
                </label>
            </div>
            <div class="with-kassa">
            </div>
            <div class="form-check">
                <input class="form-check-input paymode qa-payment-scenario-select"
                       type="radio"
                       name="pm_params[paymode]"
                       id="paymode-website"
                       value="2"
                       onclick="yoomoney_validate_mode(2);"
                    <?php echo $params['paymode'] == 2 ? "checked" : '' ?>
                >
                <label class="form-check-label" for="paymode-website">
                    <?php echo _JSHOP_YOO_KASSA_PAYMODE_SHOP; ?>
                </label>
                <div  class="form-text"><?php echo _JSHOP_YOO_KASSA_PAYMODE_LINK; ?></div>
            </div>
        </div>
    </fieldset>

    <div class="row mb-3 with-select">
        <div class="col-3">
            <label for="pm_params-shop-password">
                <?php echo _JSHOP_YOO_KASSA_SELECT_TEXT; ?>
            </label>
        </div>

        <div class="col-9">
        <?php foreach ($params['paymentMethodsKassa'] as $value) : ?>
            <div class="form-check">
                <input class="form-check-input input-kassa" type="checkbox" id="payment-method_<?php echo $value; ?>"
                       name="pm_params[method_yookassa_<?php echo $value; ?>]" value="1"
                    <?php echo $params['method_yookassa_'.$value] == '1' ? "checked" : '' ?>
                >
                <label class="form-check-label" for="payment-method_<?php echo $value; ?>">
                    <?php echo constant('_JSHOP_YOO_METHOD_'.strtoupper($value).'_DESCRIPTION'); ?>
                </label>
            </div>
        <?php endforeach; ?>
        </div>
    </div>

    <div class="row mb-3">
        <div class="col-3">
            <label for="yookassa_description_template">
                <?php echo _JSHOP_YOO_DESCRIPTION_TITLE; ?>
            </label>
        </div>

        <div class="col-9">
            <input name="pm_params[yookassa_description_template]" type="text" class="form-control"
                   id="yookassa_description_template"
                   value="<?= !empty($params['yookassa_description_template'])
                       ? $params['yookassa_description_template']
                       : _JSHOP_YOO_DESCRIPTION_DEFAULT_PLACEHOLDER; ?>"
            >
            <div  class="form-text"><?php echo _JSHOP_YOO_DESCRIPTION_HELP; ?></div>
        </div>
    </div>

    <div class="row mb-3">
        <div class="col-3">
            <label for="yookassa_enable_hold_mode">
                <?php echo _JSHOP_YOO_ENABLE_HOLD_MODE; ?>
            </label>
        </div>
        <div class="col-9">
            <div class="form-check">
                <input class="form-check-input input-kassa qa-enable-hold-control"
                       type="checkbox"
                       id="yookassa_enable_hold_mode"
                       name="pm_params[yookassa_enable_hold_mode]"
                       value="1"
                    <?= $params['yookassa_enable_hold_mode'] == '1' ? "checked" : ''; ?>
                >
            </div>
            <div  class="form-text"><?php echo _JSHOP_YOO_ENABLE_HOLD_MODE_HELP; ?></div>
            <div id="yookassa_enable_hold_mode_extended_settings">
                <div class="row mt-3 mb-0">
                    <p><?php echo _JSHOP_YOO_HOLD_MODE_STATUSES; ?></p>
                </div>
                <div class="row mb-3">
                    <div class="col-2">
                        <label for="yookassa_hold_mode_on_hold_status">
                            <?php echo _JSHOP_YOO_HOLD_MODE_ON_HOLD_STATUS; ?>
                        </label>
                    </div>
                    <div class="col-3">
                        <?= JHTML::_('select.genericlist', $orders->getAllOrderStatus(),
                            'pm_params[yookassa_hold_mode_on_hold_status]',
                            'class="form-select form-control form-select-sm qa-hold-status" size="1" data-type="kassa"', 'status_id',
                            'name', $params['yookassa_hold_mode_on_hold_status']); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-2">
                        <label for="yookassa_hold_mode_cancel_status">
                            <?php echo _JSHOP_YOO_HOLD_MODE_CANCEL_STATUS; ?>
                        </label>
                    </div>
                    <div class="col-3">
                        <?= JHTML::_('select.genericlist', $orders->getAllOrderStatus(),
                            'pm_params[yookassa_hold_mode_cancel_status]',
                            'class="form-select form-control form-select-sm qa-cancell-status" size="1" data-type="kassa"', 'status_id',
                            'name', $params['yookassa_hold_mode_cancel_status']); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <fieldset  class="row mb-3">
        <legend class="col-form-label col-3 pt-0"><?php echo _JSHOP_YOO_KASSA_SEND_RECEIPT_LABEL; ?></legend>
        <div class="col-9">
            <span class="<?php echo $kassa->isFiscalizationEnabled() && !$kassa->isSendReceipt() ? 'd-block' : 'd-none'; ?>">
                <strong><?php echo _JSHOP_YOO_KASSA_FISCALIZATION_HELP_HEAD; ?></strong><br>
                <strong><?php echo _JSHOP_YOO_KASSA_FISCALIZATION_HELP_TEXT_STRONG; ?></strong>
                <?php echo _JSHOP_YOO_KASSA_FISCALIZATION_HELP_TEXT; ?>
            </span>
            <div class="form-check">
                <input class="form-check-input yookassa_send_check qa-enable-receipt-control"
                       type="radio"
                       name="pm_params[yookassa_send_check]"
                       id="yookassa_send_check-enable"
                       value="1"
                       onclick="taxes_validate_mode(1)"
                    <?php echo $params['yookassa_send_check'] == '1' ? "checked" : '' ?>
                >
                <label class="form-check-label" for="yookassa_send_check-enable">
                    <?php echo _JSHOP_YOO_ENABLE; ?>
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input yookassa_send_check qa-enable-receipt-control"
                       type="radio"
                       name="pm_params[yookassa_send_check]"
                       id="yookassa_send_check-disable"
                       value="0"
                       onclick="taxes_validate_mode(0)"
                    <?php echo $params['yookassa_send_check'] == '0' ? "checked" : '' ?>
                >
                <label class="form-check-label" for="yookassa_send_check-disable">
                    <?php echo _JSHOP_YOO_DISABLE; ?>
                </label>
            </div>
            <div class="taxesArea">
                <div class="row mt-3">
                    <div class="col-auto">
                        <label for="pm_params[yookassa_default_tax]"
                               class="col-form-label"><?= _JSHOP_YOO_DEFAULT_TAX_LABEL; ?></label>
                    </div>
                    <div class="col-auto">
                        <select name="pm_params[yookassa_default_tax]" class="form-select form-control form-select-sm"
                                id="pm_params[yookassa_default_tax]">
                            <option <?php if ($params['yookassa_default_tax'] == 1) { ?> selected="selected" <?php } ?>
                                    value="1"><?= _JSHOP_YOO_WITHOUT_VAT ?></option>
                            <option <?php if ($params['yookassa_default_tax'] == 2) { ?> selected="selected" <?php } ?>
                                    value="2"><?= _JSHOP_YOO_VAT_0 ?></option>
                            <option <?php if ($params['yookassa_default_tax'] == 3) { ?> selected="selected" <?php } ?>
                                    value="3"><?= _JSHOP_YOO_VAT_10 ?></option>
                            <option <?php if ($params['yookassa_default_tax'] == 4) { ?> selected="selected" <?php } ?>
                                    value="4"><?= _JSHOP_YOO_VAT_20 ?></option>
                            <option <?php if ($params['yookassa_default_tax'] == 5) { ?> selected="selected" <?php } ?>
                                    value="5"><?= _JSHOP_YOO_VAT_10_100 ?></option>
                            <option <?php if ($params['yookassa_default_tax'] == 6) { ?> selected="selected" <?php } ?>
                                    value="6"><?= _JSHOP_YOO_VAT_20_120 ?></option>
                        </select>
                    </div>
                    <div class="form-text"><?php echo _JSHOP_YOO_DEFAULT_TAX_DESCRIPTION; ?></div>
                </div>
                <p class="mt-3 mb-1"><?= _JSHOP_YOO_TAX_RATES_LABEL ?>:</p>
                <div class="row mt-1 mb-1">
                    <div class="col-4">
                        <?= _JSHOP_YOO_TAX_IN_MODULE ?>:
                    </div>
                    <div class="col-4">
                        <?= _JSHOP_YOO_TAX_FOR_CHECKOUT ?>:
                    </div>
                </div>
                <?php foreach ($taxes as $k => $tax) { ?>
                    <div class="row mb-2">
                        <div class="col-4">
                            <label for="pm_params[yookassa_tax_<?php echo $k; ?>]" class=""><?php echo $tax; ?>%</label>
                        </div>
                        <div class="col-4">
                            <select id="pm_params[yookassa_tax_<?php echo $k; ?>]" name="pm_params[yookassa_tax_<?php echo $k; ?>]"
                                    class="form-select form-control form-select-sm">
                                <option <?php if ($params['yookassa_tax_' . $k] == 1) { ?> selected="selected" <?php } ?>
                                        value="1"><?= _JSHOP_YOO_WITHOUT_VAT ?></option>
                                <option <?php if ($params['yookassa_tax_' . $k] == 2) { ?> selected="selected" <?php } ?>
                                        value="2"><?= _JSHOP_YOO_VAT_0 ?></option>
                                <option <?php if ($params['yookassa_tax_' . $k] == 3) { ?> selected="selected" <?php } ?>
                                        value="3"><?= _JSHOP_YOO_VAT_10 ?></option>
                                <option <?php if ($params['yookassa_tax_' . $k] == 4) { ?> selected="selected" <?php } ?>
                                        value="4"><?= _JSHOP_YOO_VAT_20 ?></option>
                                <option <?php if ($params['yookassa_tax_' . $k] == 5) { ?> selected="selected" <?php } ?>
                                        value="5"><?= _JSHOP_YOO_VAT_10_100 ?></option>
                                <option <?php if ($params['yookassa_tax_' . $k] == 6) { ?> selected="selected" <?php } ?>
                                        value="6"><?= _JSHOP_YOO_VAT_20_120 ?></option>
                            </select>
                        </div>
                    </div>
                <?php } ?>
                <div class="row mt-4">
                    <div class="col-auto">
                        <label for="pm_params[yookassa_default_tax_system]"><?= _JSHOP_YOO_DEFAULT_TAX_SYSTEM_LABEL; ?></label>
                    </div>
                    <div class="col-auto">
                        <select name="pm_params[yookassa_default_tax_system]"
                                class="form-select form-control form-select-sm"
                                id="pm_params[yookassa_default_tax_system]">
                            <option value="">-</option>
                            <?php foreach (range(1, 6) as $tax_id) : ?>
                                <option <?php if ($params['yookassa_default_tax_system'] == $tax_id) { ?> selected="selected" <?php } ?>
                                        value="<?= $tax_id ?>"><?= constant("_JSHOP_YOO_DEFAULT_TAX_SYSTEM_{$tax_id}_LABEL") ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-text"><?php echo _JSHOP_YOO_DEFAULT_TAX_DESCRIPTION; ?></div>
                </div>
                <div class="row mt-4 mb-3">
                    <div class="col-auto">
                        <label for="pm_params[yookassa_default_payment_mode]"> <?php echo _JSHOP_YOO_KASSA_DEFAULT_PAYMENT_MODE_LABEL; ?></label>
                    </div>
                    <div class="col-auto">
                        <select name="pm_params[yookassa_default_payment_mode]"
                                class="form-select form-control form-select-sm"
                                id="pm_params[yookassa_default_payment_mode]">
                            <?php foreach ($params['paymentModeEnum'] as $key => $value): ?>
                                <option value="<?= $key ?>" <?= $params['yookassa_default_payment_mode'] == $key ? 'selected' : '' ?>><?= $value ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-auto">
                        <label for="pm_params[yookassa_default_payment_subject]"><?php echo _JSHOP_YOO_KASSA_DEFAULT_PAYMENT_SUBJECT_LABEL; ?></label>
                    </div>
                    <div class="col-auto">
                        <select name="pm_params[yookassa_default_payment_subject]"
                                class="form-select form-control form-select-sm"
                                id="pm_params[yookassa_default_payment_subject]">
                            <?php foreach ($params['paymentSubjectEnum'] as $key => $value): ?>
                                <option value="<?= $key ?>" <?= $params['yookassa_default_payment_subject'] == $key ? 'selected' : '' ?>><?= $value ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-auto">
                        <label for="pm_params[yookassa_default_delivery_payment_mode]"> <?php echo _JSHOP_YOO_KASSA_DEFAULT_DELIVERY_MODE_LABEL; ?></label>
                    </div>
                    <div class="col-auto">
                        <select name="pm_params[yookassa_default_delivery_payment_mode]"
                                class="form-select form-control form-select-sm"
                                id="pm_params[yookassa_default_delivery_payment_mode]">
                            <?php foreach ($params['paymentModeEnum'] as $key => $value): ?>
                                <option value="<?= $key ?>" <?= $params['yookassa_default_delivery_payment_mode'] == $key ? 'selected' : '' ?>><?= $value ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-auto">
                        <label for="pm_params[yookassa_default_delivery_payment_subject]"> <?php echo _JSHOP_YOO_KASSA_DEFAULT_DELIVERY_SUBJECT_LABEL; ?></label>
                    </div>
                    <div class="col-auto">
                        <select name="pm_params[yookassa_default_delivery_payment_subject]"
                                class="form-select form-control form-select-sm"
                                id="pm_params[yookassa_default_delivery_payment_subject]">
                            <?php foreach ($params['paymentSubjectEnum'] as $key => $value): ?>
                                <option value="<?= $key ?>" <?= $params['yookassa_default_delivery_payment_subject'] == $key ? 'selected' : '' ?>><?= $value ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="row mt-3 mb-3">
                    <div class="col-auto">
                        <label>
                            <?= _JSHOP_YOO_KASSA_SEND_SECOND_RECEIPT_LABEL ?>
                        </label>
                    </div>
                    <div class="col-auto">
                        <div class="form-check">
                            <input class="form-check-input qa-second-receipt-enable"
                                   name="pm_params[send_second_receipt]"
                                <?= $params['send_second_receipt'] ? "checked" : "" ?>
                                   type="radio" value="1" id="send_second_receipt-on"
                            >
                            <label class="form-check-label" for="send_second_receipt-on">
                                <?= _JSHOP_YOO_ENABLE ?>
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input qa-second-receipt-disable"
                                   name="pm_params[send_second_receipt]"
                                <?= $params['send_second_receipt'] ? "" : "checked" ?>
                                   type="radio" value="0" id="send_second_receipt-off"
                            >
                            <label class="form-check-label" for="send_second_receipt-off">
                                <?= _JSHOP_YOO_DISABLE ?>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="row mb-3 secondReceiptArea">
                    <div class="mb-3 form-text"><?php echo _JSHOP_YOO_KASSA_SEND_SECOND_RECEIPT_INFO; ?></div>
                    <div class="col-auto">
                        <label>
                            <?= _JSHOP_YOO_KASSA_SEND_SECOND_RECEIPT_STATUS_LABEL; ?>
                        </label>
                    </div>
                    <div class="col-auto">
                        <?php
                        print JHTML::_('select.genericlist', $orders->getAllOrderStatus(),
                            'pm_params[kassa_second_receipt_status]',
                            'class="form-select form-control form-select-sm qa-second-receipt-status-select" 
                            size="1" data-type="kassa"', 'status_id', 'name',
                            $params['kassa_second_receipt_status']);
                        ?>
                    </div>
                    <div class="mt-3 form-text"><?php echo _JSHOP_YOO_KASSA_SEND_SECOND_RECEIPT_HELP_BLOCK; ?></div>
                </div>
            </div>
        </div>
    </fieldset>

    <div class="row  mb-3">
        <div class="col">
            <h4><?php echo _JSHOP_YOO_COMMON_HEAD; ?></h4>
        </div>
    </div>

    <div class="row mb-3">
        <div class="col-3">
            <label for="yookassa_transaction_end_status">
                <?php echo _JSHOP_YOO_COMMON_STATUS; ?>
            </label>
        </div>

        <div class="col-9">
            <?php
            print JHTML::_('select.genericlist', $orders->getAllOrderStatus(),
                'pm_params[yookassa_transaction_end_status]',
                'class="transaction-end-status form-select form-control form-select-sm qa-order-end-status" size="1" data-type="kassa"', 'status_id', 'name',
                $params['yookassa_transaction_end_status']);
            ?>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-3">
            <label for="pm_params[debug_log]"><?php echo _JSHOP_YOO_KASSA_DEBUG ?></label>
        </div>
        <div class="col-9">
            <select class="form-select form-control form-select-sm" name="pm_params[debug_log]" id="pm_params[debug_log]">
                <option value="1"<?= $params['debug_log'] == '1' ? ' selected' : '' ?>><?= _JSHOP_YOO_ENABLE ?></option>
                <option value="0"<?= $params['debug_log'] == '1' ? '' : ' selected' ?>> <?= _JSHOP_YOO_DISABLE ?></option>
            </select>
            <div  class="mb-3 form-text">
                <a href="javascript://" id="show_module_log"><?= _JSHOP_YOO_LOG_VIEW_LABEL ?></a>
            </div>

        </div>
    </div>

    <div class="modal fade" id="log-modal-window" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title h4"><?= _JSHOP_YOO_LOGS_LABEL ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" style="overflow:auto;max-height:60vh;">
                    <div style="padding:10px;">
                        <pre id="logs-list"></pre>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger pull-left" id="clear-logs"><?= _JSHOP_YOO_CLEAR_LOGS ?></button>
                </div>
            </div>
        </div>
    </div>


<?php echo JHtml::_('uitab.endTab'); ?>