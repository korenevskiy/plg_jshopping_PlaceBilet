<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

defined('_JEXEC') or die('Restricted access');

/** @var array $params Настройки модуля оплаты */

/**
 * Проверяет, выбран ли способ оплаты через ЮКассу или ЮМани.
 *
 * @param array $params Сохраненные настройки модуля оплаты
 * @param string $type Тип оплаты
 *
 * @return bool
 */
function isSelected(array $params, string $type): bool
{
    $result = null;
    foreach (['kassamode', 'moneymode'] as $mode) {
        if ($mode === $type) {
            if (!empty($params[$mode]) && $params[$mode] == 1) {
                $result = true;
            }
        } elseif (!empty($params[$mode]) && $params[$mode] == 1) {
            $result = false;
            break;
        }
    }
    return $result === true;
}

/**
 * Экранирует переданное значение.
 *
 * @param string|null $value Переданное значение
 *
 * @return string
 */
function escapeValue(?string $value): string
{
    return htmlspecialchars($value);
}

?>
<div class="col100">
    <fieldset class="adminform">
        <p><?php echo _JSHOP_YOO_LICENSE_TEXT2; ?></p>
        <p><?php echo _JSHOP_YOO_VERSION_DESCRIPTION; ?><?php echo pm_yoomoney::_JSHOP_YOO_VERSION; ?></p>

        <?php echo JHtml::_('uitab.startTabSet', 'yamTab', ['active' => 'kassa-tab']); ?>

        <?php include(dirname(__FILE__) . '/admin_yookassa.php'); ?>

        <?php if (isset($newVersionInfo)) : ?>
            <?php include(dirname(__FILE__) . '/update/update.php'); ?>
        <?php else: ?>
            <?php include(dirname(__FILE__) . '/update/update_disable.php'); ?>
        <?php endif; ?>

        <input type="hidden" name="pm_params[transaction_end_status]" id="transaction-end-status"/>

        <?php echo JHtml::_('uitab.endTabSet'); ?>
    </fieldset>
</div>
<div class="clr"></div>
<script type="text/javascript">
    /**
     * Переключает отображение выбора способы оплаты (на стороне Юкассы или на стороне магазина)
     *
     * @param paymode Выбранный способ оплаты
     */
    function yoomoney_validate_mode(paymode) {
        jQuery(function ($) {
            if (paymode === 1) {
                $(".with-kassa").slideDown();
                $(".with-select").slideUp();
            } else {
                $(".with-kassa").slideUp();
                $(".with-select").slideDown();
            }
        });
    }

    /**
     * Отображает скрытые поля для настроек второго чека
     *
     * @param isShow Флаг включена ли отправка второго чека
     */
    function toggleShowSecondReceipt(isShow) {
        jQuery(function ($) {
            if (isShow == 1) {
                $(".secondReceiptArea").show();
            } else {
                $(".secondReceiptArea").hide();
            }
        });
    }

    /**
     * Отображает скрытые поля для настроек налогов
     *
     * @param paymode Выбранный способ оплаты
     */
    function taxes_validate_mode(paymode) {
        jQuery(function ($) {
            if (paymode === 1) {
                $(".taxesArea").slideDown();
            } else {
                $(".taxesArea").slideUp();
            }
        });
    }

    /**
     * Отображает скрытые поля для настроек отложенной оплаты
     */
    function yaKassaEnableHoldModeChangeHandler() {
        document.getElementById('yookassa_enable_hold_mode_extended_settings').style.display
            = document.getElementById('yookassa_enable_hold_mode').checked
            ? 'block'
            : 'none';
    }

    window.addEventListener('DOMContentLoaded', function () {
        yaKassaEnableHoldModeChangeHandler();
        document.getElementById('yookassa_enable_hold_mode').addEventListener("change", yaKassaEnableHoldModeChangeHandler);
        yoomoney_validate_mode(<?php if ($params['paymode'] == '1') echo "1"; ?>);
        taxes_validate_mode(<?php if ($params['yookassa_send_check'] == '1') echo "1"; ?>);
        const payModes = jQuery('.pay-mode');
        payModes.change(function () {
            if (this.checked) {
                const self = this;
                payModes.each(function () {
                    if (this !== self) {
                        this.checked = false;
                    } else {
                        const id = 'pm_paramsyoo' + this.getAttribute('id') + '_transaction_end_status';
                        document.getElementById('transaction-end-status').value = document.getElementById(id).value;
                    }
                });
            }
        });

        jQuery(function ($) {
            toggleShowSecondReceipt($("input[name='pm_params[send_second_receipt]']:checked").val());

            $("input[name='pm_params[send_second_receipt]']").on('change', function () {
                toggleShowSecondReceipt($(this).val());
            })
        });

        jQuery('.transaction-end-status').change(function () {
            const id = this.dataset.type;
            if (document.getElementById(id).checked) {
                document.getElementById('transaction-end-status').value = this.value;
            }
        });
        for (let i = 0; i < payModes.length; ++i) {
            if (payModes[i].checked) {
                const id = 'pm_paramsyoo' + payModes[i].getAttribute('id') + '_transaction_end_status';
                document.getElementById('transaction-end-status').value = document.getElementById(id).value;
            }
        }
        jQuery('#show_module_log').click(showLogsHandler);
        jQuery('#clear-logs').click(clearLogsHandler);

        jQuery('#adminForm > ul.nav-tabs a:last').tab('show');
    });

    jQuery('input[name="pm_params[method_widget]"]').change(function () {
        if (jQuery(this).prop('checked') === true) {
            installWidgetHandler();
        }
    })

    /**
     * Закрывает окно с журналом логов
     */
    function closeModalLog() {
        jQuery('#log-modal-window').modal('hide');
    }

    /**
     * Открывает окно с журналом логов
     */
    function showLogsHandler() {
        const form = document.getElementById('adminForm');
        const paymentId = form.payment_id.value;
        jQuery.ajax({
            method: 'GET',
            url: 'index.php',
            data: {
                option: 'com_jshopping',
                controller: 'payments',
                task: 'edit',
                payment_id: paymentId,
                subaction: 'get_log_messages'
            },
            dataType: 'json',
            success: function (logs) {
                if (logs.length > 0) {
                    jQuery('#logs-list').html(logs.join("\n"));
                    jQuery('#clear-logs').css('display', 'block');
                } else {
                    jQuery('#logs-list').html('Сообщений нет');
                    jQuery('#clear-logs').css('display', 'none');
                }
                jQuery('#log-modal-window').modal('show');
            }
        });
    }

    /**
     * Очищает журнал логов
     */
    function clearLogsHandler() {
        const form = document.getElementById('adminForm');
        const paymentId = form.payment_id.value;

        if (window.confirm('Вы действительно хотите очистить журнал сообщений?')) {
            jQuery.ajax({
                method: 'GET',
                url: 'index.php',
                data: {
                    option: 'com_jshopping',
                    controller: 'payments',
                    task: 'edit',
                    payment_id: paymentId,
                    subaction: 'clear_log_messages'
                },
                dataType: 'json',
                success: function () {
                    jQuery('#log-modal-window').modal('hide');
                }
            });
        }
    }
</script>