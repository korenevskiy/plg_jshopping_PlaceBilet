<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

defined('_JEXEC') or die('Restricted access');

/** @var bool $zipEnabled Флаг доступности функции распаковки zip архива */
/** @var bool $curlEnabled Флаг доступности функции инициализации сеанса cURL */

echo JHtml::_('uitab.addTab', 'yamTab', 'updater-tab', 'Обновления');

?>

    <div class="row">
        <div class="span11 offset1">
            <h4><?= _JSHOP_YOO_UPDATER_TEXT_HEADER ?></h4>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <p>
                <?= _JSHOP_YOO_UPDATER_ABOUT_TEXT ?>
            </p>
            <p>
                <?= _JSHOP_YOO_UPDATER_DISABLED_TEXT ?>
                <?php if (!$zipEnabled && !$curlEnabled): ?>
                    <?= _JSHOP_YOO_UPDATER_CAUSE_ZIP_CURL ?>
                <?php elseif (!$zipEnabled) : ?>
                    <?= _JSHOP_YOO_UPDATER_CAUSE_ZIP ?>
                <?php elseif (!$curlEnabled) : ?>
                    <?= _JSHOP_YOO_UPDATER_CAUSE_CURL ?>
                <?php endif; ?>
            </p>
        </div>
    </div>
<?php echo JHtml::_('uitab.endTab'); ?>