<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

use YooMoney\Model\KassaPaymentMethod;

defined('_JEXEC') or die('Restricted access');

/** @var array $params Настройки модуля оплаты */
/** @var KassaPaymentMethod $kassa Класс методов для оплаты через ЮКассу */
/** @var string $isDisabledClass Строка с disabled классом или пустой строкой */
?>

<div class="row mb-3 qa-oauth-info">
    <?php if ($kassa->isAuthorization() && $kassa->isConnectFailed()) : ?>
        <div class="col-12">
            <div class="alert alert-danger" role="alert">
                <strong><?php echo _JSHOP_YOO_AUTHORIZATION_TITLE_ERROR; ?></strong><br>
                <?php echo _JSHOP_YOO_AUTHORIZATION_TEXT_ERROR; ?>
            </div>
            <button class="btn btn-warning btn-oauth-connect offset-top-10 qa-yookassa-entrance <?php echo $isDisabledClass ?>"><?php echo _JSHOP_YOO_OAUTH_BTN_RECONNECT; ?></button>
        </div>
    <?php endif; ?>

    <?php if ($kassa->isOauthAuthorization() && !$kassa->isConnectFailed()) : ?>
        <?php if ($kassa->isSberLoanAvailable()) : ?>
            <div class="col-12">
                <div class="alert alert-warning offset-top-10" role="alert">
                    <strong><?php echo _JSHOP_YOO_SBER_LOAN_WARNING_TITLE; ?></strong>
                    <p><?php echo _JSHOP_YOO_SBER_LOAN_WARNING_TEXT; ?></p>
                    <p><?php echo _JSHOP_YOO_SBER_LOAN_WARNING_TEXT_INSTRUCTION; ?></p>
                </div>
            </div>
        <?php endif; ?>
        <div class="col-12">
            <?php if (isSelected($params, 'kassamode')) : ?>
                <span class="qa-shop-type"
                      data-qa-shop-type="<?php echo $kassa->isTest() ? 'test' : 'prod'; ?>">
                    <?php echo $kassa->isTest() ? _JSHOP_YOO_KASSA_TEST_STORE : _JSHOP_YOO_KASSA_REAL_STORE; ?>
                </span>
                <br>
            <?php endif; ?>
            <span class="qa-shop-id"
                  data-qa-shop-id="<?php echo escapeValue($kassa->getShopId()) ?>">
                <?php echo _JSHOP_YOO_KASSA_SHOP_ID_LABEL . ': ' . escapeValue($kassa->getShopId()); ?>
            </span>
            <?php if ($kassa->isTest()) : ?>
                <br>
                <span>
                    <strong><?php echo _JSHOP_YOO_KASSA_TEST_SHOP_HELP_HEAD ?></strong><br>
                    <?php echo _JSHOP_YOO_KASSA_TEST_SHOP_HELP_TEXT ?>
                </span>
            <?php endif; ?>
        </div>
        <div class="col-12">
            <button class="btn btn-warning btn-oauth-connect offset-top-10 qa-change-shop-button <?php echo $isDisabledClass ?>">
                <?php echo _JSHOP_YOO_OAUTH_BTN_CHANGE; ?>
            </button>
        </div>
    <?php endif; ?>

    <?php if (!$kassa->isAuthorization()) : ?>
        <div class="col-2">
            <button class="btn btn-warning btn-oauth-connect offset-top-10 qa-connect-shop-button <?php echo $isDisabledClass ?>"><?php echo _JSHOP_YOO_OAUTH_BTN_CONNECT; ?></button>
        </div>
    <?php endif; ?>

    <div class="col-12">
        <div class="alert alert-danger connect-error d-none offset-top-10"
             role="alert"><?php echo _JSHOP_YOO_OAUTH_CONNECT_ERROR; ?></div>
    </div>
</div>