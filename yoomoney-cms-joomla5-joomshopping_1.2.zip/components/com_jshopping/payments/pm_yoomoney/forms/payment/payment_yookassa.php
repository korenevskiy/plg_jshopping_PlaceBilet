<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

use YooKassa\Model\Payment\PaymentMethodType;
use Joomla\Component\Jshopping\Site\Model\CartModel;

defined('_JEXEC') or die('Restricted access');

/** @var array $pmConfigs Настройки модуля оплаты */
/** @var array $yookassaMethods Массив доступных методов для оплаты через ЮКассу */
/** @var CartModel $cartData Модель корзины */

if ($pmConfigs['paymode'] != '1') : ?>
    <table class="radio" style="margin-left: 50px;">
        <tbody>
        <?php
        $num = 0;
        foreach ($yookassaMethods as $name) :
            if (isset($pmConfigs['method_yookassa_' . $name]) && $pmConfigs['method_yookassa_' . $name] == '1') :
                $num += 1; ?>
                <tr class="highlight">
                    <td>
                        <input type="radio" name="params[pm_yoomoney][payment_type]" value="<?php echo $name; ?>"
                            <?php echo($num == 1 ? ' checked' : ''); ?> id="yoomoney_<?php echo $name; ?>"/>
                    </td>
                    <td>
                        <img src="<?php echo JURI::root(); ?>components/com_jshopping/images/yoomoney/<?php echo strtolower($name); ?>.png"
                             alt="<?php echo strtolower($name); ?>">
                    </td>
                    <td>
                        <label for="yoomoney_<?php echo $name; ?>"><?php echo constant('_JSHOP_YOO_METHOD_' . strtoupper($name) . '_DESCRIPTION_PUBLIC'); ?></label>
                    </td>
                </tr>
            <?php endif;
        endforeach;
        ?>
        </tbody>
    </table>
<?php else : ?>
    <input type="hidden" name="params[pm_yoomoney][payment_type]" value="" id="pm_yoomoney_payment_type"/>
<?php endif; ?>
<script type="text/javascript">
    /**
     * Отправляет данные с формы
     */
    function check_pm_yoomoney() {
        document.getElementById('payment_form').submit();
    }
</script>
