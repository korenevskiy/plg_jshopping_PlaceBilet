<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

/** @var string $token Токен для оплаты */
/** @var string $returnUrl URL, на который вернется пользователь после подтверждения или отмены платежа */

?>
<script src="https://yookassa.ru/checkout-widget/v1/checkout-widget.js"></script>
<script>
    const checkout = new window.YooMoneyCheckoutWidget({
        __checkoutWidgetAPIHost: 'https://yookassa.ru',
        confirmation_token: '<?= $token; ?>',
        return_url: '<?= $returnUrl; ?>',
        error_callback: function (error) {
            if (error.error === 'token_expired') {
                document.location.redirect('<?= $returnUrl; ?>');
            }
            console.log(error);
        }
    });
</script>

<div id="yoo-widget-checkout-ui" style="margin-top: 20px"></div>
<button onclick="history.go(-1);" class="a_checkout_back_button btn"><?= constant("_JSHOP_YOO_BTN_BACK") ?></button>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        checkout.render('yoo-widget-checkout-ui');
    });
</script>