<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

use YooKassa\Model\Notification\AbstractNotification;
use YooKassa\Model\Payment\Confirmation\ConfirmationEmbedded;
use YooKassa\Model\Payment\Confirmation\ConfirmationRedirect;
use YooKassa\Model\Payment\PaymentMethodType;
use YooKassa\Model\Receipt\PaymentMode;
use YooKassa\Model\Receipt\PaymentSubject;
use YooKassa\Request\Payments\CreatePaymentResponse;
use YooMoney\Helpers\DatabaseHelper;
use YooMoney\Helpers\OauthHelpers\HttpClient;
use YooMoney\Helpers\OauthHelpers\OauthDataStorageHelper;
use YooMoney\Helpers\OauthHelpers\OauthWebhooksHelper;
use YooMoney\Helpers\OauthHelpers\YookassaShopInfoHelper;
use YooMoney\Helpers\StorageHelper;
use YooMoney\Model\OrderModel;
use YooMoney\Model\OauthModel;
use YooMoney\Model\KassaPaymentMethod;
use YooMoney\Helpers\YookassaClientFactory;
use YooMoney\Helpers\ReceiptHelper;
use YooMoney\Helpers\LoggerHelper;
use YooMoney\Helpers\NotificationHelper;
use YooMoney\Helpers\JVersionDependenciesHelper;
use YooMoney\Helpers\YookassaNotificationFactory;
use YooMoney\Updater\Archive\BackupZip;
use YooMoney\Updater\Archive\RestoreZip;
use YooMoney\Updater\BitbucketConnector;
use YooMoney\Updater\ProjectStructure\ProjectStructureReader;
use Joomla\Component\Jshopping\Site\Model\CartModel;
use Joomla\Component\Jshopping\Site\Table\OrderTable;
use Joomla\CMS\Application\SiteApplication;

defined('_JEXEC') or die('Restricted access');

!defined('JSH_DIR') && define('JSH_DIR', realpath(dirname(__FILE__) . '/../..'));

/** Путь до директории для скаченного модуля */
const DIR_DOWNLOAD = JSH_DIR . '/log';

require_once dirname(__FILE__) . '/lib/autoload.php';

/**
 * Класс модуля ЮМани
 */
class pm_yoomoney extends PaymentRoot
{
    /** Версия модуля */
    public const _JSHOP_YOO_VERSION = '1.2.0';

    /** Отключены все способы оплаты */
    public const MODE_OFF = 0;

    /** Оплата через ЮКассу */
    public const MODE_KASSA = 1;

    /** Минимальная сумма платежа при оплате через "Покупки в кредит от Сбера" */
    public const PAYMENT_METHOD_SBER_LOAN_MIN_AMOUNT = 3000;

    /** Максимальная сумма платежа при оплате через "Покупки в кредит от Сбера" */
    public const PAYMENT_METHOD_SBER_LOAN_MAX_AMOUNT = 600000;

    /** @var int Режим оплаты */
    private int $mode = self::MODE_OFF;

    /** @var bool Режим логирования */
    private bool $debugLog = true;

    /** @var array Данные формы */
    private array $formParams = [];

    /** @var string Название модуля */
    private string $element = 'pm_yoomoney';

    /** @var string Путь до модуля в репозитории git.yoomoney.ru */
    private string $repository = 'cms/repos/cms-joomla5-joomshopping';

    /** @var string Название директории в cms для модуля */
    private string $downloadDirectory = 'pm_yoomoney';

    /** @var string Путь в cms для хранения бекапов модуля */
    private string $backupDirectory = 'pm_yoomoney/backups';

    /** @var string Путь в cms для хранения скаченных версий модуля */
    private string $versionDirectory = 'pm_yoomoney/download';

    /** @var LoggerHelper Класс методов для работы с логами модуля */
    private LoggerHelper $logger;

    /** @var NotificationHelper Класс методов для работы для обработки входящих уведомлений от Юkassa */
    private NotificationHelper $notificationHelper;

    /** @var JVersionDependenciesHelper Класс для совместимости модуля */
    private JVersionDependenciesHelper $versionHelper;

    /** @var YookassaNotificationFactory Класс-фабрика для получения объекта уведомления от Юkassa */
    private YookassaNotificationFactory $yooNotificationHelper;

    /** @var array Отключенные способы оплаты */
    private static array $disabledPaymentMethods = [
        PaymentMethodType::B2B_SBERBANK,
        PaymentMethodType::MOBILE_BALANCE,
    ];

    /** @var array Дополнительные методы оплаты */
    private static array $customPaymentMethods = [
        'widget',
    ];

    /** @var KassaPaymentMethod Класс методов для оплаты через ЮКассу */
    private KassaPaymentMethod $kassa;

    /** @var ReceiptHelper Класс методов для работы с чеками */
    private ReceiptHelper $receiptHelper;

    /** @var StorageHelper Класс методов для подготовки и работы с данными */
    private StorageHelper $storageHelper;

    /**
     * Конструктор pm_yoomoney.
     */
    public function __construct()
    {
        $this->versionHelper = new JVersionDependenciesHelper();
        $this->logger = new LoggerHelper();
        $this->notificationHelper = new NotificationHelper();
        $this->yooNotificationHelper = new YookassaNotificationFactory();
        $this->receiptHelper = new ReceiptHelper();
        $this->storageHelper = new StorageHelper();
    }

    /**
     * Получение сохраненных параметров оплаты. Расширение метода из класса PaymentRoot.
     *
     * @return bool
     */
    public function getSavePaymentParams(): bool
    {
        return true;
    }

    /**
     * Отображает форму оплаты. Шаг 3. Расширение метода из класса PaymentRoot.
     *
     * @param array $params Массив параметров, указанных в params[pm_yoomoney] на странице выбора способа оплаты
     * @param array $pmConfigs Настройки модуля оплаты
     *
     * @return void
     */
    public function showPaymentForm($params, $pmConfigs): void
    {
        $this->loadLanguageFile();
        $this->mode = $this->getMode($pmConfigs);

        if ($this->mode === self::MODE_KASSA) {
            $yookassaMethods = self::getKassaPaymentMethods();
            $cartData = JSFactory::getModel('cart', 'jshop');
            $cartData->load();
            include(dirname(__FILE__) . "/forms/payment/payment_yookassa.php");
        }
    }

    /**
     * Отображение списка параметров для заказа. Расширение метода из класса PaymentRoot.
     *
     * @return array
     */
    public function getDisplayNameParams(): array
    {
        return [];
    }

    /**
     * Проверяет параметры указанные пользователем на странице выбора способа оплаты. Расширение метода из класса PaymentRoot.
     *
     * @param array $params Массив параметров, указанных в params[pm_yoomoney] на странице выбора способа оплаты
     * @param array $pmConfigs Настройки модуля оплаты
     *
     * @return bool True если все параметры вылидны, false если нет
     */
    public function checkPaymentInfo($params, $pmConfigs): bool
    {
        $this->loadLanguageFile();
        $this->mode = $this->getMode($pmConfigs);

        if ($this->mode === self::MODE_OFF) {
            $this->log('error', 'Please activate payment method');
            $this->setErrorMessage(_JSHOP_ERROR_PAYMENT);

            return false;
        }

        if ($this->mode === self::MODE_KASSA) {
            // если оплата через кассу, то должен быть указан способ оплаты
            $paymentType = $params['payment_type'] ?? '';

            if (empty($paymentType) && $pmConfigs['paymode'] == '1') {
                return true;
            }

            if (!in_array($paymentType, self::getKassaPaymentMethods())) {
                return false;
            }

            return true;
        }

        return true;
    }

    /**
     * Генерация и отображение админ формы. Расширение метода из класса PaymentRoot.
     * Расширение метода из класса PaymentRoot.
     *
     * @param array|string $params Настройки модуля оплаты
     *
     * @return void
     * @throws Exception
     */
    public function showAdminFormParams($params): void
    {
        $this->loadLanguageFile();
        $this->installExtension();

        if (isset($_GET['subaction'])) {
            $this->formParams = $params;
            $this->checkSubaction();
        }

        $array_params = [
            'kassamode',
            'paymode',
            'yookassa_description_template',
            'yookassa_send_check',
            'yookassa_default_tax',
            'yookassa_default_tax_system',
            'yookassa_default_payment_mode',
            'yookassa_default_payment_subject',
            'yookassa_default_delivery_payment_mode',
            'yookassa_default_delivery_payment_subject',
            'yookassa_enable_hold_mode',
            'yookassa_hold_mode_on_hold_status',
            'yookassa_hold_mode_cancel_status',
            'yookassa_transaction_end_status',
            'method_yookassa_yoo_money',
            'method_yookassa_bank_card',
            'method_yookassa_cash',
            'method_yookassa_sberbank',
            'method_yookassa_mobile_balance',
            'method_yookassa_b2b_sberbank',
            'method_yookassa_tinkoff_bank',
            'method_yookassa_psb',
            'method_yookassa_sbp',
            'method_yookassa_sber_loan',
            'method_yookassa_widget',
            'shop_id',
            'transaction_end_status',
            'debug_log',
            'access_token',
            'state',
            'expires_in',
            'send_second_receipt'
        ];

        $paymentModeEnum = [
            PaymentMode::FULL_PREPAYMENT => _JSHOP_YOO_KASSA_PAYMENT_MODE_FULL_PREPAYMENT,
            PaymentMode::PARTIAL_PREPAYMENT => _JSHOP_YOO_KASSA_PAYMENT_MODE_PARTIAL_PREPAYMENT,
            PaymentMode::ADVANCE => _JSHOP_YOO_KASSA_PAYMENT_MODE_ADVANCE,
            PaymentMode::FULL_PAYMENT => _JSHOP_YOO_KASSA_PAYMENT_MODE_FULL_PAYMENT,
            PaymentMode::PARTIAL_PAYMENT => _JSHOP_YOO_KASSA_PAYMENT_MODE_PARTIAL_PAYMENT,
            PaymentMode::CREDIT => _JSHOP_YOO_KASSA_PAYMENT_MODE_CREDIT,
            PaymentMode::CREDIT_PAYMENT => _JSHOP_YOO_KASSA_PAYMENT_MODE_CREDIT_PAYMENT,
        ];

        $paymentSubjectEnum = [
            PaymentSubject::COMMODITY => _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_COMMODITY,
            PaymentSubject::EXCISE => _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_EXCISE,
            PaymentSubject::JOB => _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_JOB,
            PaymentSubject::SERVICE => _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_SERVICE,
            PaymentSubject::GAMBLING_BET => _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_GAMBLING_BET,
            PaymentSubject::GAMBLING_PRIZE => _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_GAMBLING_PRIZE,
            PaymentSubject::LOTTERY => _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_LOTTERY,
            PaymentSubject::LOTTERY_PRIZE => _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_LOTTERY_PRIZE,
            PaymentSubject::INTELLECTUAL_ACTIVITY => _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_INTELLECTUAL_ACTIVITY,
            PaymentSubject::PAYMENT => _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_PAYMENT,
            PaymentSubject::AGENT_COMMISSION => _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_AGENT_COMMISSION,
            PaymentSubject::COMPOSITE => _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_COMPOSITE,
            PaymentSubject::ANOTHER => _JSHOP_YOO_KASSA_PAYMENT_SUBJECT_ANOTHER,
        ];

        if (!is_array($params)) {
            $params = [];
        }

        $params['paymentModeEnum'] = $paymentModeEnum;
        $params['paymentSubjectEnum'] = $paymentSubjectEnum;
        $params['paymentMethodsKassa'] = self::getKassaPaymentMethods();

        $taxes = JSFactory::getAllTaxes();

        foreach ($taxes as $k => $tax) {
            $array_params[] = 'yookassa_tax_' . $k;
        }

        foreach ($array_params as $key) {
            if (!isset($params[$key])) {
                $params[$key] = '';
            }
        }
        if (!isset($params['use_ssl'])) {
            $params['use_ssl'] = 0;
        }

        $orders = JModelLegacy::getInstance('orders', 'JshoppingModel'); //admin model

        $zipEnabled = function_exists('zip_open');
        $curlEnabled = function_exists('curl_init');
        if ($zipEnabled && $curlEnabled) {
            $versionInfo = $this->checkModuleVersion(false);
            $newVersionAvailable = false;
            $changelog = '';
            $newVersion = self::_JSHOP_YOO_VERSION;
            if (version_compare($versionInfo['version'], self::_JSHOP_YOO_VERSION) > 0) {
                $newVersionAvailable = true;
                $changelog = $this->getChangeLog(self::_JSHOP_YOO_VERSION, $versionInfo['version']);
                $newVersion = $versionInfo['version'];
            }
            $newVersionInfo = $versionInfo;
            $backups = $this->getBackupList();
        }

        $kassa = $this->getKassaPaymentMethod($params);
        $kassa->setShopAndWebhooksInfo();
        $yookassaNotifyUrl = $kassa->getNotificationUrl();

        $uri = JURI::getInstance();
        $sslUrlHost = $uri->toString(['host', 'port']);

        $notifyUrl = 'https://' . $sslUrlHost . \JSHelper::SEFLink("index.php?option=com_jshopping&controller=checkout&task=step7&act=notify&js_paymentclass=pm_yoomoney&no_lang=1");
        $notifyUrl = htmlspecialchars_decode($notifyUrl);

        $isDisabledClass = !$kassa->getKassaMode() ? 'disabled' : '';

        include(dirname(__FILE__) . "/forms/admin/admin.php");
    }

    /**
     * Отрисовка логов.
     *
     * @return void
     */
    public function viewModuleLogs(): void
    {
        $fileName = $this->getLogFileName();
        $fd = @fopen($fileName, 'r');
        $logs = [];
        if ($fd) {
            flock($fd, LOCK_SH);
            $size = filesize($fileName);
            if ($size > 0) {
                $logs = array_map('trim', explode("\n", fread($fd, $size)));
            }
            flock($fd, LOCK_UN);
            fclose($fd);
        }
        $this->sendResponseJson($logs);
    }

    /**
     * Очистка файла с логами.
     *
     * @return void
     */
    public function clearModuleLogs(): void
    {
        $fileName = $this->getLogFileName();
        $fd = @fopen($fileName, 'w');
        $success = false;
        if ($fd) {
            flock($fd, LOCK_SH);
            flock($fd, LOCK_UN);
            fclose($fd);
            $success = true;
        }
        $this->sendResponseJson(['success' => $success]);
    }

    /**
     * Возвращает путь к файлу лога.
     *
     * @return string
     */
    private function getLogFileName(): string
    {
        return $this->logger->getLogFileName();
    }

    /**
     * Восстанавливает резервную копию.
     *
     * @return array
     */
    private function restoreBackup(): array
    {
        $this->loadLanguageFile();
        if (empty($_POST['file_name'])) {
            return [
                'message' => _JSHOP_YOO_UPDATER_ERROR_REMOVE,
                'success' => false,
            ];
        }

        $fileName = DIR_DOWNLOAD . '/' . $this->backupDirectory . '/' . $_POST['file_name'];
        if (!file_exists($fileName)) {
            $this->log('error', 'File "' . $fileName . '" not exists');

            return [
                'message' => 'Файл резервной копии ' . $fileName . ' не найден',
                'success' => false,
            ];
        }

        try {
            $sourceDirectory = dirname(realpath(JSH_DIR), 2);
            $archive = new RestoreZip($fileName);
            $archive->restore('file_map.map', $sourceDirectory);
        } catch (Exception $e) {
            $this->log('error', $e->getMessage());
            $this->log('error', $e->getPrevious()?->getMessage());

            return [
                'message' => _JSHOP_YOO_UPDATER_ERROR_RESTORE . $e->getMessage(),
                'success' => false,
            ];
        }

        return [
            'message' => _JSHOP_YOO_UPDATER_SUCCESS_MESSAGE . $_POST['file_name'],
            'success' => true,
        ];

    }

    /**
     * Удаляет резервную копию.
     *
     * @return array
     */
    public function removeBackup(): array
    {
        $this->loadLanguageFile();
        if (empty($_POST['file_name'])) {
            return [
                'message' => _JSHOP_YOO_UPDATER_ERROR_REMOVE,
                'success' => false,
            ];
        }

        $fileName = DIR_DOWNLOAD . '/' . $this->backupDirectory . '/' . str_replace(['/', '\\'], ['', ''],
                $_POST['file_name']);
        if (!file_exists($fileName)) {
            $this->log('error', 'File "' . $fileName . '" not exists');

            return [
                'message' => sprintf(_JSHOP_YOO_ERROR_BACKUP_NOT_FOUND, $fileName),
                'success' => false,
            ];
        }

        if (!unlink($fileName) || file_exists($fileName)) {
            $this->log('error', 'Failed to unlink file "' . $fileName . '"');

            return [
                'message' => _JSHOP_YOO_ERROR_REMOVE_BACKUP . $fileName,
                'success' => false,
            ];
        }

        return [
            'message' => sprintf(_JSHOP_YOO_SUCCESS_REMOVE_BECKUP, $fileName),
            'success' => true,
        ];
    }

    /**
     * Проверяет наличие новой версии, создает бекап и разворачивает новую версию модуля.
     *
     * @return array
     */
    public function updateVersion(): array
    {
        $this->loadLanguageFile();
        $versionInfo = $this->checkModuleVersion(false);
        $fileName = $this->downloadLastVersion($versionInfo['tag']);

        if (empty($fileName)) {
            return [
                'message' => _JSHOP_YOO_ERROR_DOWNLOAD_NEW_VERSION,
                'success' => false,
            ];
        }

        if (!$this->createBackup(self::_JSHOP_YOO_VERSION)) {
            return [
                'message' => _JSHOP_YOO_ERROR_CREATE_BACKUP,
                'success' => false,
            ];
        }

        if (!$this->unpackLastVersion($fileName)) {
            return [
                'message' => sprintf(_JSHOP_YOO_ERROR_UNPACK_NEW_VERSION, $fileName),
                'success' => false,
            ];
        }

        return [
            'message' => sprintf(_JSHOP_YOO_SUCCESS_UPDATE_VERSION, $_POST['version'], $fileName),
            'success' => true,
        ];
    }


    /**
     * Получает тег языка и загружает необходимый файл с переводом.
     *
     * @return void
     */
    private function loadLanguageFile(): void
    {
        $lang = JFactory::getLanguage();
        $langTag = $lang->getTag();
        $langFileUrl = JPATH_ROOT . '/components/com_jshopping/payments/pm_yoomoney/lang/';
        if (file_exists($langFileUrl . $langTag . '.php')) {
            require_once($langFileUrl . $langTag . '.php');
        } else {
            require_once($langFileUrl . 'ru-RU.php');
        }
    }

    /**
     * Метод проверки валидности платежа, вызывается при создании платежа после возврата пользователя на страницу
     * подтверждения заказа, так же вызывается при приходе нотификации от платёжной системы.
     * Расширение метода из класса PaymentRoot.
     *
     * @param array $pmConfigs Массив настроек платёжной системы
     * @param OrderTable $order Модель заказа
     * @param string $act Значение параметра "act" в ссылке
     *
     * @return array Массив с информацией о транзакции
     */
    function checkTransaction($pmConfigs, $order, $act): array
    {
        $this->loadLanguageFile();
        $kassa = $this->getKassaPaymentMethod($pmConfigs);

        $this->mode = $this->getMode($pmConfigs);
        $order = $this->getOrderModel($order->order_id);

        if ($this->mode === self::MODE_KASSA) {

            if ($act === 'notify') {
                $this->log('debug', 'Notification callback called');

                try {
                    $result = $this->notificationHelper->processNotification($kassa, $pmConfigs, $order);
                } catch (Exception $e) {
                    $this->log('debug', $e->getMessage());
                    header('HTTP/1.1 500 Internal Server Error');
                    die;
                }
                if (!$result) {
                    $this->log('debug', 'Notification error: wrong payment status');
                    header('HTTP/1.1 401 Payment does not exists');
                }

                header('HTTP/1.1 200');
                exit();
            }

            $this->log('debug', 'Check transaction for order#' . $order->order_id);

            if (!$this->checkPaymentByOrderId($order->order_id, $pmConfigs)) {
                return [3, 'Transaction not exists', '', 'Transaction not exists'];
            }
            $transactionId = $this->getDatabaseHelper()->getPaymentIdByOrderId($order->order_id);
            if (empty($transactionId)) {
                $this->log('debug', 'Payment id for order#' . $order->order_id . ' not exists');

                return [3, 'Transaction not exists', '', 'Transaction not exists'];
            }

            return [
                -1,
                sprintf(_JSHOP_YOO_PAYMENT_CAPTURED_TEXT, $transactionId),
                $transactionId,
                _JSHOP_YOO_PAYMENT_CAPTURED,
            ];

        }

        return [0, 'hash error'];
    }

    /**
     * Отображает конечный шаг в форме оплаты. Шаг 6.
     * Расширение метода из класса PaymentRoot.
     *
     * @param array $pmConfigs Массив настроек платёжной системы
     * @param jshopOrder $order Модель заказа
     *
     * @return void
     * @throws Exception
     */
    public function showEndForm($pmConfigs, $order): void
    {
        $order = $this->getOrderModel($order->order_id);
        $this->mode = $this->getMode($pmConfigs);
        $app = JFactory::getApplication();
        $this->loadLanguageFile();

        if ($this->mode === self::MODE_KASSA) {
            if (empty($pmConfigs['shop_id']) || empty($pmConfigs['access_token'])) {
                $this->authorizationError($app);
            }

            if ($this->processKassaPayment($pmConfigs, $order)) {
                return;
            }
            // если произошла ошибка, редиректим на шаг выбора метода оплаты
            $redirectUrl = JRoute::_(JURI::root() . 'index.php?option=com_jshopping&controller=checkout&task=step5');
            $app = JFactory::getApplication();
            $app->redirect($redirectUrl);
        }
    }

    /**
     * Процесс оплаты.
     *
     * @param array $pmConfigs Массив настроек платёжной системы
     * @param OrderModel $order Модель заказа
     *
     * @return bool|void
     * @throws Exception
     */
    public function processKassaPayment(array $pmConfigs, OrderModel $order)
    {
        $this->loadLanguageFile();
        $app = JFactory::getApplication();
        $uri = JURI::getInstance();

        $redirectUrl = $uri->toString(['scheme', 'host', 'port'])
            . \JSHelper::SEFLink("index.php?option=com_jshopping&controller=checkout&task=step7&act=return&js_paymentclass=pm_yoomoney&no_lang=1&order_id=" . $order->order_id);
        $redirectUrl = htmlspecialchars_decode($redirectUrl);

        /** @var CartModel $cart */
        $cart = JSFactory::getModel('cart', 'jshop');
        if (method_exists($cart, 'init')) {
            $cart->init('cart', 1);
        } else {
            $cart->load('cart');
        }
        $paymentParams = unserialize($order->payment_params_data);
        $paymentType = !empty($paymentParams['payment_type']) ? $paymentParams['payment_type'] : null;

        if (
            $paymentType
            && $paymentType === PaymentMethodType::SBER_LOAN
            && !$this->isCorrectAmountForSberLoan((float)$order->order_total)
        ) {
            $redirect = JRoute::_(JURI::root() . 'index.php?option=com_jshopping&controller=cart');
            $app->enqueueMessage(_JSHOP_YOO_SBER_LOAN_CREATE_PAYMENT_ERROR, 'error');
            $app->redirect($redirect);
        }

        try {
            $payment = $this->getKassaPaymentMethod($pmConfigs)->createPayment($order, $cart, $redirectUrl);
        } catch (Exception $e) {
            $redirect = JRoute::_(JURI::root() . 'index.php?option=com_jshopping&controller=checkout&task=step3');
            $app->enqueueMessage(_JSHOP_YOO_ERROR_MESSAGE_CREATE_PAYMENT, 'error');
            $this->log('error', 'Error when creating a payment', ['exception' => $e->getMessage()]);
            $app->redirect($redirect);
        }

        $redirect = $redirectUrl;

        if (!$payment) {
            $redirect = JRoute::_(JURI::root() . 'index.php?option=com_jshopping&controller=checkout&task=step3');
            $app->enqueueMessage(_JSHOP_YOO_ERROR_MESSAGE_CREATE_PAYMENT, 'error');
            $app->redirect($redirect);
        }

        $confirmation = $payment->getConfirmation();
        $this->getDatabaseHelper()->savePayment($order->order_id, $payment);

        if ($confirmation instanceof ConfirmationRedirect) {
            $redirect = $confirmation->getConfirmationUrl();
        }

        if ($confirmation instanceof ConfirmationEmbedded) {
            $this->renderWidget($payment, $redirect);
            return true;
        }

        $app->redirect($redirect);
    }

    /**
     * Инициализирует параметры для обработки процессором заказа из URL запроса при возврате на сайт. Шаг 7.
     * Расширение метода из класса PaymentRoot.
     *
     * @param array $pmConfigs Настройки модуля оплаты
     *
     * @return array Массив параметров, который будет использоваться в процессоре заказа
     * @throws Exception
     */
    public function getUrlParams($pmConfigs): array
    {
        $this->mode = $this->getMode($pmConfigs);
        $params = [];
        if ($this->mode != self::MODE_KASSA) {

            $params['order_id'] = (int)$_POST['label'];
            $params['hash'] = "";
            $params['checkHash'] = 0;

            return $params;
        }

        $this->log('debug', 'Get URL parameters for payment');
        if (isset($_GET['order_id'])) {

            $this->log('debug', 'Order id exists in return url: ' . $_GET['order_id']);

            $params['order_id'] = (int)$_GET['order_id'];

            if (!$this->checkPaymentByOrderId($params['order_id'], $pmConfigs)) {
                $redirectUrl = JRoute::_(JURI::root() . 'index.php?option=com_jshopping&controller=checkout&task=step3');
                $app = JFactory::getApplication();
                $app->redirect($redirectUrl);
            }

            $params['hash'] = "";
            $params['checkHash'] = 0;
            $params['checkReturnParams'] = 1;
            $this->log('debug', 'Return url params is: ' . json_encode($params));

            return $params;
        }

        if (isset($_GET['act']) && $_GET['act'] === 'notify') {
            $this->log('debug', 'Notification callback check URL parameters');

            try {
                $notification = $this->yooNotificationHelper->getNotificationObject();
                $orderId = $this->getOrderIdByNotification($notification);
            } catch (Exception $e) {
                $this->log('debug', 'Notification error: ' . $e->getMessage());
                header('HTTP/1.1 400 Invalid body');
                die();
            }
            $params['order_id'] = $orderId;
            $params['hash'] = "";
            $params['checkHash'] = 0;
            $params['checkReturnParams'] = 1;
            $this->log('debug', 'Notify url params is: ' . json_encode($params));

            return $params;
        }

        $this->log('debug', 'Order id not exists in return url: ' . json_encode($_GET));

        return $params;
    }

    /**
     * Возвращает id заказа по значению metadata.order_id в уведомлении, или, если уведомление о статусе
     * refund.succeeded, то вызывает метод поиска refund.succeeded в БД по id платежа.
     *
     * @param AbstractNotification $notification Класс уведомлений
     *
     * @return string
     * @throws Exception
     */
    private function getOrderIdByNotification(AbstractNotification $notification): string
    {
        $object = $notification->getObject();
        if (method_exists($object, 'getMetadata')) {
            $meta = $object->getMetadata();
            $orderId = $meta['order_id'];
        } else {
            $orderId = $this->getDatabaseHelper()->getOrderIdByPaymentId($object->getPaymentId());
        }

        if (empty($orderId)) {
            throw new Exception('Notification error: order_id was not found');
        }

        return $orderId;
    }

    /**
     * Проверяет, что платеж существует для переданного id заказа и оплачен.
     *
     * @param int $orderId Id заказа
     * @param array $pmConfigs Массив настроек платёжной системы
     *
     * @return bool
     */
    private function checkPaymentByOrderId(int $orderId, array $pmConfigs): bool
    {
        $paymentId = $this->getDatabaseHelper()->getPaymentIdByOrderId($orderId);
        if (empty($paymentId)) {
            $this->log('debug', 'Redirect user to payment method page: payment id not exists');

            return false;
        }
        $payment = $this->getKassaPaymentMethod($pmConfigs)->fetchPayment($paymentId);
        if ($payment === null) {
            $this->log('debug', 'Redirect user to payment method page: payment not exists');

            return false;
        }
        if (!$payment->getPaid()) {
            $this->log('debug', 'Redirect user to payment method page: payment not paid');
            $redirectUrl = JRoute::_(JURI::root() . 'index.php?option=com_jshopping&controller=checkout&task=step3');
            $app = JFactory::getApplication();
            $app->redirect($redirectUrl);

            return false;
        }

        $this->log('debug', 'Payment ' . $payment->getId() . ' for order#' . $orderId . ' paid');

        return true;
    }

    /**
     * Подключение виджета для оплаты.
     *
     * @param CreatePaymentResponse $payment Модуль платежа
     * @param string $returnUrl URL, на который вернется пользователь после подтверждения или отмены платежа
     *
     * @return void
     */
    private function renderWidget(CreatePaymentResponse $payment, string $returnUrl): void
    {
        $token = $payment->getConfirmation()->getConfirmationToken();
        require_once __DIR__ . "/widget.php";
    }

    /**
     * Округление суммы заказа в зависимости от валюты.
     *
     * @param OrderModel $order Модуль заказа
     *
     * @return float|string
     */
    private function fixOrderTotal(OrderModel $order): float|string
    {
        $total = $order->order_total;

        if ($order->currency_code_iso == 'HUF') {
            return round($total);
        }

        return number_format($total, 2, '.', '');
    }

    /**
     * Возвращает режим оплаты.
     *
     * @param array $paymentConfig Массив настроек платёжной системы
     *
     * @return int
     */
    private function getMode(array $paymentConfig): int
    {
        $this->debugLog = isset($paymentConfig['debug_log']) && $paymentConfig['debug_log'] == '1';

        if (isset($paymentConfig['kassamode']) && $paymentConfig['kassamode'] == '1') {
            $this->mode = self::MODE_KASSA;
        }

        return $this->mode;
    }

    /**
     * Создание записи в лог.
     *
     * @param string $level Уровень
     * @param string $message Сообщение
     * @param array $context Контекст ошибки
     *
     * @return void
     */
    public function log(string $level, string $message, array $context = []): void
    {
        if (!$this->debugLog) {
            return;
        }

        $this->logger->log($level, $message, $context);
    }

    /**
     * Возвращает модель для запросов в БД.
     *
     * @return DatabaseHelper
     */
    public function getDatabaseHelper(): DatabaseHelper
    {
        return new DatabaseHelper();
    }

    /**
     * Возвращает модель для оплаты через ЮКассу.
     *
     * @param array|null $pmConfigs Массив настроек платёжной системы
     *
     * @return KassaPaymentMethod
     */
    public function getKassaPaymentMethod(?array $pmConfigs = []): KassaPaymentMethod
    {
        $this->loadLanguageFile();
        return $this->kassa = new KassaPaymentMethod($this, $pmConfigs);
    }

    /**
     * Проверка наличия новой версии модуля.
     *
     * @param bool $useCache Использовать ли кеш
     *
     * @return array
     */
    public function checkModuleVersion(bool $useCache = true): array
    {
        $this->preventDirectoryCreation();

        $file = DIR_DOWNLOAD . '/' . $this->downloadDirectory . '/version_log.txt';

        if ($useCache && file_exists($file)) {

            $versionLogContent = $this->prepareVersionLogContent($file);
            if (count($versionLogContent) === 2 && (time() - $versionLogContent[1] < 3600 * 8)) {
                return [
                    'tag' => $versionLogContent[0],
                    'version' => preg_replace('/[^\d\.]+/', '', $versionLogContent[0]),
                    'time' => $versionLogContent[1],
                    'date' => $this->dateDiffToString($versionLogContent[1]),
                ];
            }
        }

        $connector = new BitbucketConnector();
        $version = $connector->getLatestRelease($this->repository);
        if (empty($version)) {
            return [];
        }

        $cache = $version . ':' . time();
        file_put_contents($file, $cache);

        return [
            'tag' => $version,
            'version' => preg_replace('/[^\d\.]+/', '', $version),
            'time' => time(),
            'date' => $this->dateDiffToString(time()),
        ];
    }

    /**
     * Подготавливает массив из данных лога версий.
     *
     * @param string $file
     *
     * @return array|null
     */
    private function prepareVersionLogContent(string $file): ?array
    {
        $content = preg_replace('/\s+/', '', file_get_contents($file));

        if (empty($content)) {
            return [];
        }

        return explode(':', $content);
    }

    /**
     * Получает данные из CHANGELOG, сравнивает и возвращает записи о новых изменениях.
     *
     * @param string $currentVersion Текущая версия
     * @param string $newVersion Новая версия
     *
     * @return string|null
     */
    public function getChangeLog(string $currentVersion, string $newVersion): ?string
    {
        $this->preventDirectoryCreation();

        $connector = new BitbucketConnector();

        $dir = DIR_DOWNLOAD . '/' . $this->downloadDirectory;
        $newChangeLog = $dir . '/CHANGELOG-' . $newVersion . '.md';
        if (!file_exists($newChangeLog)) {
            $fileName = $connector->downloadLatestChangeLog($this->repository, $dir);
            if (!empty($fileName)) {
                rename($dir . '/' . $fileName, $newChangeLog);
            }
        }

        $oldChangeLog = $dir . '/CHANGELOG-' . $currentVersion . '.md';
        if (!file_exists($oldChangeLog)) {
            $fileName = $connector->downloadLatestChangeLog($this->repository, $dir);
            if (!empty($fileName)) {
                rename($dir . '/' . $fileName, $oldChangeLog);
            }
        }

        $result = '';
        if (file_exists($newChangeLog)) {
            $result = $connector->diffChangeLog($oldChangeLog, $newChangeLog);
        }

        return $result;
    }

    /**
     * Возвращает дату в виде строки.
     *
     * @param int $timestamp Временная метка
     *
     * @return string
     */
    private function dateDiffToString(int $timestamp): string
    {
        return date('d.m.Y H:i', $timestamp);
    }

    /**
     * Возвращает список бекапов.
     *
     * @return array
     */
    public function getBackupList(): array
    {
        $result = [];

        $this->preventDirectoryCreation();
        $dir = DIR_DOWNLOAD . '/' . $this->backupDirectory;

        $handle = opendir($dir);
        while (($entry = readdir($handle)) !== false) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }
            $ext = pathinfo($entry, PATHINFO_EXTENSION);
            if ($ext === 'zip') {
                $backup = [
                    'name' => pathinfo($entry, PATHINFO_FILENAME) . '.zip',
                    'size' => $this->formatSize(filesize($dir . '/' . $entry)),
                ];
                $parts = explode('-', $backup['name'], 3);
                $backup['version'] = $parts[0];
                $backup['time'] = $parts[1];
                $backup['date'] = date('d.m.Y H:i:s', $parts[1]);
                $backup['hash'] = $parts[2];
                $result[] = $backup;
            }
        }

        return $result;
    }

    /**
     * Подготавливает необходимые директории.
     *
     * @return void
     */
    private function preventDirectoryCreation(): void
    {
        if (!file_exists(DIR_DOWNLOAD)) {
            mkdir(DIR_DOWNLOAD);
        }
        $dir = DIR_DOWNLOAD . '/' . $this->downloadDirectory;
        if (!file_exists($dir)) {
            mkdir($dir);
        }
        $dir = DIR_DOWNLOAD . '/' . $this->backupDirectory;
        if (!file_exists($dir)) {
            mkdir($dir);
        }
        $dir = DIR_DOWNLOAD . '/' . $this->versionDirectory;
        if (!file_exists($dir)) {
            mkdir($dir);
        }
    }

    /**
     * Возвращает размер файла.
     *
     * @param int $size Размер файла бекапа
     *
     * @return string
     */
    private function formatSize(int $size): string
    {
        static $sizes = [
            'B',
            'kB',
            'MB',
            'GB',
            'TB',
        ];

        $i = 0;
        while ($size > 1024) {
            $size /= 1024.0;
            $i++;
        }

        return number_format($size, 2, '.', ',') . '&nbsp;' . $sizes[$i];
    }

    /**
     * Подготавливает директорию и скачивает последнюю версию модуля.
     *
     * @param string $tag Тег версии
     *
     * @return bool|string
     */
    private function downloadLastVersion(string $tag): bool|string
    {
        $this->loadLanguageFile();
        $this->preventDirectoryCreation();

        $dir = DIR_DOWNLOAD . '/' . $this->versionDirectory;

        if (!file_exists($dir) && !mkdir($dir)) {
            $this->log('error', _JSHOP_YOO_FAILED_CREATE_DIRECTORY . $dir);
            return false;
        }

        $fileName = $dir . '/' . $tag . '.zip';
        if (file_exists($fileName)) {
            return $fileName;
        }

        $connector = new BitbucketConnector();
        $fileName = $connector->downloadRelease($this->repository, $tag, $dir);
        if (empty($fileName)) {
            $this->log('error', _JSHOP_YOO_FAILED_DOWNLOAD_UPDATE);

            return false;
        }

        return $fileName;
    }

    /**
     * Создает бекап модуля.
     *
     * @param string $version Текущая версия модуля
     *
     * @return bool
     */
    public function createBackup(string $version): bool
    {
        $this->preventDirectoryCreation();

        $sourceDirectory = dirname(JSH_DIR, 2);
        $reader = new ProjectStructureReader();
        $root = $reader->readFile(JSH_DIR . '/payments/pm_yoomoney/lib/joomshopping.map',
            $sourceDirectory);

        $rootDir = $version . '-' . time();
        $fileName = $rootDir . '-' . uniqid('', true) . '.zip';
        $dir = DIR_DOWNLOAD . '/' . $this->backupDirectory;
        try {
            $fileName = $dir . '/' . $fileName;
            $archive = new BackupZip($fileName, $rootDir);
            $archive->backup($root);
        } catch (Exception $e) {
            $this->log('error', 'Failed to create backup: ' . $e->getMessage());

            return false;
        }

        return true;
    }

    /**
     * Распаковывает новую версию модуля.
     *
     * @param string $fileName Файл с новой версий модуля
     *
     * @return bool
     */
    public function unpackLastVersion(string $fileName): bool
    {
        if (!file_exists($fileName)) {
            $this->log('error', 'File "' . $fileName . '" not exists');

            return false;
        }

        try {
            $sourceDirectory = dirname(JSH_DIR, 2);
            $archive = new RestoreZip($fileName, $this->logger);
            $archive->restore('joomshopping.map', $sourceDirectory);
        } catch (Exception $e) {
            $this->log('error', $e->getMessage());
            if ($e->getPrevious() !== null) {
                $this->log('error', $e->getPrevious()->getMessage());
            }

            return false;
        }

        return true;
    }

    /**
     * Устанавливает модуль.
     *
     * @return void
     */
    private function installExtension(): void
    {
        $addon = $this->versionHelper->getAddonTableObj();

        $manifest = '{"creationDate":"20.07.2018","author":"YooMoney","authorEmail":"cms@yoomoney.ru","authorUrl":"https://yookassa.ru","version":"' . self::_JSHOP_YOO_VERSION . '"}';
        $addon->installJoomlaExtension(
            [
                'name' => 'YooMoney',
                'type' => 'plugin',
                'element' => $this->element,
                'folder' => 'jshoppingadmin',
                'client_id' => 0,
                'enabled' => 1,
                'access' => 1,
                'protected' => 0,
                'manifest_cache' => $manifest,
            ]
        );
    }

    /**
     * Сохранение записи в истории заказа.
     *
     * @param int $order_id Id заказа
     * @param string $comments Комментарий
     *
     * @return bool
     */
    public function saveOrderHistory(int $order_id, string $comments): bool
    {
        return $this->getOrderModel($order_id)->saveOrderHistory(0, $comments);
    }

    /**
     * Отправляет второй чек.
     *
     * @param int $orderId Id заказа
     * @param KassaPaymentMethod $kassa Модель для оплаты через ЮКассу
     * @param string $status Текущий статус заказа
     */
    public function sendSecondReceipt(int $orderId, KassaPaymentMethod $kassa, string $status)
    {
        $this->receiptHelper->sendSecondReceipt($orderId, $kassa, $status);
    }

    /**
     * Возвращает доступные способы оплаты для оплаты через ЮКассу на стороне магазина.
     *
     * @return array
     */
    private static function getKassaPaymentMethods(): array
    {
        $enabledPaymentMethods = [];
        $paymentMethods = array_merge(self::$customPaymentMethods, PaymentMethodType::getEnabledValues());
        foreach ($paymentMethods as $value) {
            if (!in_array($value, self::$disabledPaymentMethods)) {
                $enabledPaymentMethods[] = $value;
            }
        }

        return $enabledPaymentMethods;
    }

    /**
     * Определение экшена и его выполнение.
     *
     * @return void
     * @throws Exception
     */
    public function checkSubaction(): void
    {
        if ($_GET['subaction'] === 'get_log_messages') {
            $this->viewModuleLogs();
        }

        if ($_GET['subaction'] === 'clear_log_messages') {
            $this->clearModuleLogs();
        }

        if ($_GET['subaction'] === 'restore_backup') {
            ob_start();
            $result = $this->restoreBackup();
            $data = ob_get_clean();
            if (!empty($data)) {
                $result['output'] = $data;
            }
            $this->sendResponseJson($result);
        }

        if ($_GET['subaction'] === 'remove_backup') {
            ob_start();
            $result = $this->removeBackup();
            $data = ob_get_clean();
            if (!empty($data)) {
                $result['output'] = $data;
            }
            $this->sendResponseJson($result);
        }

        if ($_GET['subaction'] === 'update') {
            ob_start();
            $result = $this->updateVersion();
            $data = ob_get_clean();
            if (!empty($data)) {
                $result['output'] = $data;
            }
            $this->sendResponseJson($result);
        }

        if ($_GET['subaction'] === 'get_oauth_url') {
            $this->getOauthUrl();
        }

        if ($_GET['subaction'] === 'get_oauth_token') {
            $this->getOauthToken();
        }
    }

    /**
     * Обработка ajax запроса на получение ссылки для авторизации по oauth.
     *
     * @return void
     * @throws Exception
     */
    public function getOauthUrl(): void
    {
        if (!$this->isRequestAjaxAndAllowed()) {
            $this->sendResponseJson(['status' => 'error', 'error' => 'Unknown', 'code' => 'unknown']);
        }

        if (!$this->formParams && ($app = $this->getApplication())) {
            $this->formParams = $this->storageHelper->stringToArray($app->input->request->get('forms', '', 'string'), 'pm_params');
        }

        $oauth = $this->getOauthModel();
        $result = $oauth->getOauthConnectUrl();
        $code = isset($result['error']) ? 502 : 200;
        $this->sendResponseJson($result, $code);
    }

    /**
     * Обработка ajax запроса на получение токена для авторизации по oauth.
     *
     * @return void
     * @throws Exception
     */
    public function getOauthToken(): void
    {
        if (!$this->isRequestAjaxAndAllowed()) {
            $this->sendResponseJson(['status' => 'error', 'error' => 'Unknown', 'code' => 'unknown']);
        }

        $oauth = $this->getOauthModel();
        $result = $oauth->getOauthToken();
        $code = isset($result['error']) ? 502 : 200;
        $this->sendResponseJson($result, $code);
    }

    /**
     * Проверка на корректность запроса со стороны юзера и типа запроса.
     *
     * @return bool
     */
    private function isRequestAjaxAndAllowed(): bool
    {
        return $this->isAllowedUser() || $this->isAjaxRequest();
    }

    /**
     * Отправка ответа в формате json.
     *
     * @param array $result Массив с данными для ответа
     * @param int $code Статус с которым будет возвращен ответ
     * @return void
     */
    private function sendResponseJson(array $result, int $code = 200): void
    {
        echo json_encode($result);
        exit($code);
    }

    /**
     * Проверка есть ли доступ отправлять запросы у текущего юзера.
     *
     * @return bool
     */
    private function isAllowedUser(): bool
    {
        $app = $this->getApplication();
        return $app && $app->getIdentity()->authorise('core.admin');
    }

    /**
     * Проверка на ajax.
     *
     * @return bool
     */
    private function isAjaxRequest(): bool
    {
        $app = $this->getApplication();
        return $app && strtolower($app->input->server->get('HTTP_X_REQUESTED_WITH', '')) === 'xmlhttprequest';
    }

    /**
     * Получение глобального объекта приложения.
     *
     * @return \Joomla\CMS\Application\CMSApplicationInterface|void
     */
    private function getApplication()
    {
        try {
            return JFactory::getApplication();
        } catch (Exception) {
            return;
        }
    }

    /**
     * Возвращает модель для работы с параметрами платежного метода.
     *
     * @return OauthDataStorageHelper
     */
    public function getOauthDataStorageHelper(): OauthDataStorageHelper
    {
        return new OauthDataStorageHelper($this->kassa);
    }

    /**
     * Возвращает фабрику для получения экземпляра клиента API Юkassa.
     *
     * @return YookassaClientFactory
     */
    public function getYookassaClientFactory(): YookassaClientFactory
    {
        return new YookassaClientFactory($this->logger, $this->kassa);
    }

    /**
     * Возвращает класс для работы с oauth вебхуками.
     *
     * @return OauthWebhooksHelper
     */
    public function getOauthWebhooksHelper(): OauthWebhooksHelper
    {
        return new OauthWebhooksHelper(
            $this->logger,
            $this->getYookassaClientFactory()
        );
    }

    /**
     * Возвращает класс для получения информации о магазине.
     *
     * @return YookassaShopInfoHelper
     */
    public function getYookassaShopInfoHelper(): YookassaShopInfoHelper
    {
        return new YookassaShopInfoHelper($this->getYookassaClientFactory());
    }

    /**
     * Возвращает класс для работы с запросами.
     *
     * @return HttpClient
     */
    private function getHttpClient(): HttpClient
    {
        return new HttpClient();
    }

    /**
     * Возвращает класс для работы с oauth.
     *
     * @return OauthModel
     */
    private function getOauthModel(): OauthModel
    {
        $this->getKassaPaymentMethod($this->formParams);
        return new OauthModel(
            $this->logger,
            $this->getOauthDataStorageHelper(),
            $this->getOauthWebhooksHelper(),
            $this->getYookassaShopInfoHelper(),
            $this->getHttpClient()
        );
    }

    /**
     * Проверяет корректность суммы при оплате через Покупки в кредит от Сбера.
     *
     * @param float $amount Сумма заказа
     * @return bool
     */
    private function isCorrectAmountForSberLoan(float $amount): bool
    {
        return $amount >= self::PAYMENT_METHOD_SBER_LOAN_MIN_AMOUNT && $amount <= self::PAYMENT_METHOD_SBER_LOAN_MAX_AMOUNT;
    }

    /**
     * Возвращает класс методов для работы с заказами.
     *
     * @param int $orderId Id заказа
     *
     * @return OrderModel
     */
    private function getOrderModel(int $orderId): OrderModel
    {
        return new OrderModel($orderId);
    }

    /**
     * Генерация ссылки на предыдущий шаг и генерация сообщения для покупателя и в лог модуля
     *
     * @param SiteApplication $app Экземпляр приложения СMS Joomla
     * @return void
     */
    private function authorizationError(SiteApplication $app): void
    {
        $redirectUrl = JRoute::_(JURI::root() . 'index.php?option=com_jshopping&controller=checkout&task=step3');
        $this->log('error', 'Authorization failed in YooMoney module');
        $app->enqueueMessage(_JSHOP_YOO_ERROR_MESSAGE_CREATE_PAYMENT, 'error');
        $app->redirect($redirectUrl);
    }
}
