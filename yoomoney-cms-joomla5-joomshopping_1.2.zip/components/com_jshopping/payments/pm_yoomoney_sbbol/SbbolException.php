<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

namespace YooMoney\Model;

use Exception;

/**
 * Класс эсепшенов по оплате через ЮКасса СББОЛ
 */
class SbbolException extends Exception
{
}