<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

defined('_JEXEC') or die('Restricted access');

/** @var array $params Настройки модуля оплаты */
/** @var array $taxes Массив с налогами */
/** @var string $notifyUrl Дефолтный адрес для уведомлений */
/** @var \JModelLegacy $orders Модель заказа */

/**
 * Экранирует переданное значение.
 *
 * @param string|null $value Переданное значение
 *
 * @return string
 */
function escapeValue(?string $value): string
{
    return htmlspecialchars($value);
}

?>
<div class="col100">
    <fieldset class="adminform">
        <p><?php echo _JSHOP_YOO_SBBOL_LICENSE_TEXT2; ?></p>
        <p><?php echo _JSHOP_YOO_SBBOL_VERSION_DESCRIPTION; ?><?php echo pm_yoomoney_sbbol::_JSHOP_YOO_VERSION; ?></p>

        <div class="row">
            <div class="span11 offset1">
                <h4><?php echo _JSHOP_YOO_SBBOL_HEAD; ?></h4>
            </div>
        </div>

        <div class="row  mb-3">
            <div class="col">
                <h4><?php echo _JSHOP_YOO_SBBOL_KASSA_HEAD_LK; ?></h4>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-3">
                <label for="pm_params-sbbol-shop-id">shopId</label>
            </div>
            <div class="col-9">
                <input type="text" name="pm_params[sbbol_shop_id]" class="form-control" id="pm_params-sbbol-shop-id"
                       value="<?php echo escapeValue($params['sbbol_shop_id']); ?>">
                <div class="form-text"><?php echo _JSHOP_YOO_SBBOL_KASSA_SHOP_ID_DESCRIPTION; ?></div>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-3">
                <label for="pm_params-sbbol-shop-password">
                    <?php echo _JSHOP_YOO_SBBOL_KASSA_PASSWORD_LABEL; ?>
                </label>
            </div>

            <div class="col-9">
                <input name="pm_params[sbbol_shop_password]" type="text" class="form-control" id="pm_params-sbbol-shop-password"
                       value="<?php echo escapeValue($params['sbbol_shop_password']); ?>">
                <div class="form-text"><?php echo _JSHOP_YOO_SBBOL_KASSA_PASSWORD_DESCRIPTION; ?></div>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-3">
                <label for="yookassa_description_template">
                    <?php echo _JSHOP_YOO_SBBOL_DESCRIPTION_TITLE; ?>
                </label>
            </div>

            <div class="col-9">
                <input name="pm_params[sbbol_purpose]" type="text" class="form-control"
                       id="yookassa_description_template"
                       value="<?php echo escapeValue($params['sbbol_purpose']); ?>"
                >
                <div class="form-text"><?php echo _JSHOP_YOO_SBBOL_DESCRIPTION_HELP; ?></div>
                <div class="row mt-3">
                    <div class="col-auto">
                        <label for="pm_params[sbbol_default_tax]" class="col-form-label">
                            <?php echo _JSHOP_YOO_SBBOL_DEFAULT_TAX_LABEL; ?>
                        </label>
                    </div>
                    <div class="col-auto">
                        <select name="pm_params[sbbol_default_tax]"
                                class="form-select form-control form-select-sm"
                                id="pm_params[sbbol_default_tax]">
                            <option <?php if ($params['sbbol_default_tax'] == 'untaxed') { ?> selected="selected" <?php } ?>
                                    value="untaxed"><?= _JSHOP_YOO_SBBOL_WITHOUT_VAT ?>
                            </option>
                            <option <?php if ($params['sbbol_default_tax'] == '7') { ?> selected="selected" <?php } ?>
                                    value="7">7%
                            </option>
                            <option <?php if ($params['sbbol_default_tax'] == '10') { ?> selected="selected" <?php } ?>
                                    value="10">10%
                            </option>
                            <option <?php if ($params['sbbol_default_tax'] == '18') { ?> selected="selected" <?php } ?>
                                    value="18">18%
                            </option>
                            <option <?php if ($params['sbbol_default_tax'] == '20') { ?> selected="selected" <?php } ?>
                                    value="20">20%
                            </option>
                        </select>
                    </div>
                </div>
                <p class="mt-3 mb-1"><?= _JSHOP_YOO_SBBOL_TAX_RATES_HEAD ?>:</p>
                <p class="mb-1"><?= _JSHOP_YOO_SBBOL_TAX_HELP ?></p>
                <?php foreach ($taxes as $k => $tax) { ?>
                    <div class="row mb-2">
                        <div class="col-4">
                            <label for="pm_params[sbbol_tax_<?php echo $k; ?>]"><?php echo $tax; ?>%
                            </label>
                        </div>
                        <div class="col-4">
                            <select name="pm_params[sbbol_tax_<?php echo $k; ?>]"
                                    class="form-select form-control form-select-sm"
                                    id="pm_params[sbbol_tax_<?php echo $k; ?>]">
                                <option <?php if ($params['sbbol_tax_' . $k] == 'untaxed') { ?> selected="selected" <?php } ?>
                                        value="untaxed">Без НДС
                                </option>
                                <option <?php if ($params['sbbol_tax_' . $k] == '7') { ?> selected="selected" <?php } ?>
                                        value="7">7%
                                </option>
                                <option <?php if ($params['sbbol_tax_' . $k] == '10') { ?> selected="selected" <?php } ?>
                                        value="10">10%
                                </option>
                                <option <?php if ($params['sbbol_tax_' . $k] == '18') { ?> selected="selected" <?php } ?>
                                        value="18">18%
                                </option>
                                <option <?php if ($params['sbbol_tax_' . $k] == '20') { ?> selected="selected" <?php } ?>
                                        value="20">20%
                                </option>
                            </select>
                        </div>
                    </div>
                <?php } ?>
                <div class="form-text"><?php echo _JSHOP_YOO_SBBOL_HELP_TEXT; ?></div>
            </div>

        </div>

        <div class="row mb-3">
            <div class="col-3">
                <label for="jform_joomlatoken_token"><?php echo _JSHOP_YOO_SBBOL_NOTIFICATION_URL_LABEL; ?></label>
            </div>

            <div class="col-9 ">
                <div class="input-group has-success">
                    <input type="text" class="form-control valid form-control-success"
                           name="jform[joomlatoken][token]" id="jform_joomlatoken_token" readonly=""
                           value="<?= escapeValue($notifyUrl) ?>" aria-invalid="false"
                    >
                </div>
                <div class="form-text"><?php echo _JSHOP_YOO_SBBOL_NOTIFICATION_URL_HELP_TEXT; ?></div>
            </div>
        </div>
        <div class="row  mb-3">
            <div class="col">
                <h4><?php echo _JSHOP_YOO_SBBOL_COMMON_HEAD; ?></h4>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-3">
                <label for="yookassa_transaction_end_status">
                    <?php echo _JSHOP_YOO_SBBOL_COMMON_STATUS; ?>
                </label>
            </div>

            <div class="col-9">
                <?php
                print JHTML::_('select.genericlist', $orders->getAllOrderStatus(),
                    'pm_params[sbbol_transaction_end_status]',
                    'class="transaction-end-status form-select form-control form-select-sm" size="1" data-type="kassa"', 'status_id', 'name',
                    $params['sbbol_transaction_end_status']);
                ?>
            </div>
        </div>

        <input type="hidden" name="pm_params[transaction_end_status]" id="transaction-end-status"
               value="<?php echo $params['transaction_end_status']; ?>"/>
    </fieldset>
</div>
<div class="clr"></div>
<script type="text/javascript">
    window.addEventListener('DOMContentLoaded', function () {
        jQuery('.transaction-end-status').change(function () {
            const endStatusInput = document.getElementById('transaction-end-status');
            endStatusInput.value = this.value;
        });
    });
</script>