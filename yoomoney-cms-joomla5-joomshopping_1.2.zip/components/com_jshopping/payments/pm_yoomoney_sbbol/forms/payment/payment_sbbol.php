<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

defined('_JEXEC') or die('Restricted access');

?>

<input type="hidden" name="params[pm_yoomoney_sbbol][payment_type]" value="yoo-b2b-sberbank"
       id="pm_yoomoney_payment_type"/>
