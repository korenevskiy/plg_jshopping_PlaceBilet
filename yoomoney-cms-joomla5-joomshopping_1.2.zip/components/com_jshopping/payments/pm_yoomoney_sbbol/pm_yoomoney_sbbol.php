<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

use YooKassa\Model\Notification\AbstractNotification;
use YooKassa\Model\Payment\Confirmation\ConfirmationRedirect;
use YooMoney\Helpers\DatabaseHelper;
use YooMoney\Helpers\YookassaNotificationFactory;
use YooMoney\Model\KassaPaymentMethod;
use YooMoney\Model\OrderModel;
use YooMoney\Model\SbbolException;
use YooMoney\Helpers\LoggerHelper;
use YooMoney\Helpers\NotificationHelper;
use Joomla\Component\Jshopping\Site\Table\OrderTable;

defined('_JEXEC') or die('Restricted access');

!defined('JSH_DIR') && define('JSH_DIR', realpath(dirname(__FILE__) . '/../..'));

require_once dirname(__FILE__) . '/../pm_yoomoney/lib/autoload.php';
require_once dirname(__FILE__) . '/SbbolException.php';

/**
 * Класс модуля ЮКасса СББОЛ
 */
class pm_yoomoney_sbbol extends PaymentRoot
{
    /** Версия модуля */
    public const _JSHOP_YOO_VERSION = '1.2.0';

    /** @var LoggerHelper Класс методов для работы с логами модуля */
    private LoggerHelper $logger;

    /** @var NotificationHelper Класс методов для работы для обработки входящих уведомлений от Юkassa */
    private NotificationHelper $transactionHelper;

    /** @var YookassaNotificationFactory Класс-фабрика для получения объекта уведомления от Юkassa */
    private YookassaNotificationFactory $yooNotificationHelper;

    /**
     * Конструктор pm_yoomoney_sbbol.
     */
    public function __construct()
    {
        $this->logger = new LoggerHelper();
        $this->transactionHelper = new NotificationHelper();
        $this->yooNotificationHelper = new YookassaNotificationFactory();
    }

    /**
     * Отображает форму оплаты. Шаг 3. Расширение метода из класса PaymentRoot.
     *
     * @param array $params Массив параметров, указанных в params[pm_yoomoney_sbbol] на странице выбора способа оплаты
     * @param array $pmconfigs Настройки модуля оплаты
     *
     * @return void
     */
    function showPaymentForm($params, $pmconfigs): void
    {
        $this->loadLanguageFile();
        include(dirname(__FILE__) . "/forms/payment/payment_sbbol.php");
    }

    /**
     * Отображение списка параметров для заказа. Расширение метода из класса PaymentRoot.
     *
     * @return array
     */
    public function getDisplayNameParams(): array
    {
        return [];
    }

    /**
     * function call in admin
     *
     * @param string|array $params
     * @return void
     *
     */
    public function showAdminFormParams($params)
    {
        $array_params = [
            'sbbol_shop_password',
            'sbbol_shop_id',
            'sbbol_transaction_end_status',
            'sbbol_default_tax',
            'sbbol_purpose',
            'transaction_end_status',
        ];

        if (!is_array($params)) {
            $params = [];
        }

        if (empty($params['sbbol_purpose'])) {
            $params['sbbol_purpose'] = 'Оплата заказа %order_id%';
        }

        $taxes = $taxes = JSFactory::getAllTaxes();

        foreach ($taxes as $k => $tax) {
            $array_params[] = 'yoo_sbbol_tax_' . $k;
        }

        foreach ($array_params as $key) {
            if (!isset($params[$key])) {
                $params[$key] = '';
            }
        }
        foreach (['yookassa', 'yoomoney'] as $type) {
            $key = $type . '_transaction_end_status';
            if (!isset($params[$key])) {
                $params[$key] = $params['sbbol_transaction_end_status'];
            }
        }
        $this->loadLanguageFile();
        $orders = JModelLegacy::getInstance('orders', 'JshoppingModel'); //admin model

        $uri = JURI::getInstance();
        $sslurlhost = $uri->toString(['host', 'port']);

        $notifyUrl = 'https://' . $sslurlhost . \JSHelper::SEFLink("index.php?option=com_jshopping&controller=checkout&task=step7&act=notify&js_paymentclass=pm_yoomoney_sbbol&no_lang=1");
        $notifyUrl = htmlspecialchars_decode($notifyUrl);


        include(dirname(__FILE__) . "/forms/admin/admin_sbbol.php");
    }

    /**
     * Получает тег языка и загружает необходимый файл с переводом.
     *
     * @return void
     */
    private function loadLanguageFile(): void
    {
        $lang = JFactory::getLanguage();
        $langTag = $lang->getTag();
        $langFileUrl = JPATH_ROOT . '/components/com_jshopping/payments/pm_yoomoney_sbbol/lang/';

        if (file_exists($langFileUrl . $langTag . '.php')) {
            require_once($langFileUrl . $langTag . '.php');
        } else {
            require_once($langFileUrl . 'ru-RU.php');
        }
    }

    /**
     * Отображает конечный шаг в форме оплаты. Шаг 6.
     * Расширение метода из класса PaymentRoot.
     *
     * @param array $pmconfigs Массив настроек платёжной системы
     * @param OrderModel $order Модель заказа
     *
     * @return void
     * @throws Exception
     */
    function showEndForm($pmconfigs, $order)
    {
        $app = JFactory::getApplication();
        $this->loadLanguageFile();
        $uri = JURI::getInstance();
        $redirectUrl = JRoute::_(JURI::root() . 'index.php?option=com_jshopping&controller=checkout&task=step3');

        if (empty($pmconfigs['sbbol_shop_id']) || empty($pmconfigs['sbbol_shop_password'])) {
            $this->log('error', 'Authorization failed in YooMoney SBBOL module');
            $app->enqueueMessage(_JSHOP_YOO_SBBOL_ERROR_MESSAGE_CREATE_PAYMENT, 'error');
            $app->redirect($redirectUrl);
        }

        $order = $this->getOrderModel($order->order_id);

        $cart = JSFactory::getModel('cart', 'jshop');
        if (method_exists($cart, 'init')) {
            $cart->init('cart', 1);
        } else {
            $cart->load('cart');
        }

        /** @var jshopCart $cart */
        $cart = JSFactory::getModel('cart', 'jshop');
        if (method_exists($cart, 'init')) {
            $cart->init('cart', 1);
        } else {
            $cart->load('cart');
        }

        $redirectUrl = $uri->toString(['scheme', 'host', 'port'])
            . \JSHelper::SEFLink("index.php?option=com_jshopping&controller=checkout&task=step7&act=return&js_paymentclass=pm_yoomoney_sbbol&no_lang=1&order_id=" . $order->order_id);
        $redirectUrl = htmlspecialchars_decode($redirectUrl);

        try {
            $payment = $this->getKassaPaymentMethod($pmconfigs)->createSbbolPayment($order, $cart, $redirectUrl);
        } catch (SbbolException $e) {
            $redirectUrl = JRoute::_(JURI::root() . 'index.php?option=com_jshopping&controller=checkout&task=step3');
            $app->enqueueMessage('У вас в корзине товары, для которых действуют разные ставки НДС — их нельзя оплатить одновременно. Можно разбить покупку на несколько этапов: сначала оплатить товары с одной ставкой НДС, потом — с другой.',
                'error');
            $app->redirect($redirectUrl);
        } catch (Exception $e) {
            $redirectUrl = JRoute::_(JURI::root() . 'index.php?option=com_jshopping&controller=checkout&task=step3');
            $app->enqueueMessage(_JSHOP_YOO_SBBOL_ERROR_MESSAGE_CREATE_PAYMENT, 'error');
            $app->redirect($redirectUrl);
        }

        $redirect = $redirectUrl;

        if ($payment !== null) {
            $confirmation = $payment->getConfirmation();

            if ($confirmation instanceof ConfirmationRedirect) {
                $redirect = $confirmation->getConfirmationUrl();
            }

            $this->getDatabaseHelper()->savePayment($order->order_id, $payment);
        } else {
            $redirect = JRoute::_(JURI::root() . 'index.php?option=com_jshopping&controller=checkout&task=step3');
            $this->setErrorMessage(_JSHOP_YOO_ERROR_MESSAGE_CREATE_PAYMENT);
        }

        $app->redirect($redirect);
    }

    /**
     * Инициализирует параметры для обработки процессором заказа из URL запроса при возврате на сайт. Шаг 7.
     * Расширение метода из класса PaymentRoot.
     *
     * @param array $pmconfigs Настройки модуля оплаты
     *
     * @return array Массив параметров, который будет использоваться в процессоре заказа
     * @throws Exception
     */
    public function getUrlParams($pmconfigs)
    {
        $params = [
            "hash" => "",
            "checkHash" => 0,
        ];

        if (isset($_GET['act']) && $_GET['act'] === 'notify') {
            $this->log('debug', 'Notification callback check URL parameters');

            try {
                $notification = $this->yooNotificationHelper->getNotificationObject();
                $orderId = $this->getOrderIdByNotification($notification);
            } catch (Exception $e) {
                $this->log('debug', 'Notification error: ' . $e->getMessage());
                header('HTTP/1.1 400 Invalid body');
                die();
            }
            $params['order_id'] = $orderId;
            $params['hash'] = "";
            $params['checkHash'] = 0;
            $params['checkReturnParams'] = 1;
            $this->log('debug', 'Notify url params is: ' . json_encode($params));

            return $params;
        }

        if ($_POST['orderNumber']) {
            $params['order_id'] = (int)$_POST['module_order_id'];
        } else {
            $params['order_id'] = (int)$_POST['label'];
        }

        return $params;
    }

    /**
     * Возвращает id заказа по значению metadata.order_id в уведомлении, или, если уведомление о статусе
     * refund.succeeded, то вызывает метод поиска refund.succeeded в БД по id платежа.
     *
     * @param AbstractNotification $notification Класс уведомлений
     *
     * @return string
     * @throws Exception
     */
    private function getOrderIdByNotification(AbstractNotification $notification): string
    {
        $object = $notification->getObject();
        if (method_exists($object, 'getMetadata')) {
            $meta = $object->getMetadata();
            $orderId = $meta['order_id'];
        } else {
            $orderId = $this->getDatabaseHelper()->getOrderIdByPaymentId($object->getPaymentId());
        }

        if (empty($orderId)) {
            throw new Exception('Notification error: order_id was not found');
        }

        return $orderId;
    }

    /**
     * Метод проверки валидности платежа, вызывается при создании платежа после возврата пользователя на страницу
     * подтверждения заказа, так же вызывается при приходе нотификации от платёжной системы.
     * Расширение метода из класса PaymentRoot.
     *
     * @param array $pmConfigs Массив настроек платёжной системы
     * @param OrderTable $order Модель заказа
     * @param string $act Значение параметра "act" в ссылке
     *
     * @return array Массив с информацией о транзакции
     */
    function checkTransaction($pmConfigs, $order, $act)
    {
        $this->loadLanguageFile();
        $kassa = $this->getKassaPaymentMethod($pmConfigs);
        $order = $this->getOrderModel($order->order_id);

        if ($act === 'notify') {
            $this->log('debug', 'Notification callback called');

            try {
                $result = $this->transactionHelper->processNotification($kassa, $pmConfigs, $order);
            } catch (Exception $e) {
                $this->log('debug', $e->getMessage());
                header('HTTP/1.1 500 Internal Server Error');
                die;
            }
            if (!$result) {
                $this->log('debug', 'Notification error: wrong payment status');
                header('HTTP/1.1 401 Payment does not exists');
            }

            exit();
        }

        $this->log('debug', 'Check transaction for order#' . $order->order_id);

        if (!$this->checkPaymentByOrderId($order->order_id, $pmConfigs)) {
            return [3, 'Transaction not exists', '', 'Transaction not exists'];
        }
        $transactionId = $this->getDatabaseHelper()->getPaymentIdByOrderId($order->order_id);
        if (empty($transactionId)) {
            $this->log('debug', 'Payment id for order#' . $order->order_id . ' not exists');

            return [3, 'Transaction not exists', '', 'Transaction not exists'];
        }

        return [
            -1,
            sprintf(_JSHOP_YOO_PAYMENT_CAPTURED_TEXT, $transactionId),
            $transactionId,
            _JSHOP_YOO_PAYMENT_CAPTURED,
        ];
    }

    /**
     * Проверяет, что платеж существует для переданного id заказа и оплачен.
     *
     * @param int $orderId Id заказа
     * @param array $pmConfigs Массив настроек платёжной системы
     *
     * @return bool
     */
    private function checkPaymentByOrderId(int $orderId, array $pmConfigs)
    {
        $paymentId = $this->getDatabaseHelper()->getPaymentIdByOrderId($orderId);
        if (empty($paymentId)) {
            $this->log('debug', 'Redirect user to payment method page: payment id not exists');

            return false;
        }
        $payment = $this->getKassaPaymentMethod($pmConfigs)->fetchPayment($paymentId);
        if ($payment === null) {
            $this->log('debug', 'Redirect user to payment method page: payment not exists');

            return false;
        }
        if (!$payment->getPaid()) {
            $this->log('debug', 'Redirect user to payment method page: payment not paid');
            $redirectUrl = JRoute::_(JURI::root() . 'index.php?option=com_jshopping&controller=checkout&task=step3');
            $app = JFactory::getApplication();
            $app->redirect($redirectUrl);

            return false;
        }

        $this->log('debug', 'Payment ' . $payment->getId() . ' for order#' . $orderId . ' paid');

        return true;
    }

    /**
     * Возвращает модель для запросов в БД.
     *
     * @return DatabaseHelper
     */
    public function getDatabaseHelper(): DatabaseHelper
    {
        return new DatabaseHelper();
    }

    /**
     * Создание записи в лог.
     *
     * @param string $level Уровень
     * @param string $message Сообщение
     * @param array $context Контекст ошибки
     *
     * @return void
     */
    public function log(string $level, string $message, array $context = []): void
    {
        $this->logger->log($level, $message, $context);
    }

    /**
     * Возвращает путь к файлу лога.
     *
     * @return string
     */
    private function getLogFileName(): string
    {
        return $this->logger->getLogFileName();
    }

    /**
     * Возвращает модель для оплаты через ЮКассу.
     *
     * @param array $pmConfigs Массив настроек платёжной системы
     *
     * @return KassaPaymentMethod
     */
    public function getKassaPaymentMethod(array $pmConfigs): KassaPaymentMethod
    {
        $this->loadLanguageFile();
        return new KassaPaymentMethod($this, $pmConfigs);
    }

    /**
     * Возвращает класс методов для работы с заказами.
     *
     * @param int $orderId Id заказа
     *
     * @return OrderModel
     */
    private function getOrderModel(int $orderId): OrderModel
    {
        return new OrderModel($orderId);
    }
}
