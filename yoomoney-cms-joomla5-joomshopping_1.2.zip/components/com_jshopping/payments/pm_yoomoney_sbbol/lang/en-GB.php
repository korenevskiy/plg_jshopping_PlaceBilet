<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

defined('_JEXEC') or die();

const _JSHOP_YOO_SBBOL_VERSION_DESCRIPTION = 'Module version ';
const _JSHOP_YOO_SBBOL_KASSA_HEAD_LK = 'Link your website on Joomla to your store in YooMoney';
const _JSHOP_YOO_SBBOL_KASSA_SHOP_ID_DESCRIPTION = 'Copy your shopId from your YooKassa Merchant Profile';
const _JSHOP_YOO_SBBOL_KASSA_PASSWORD_LABEL = 'Secret key';
const _JSHOP_YOO_SBBOL_KASSA_PASSWORD_DESCRIPTION = 'Issue and activate a secret key under your YooKassa\'s Merchant Profile. Then copy it here.';
const _JSHOP_YOO_SBBOL_COMMON_HEAD = 'Additional settings for administrator';
const _JSHOP_YOO_SBBOL_COMMON_STATUS = 'Order status after the payment';
const _JSHOP_YOO_SBBOL_LICENSE_TEXT2 = "<p>By using this program in any way, you fully and unconditionally accept the terms of the license agreement as posted at <a href=\"https://yoomoney.ru/doc.xml?id=527132\"> https://yoomoney.ru/doc.xml?id=527132 </a>(hereinafter referred to \"license agreement\"). If you do not accept any part of the terms of the license agreement, you are forbidden to use the program for any purpose.</p>";
const _JSHOP_YOO_SBBOL_NOTIFICATION_URL_LABEL = 'Address for notifications';
const _JSHOP_YOO_SBBOL_NOTIFICATION_URL_HELP_TEXT = 'Only required if YooMoney for business\'s specialists ask for it';
const _JSHOP_YOO_SBBOL_HEAD = 'For payments via Sberbank Business Online to work, the store must be connected to <a href="https://yookassa.ru/">ЮKassa</a>';
const _JSHOP_YOO_SBBOL_HELP_TEXT = 'There is a restriction for payments via Sberbank Business Online: one receipt can only contain products with the same VAT rate. If the client wants to pay for products with different VAT rates at the same time, we will show him the message explaining that it\'s not possible.';
const _JSHOP_YOO_SBBOL_TAX_RATES_HEAD = 'Compare the VAT rates in your store with the rates for Sberbank Business Online';
const _JSHOP_YOO_SBBOL_DESCRIPTION_TITLE = 'Transaction data';
const _JSHOP_YOO_SBBOL_DESCRIPTION_HELP = 'Full description of the transaction that the user will see during the checkout process. You can find it in your YooKassa Merchant Profile. For example, "Payment for order No. 72 by user@yoomoney.ru". Limitations: no more than 128 symbols.';
const _JSHOP_YOO_SBBOL_DEFAULT_TAX_LABEL = 'Default rate';
const _JSHOP_YOO_SBBOL_WITHOUT_VAT = 'Without VAT';
const _JSHOP_YOO_SBBOL_TAX_HELP = 'On the left is the VAT rate in your store, on the right — in ЮKassa. Please compare them.';
const _JSHOP_YOO_SBBOL_DESCRIPTION_DEFAULT_PLACEHOLDER = 'Payment for order No. %order_id%';
const _JSHOP_YOO_SBBOL_ERROR_MESSAGE_CREATE_PAYMENT = 'Unable to create the payment, choose another payment method.';