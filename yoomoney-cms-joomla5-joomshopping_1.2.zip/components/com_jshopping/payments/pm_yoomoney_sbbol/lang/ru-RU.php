<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

defined('_JEXEC') or die();

const _JSHOP_YOO_SBBOL_VERSION_DESCRIPTION = 'Версия модуля ';
const _JSHOP_YOO_SBBOL_KASSA_HEAD_LK = 'Свяжите ваш сайт на Joomla с магазином в ЮKassa';
const _JSHOP_YOO_SBBOL_KASSA_SHOP_ID_DESCRIPTION = 'Скопируйте shopId из личного кабинета ЮKassa';
const _JSHOP_YOO_SBBOL_KASSA_PASSWORD_LABEL = 'Секретный ключ';
const _JSHOP_YOO_SBBOL_KASSA_PASSWORD_DESCRIPTION = 'Выпустите и активируйте секретный ключ в личном кабинете ЮKassa. Потом скопируйте его сюда.';
const _JSHOP_YOO_SBBOL_COMMON_HEAD = 'Дополнительные настройки для администратора';
const _JSHOP_YOO_SBBOL_COMMON_STATUS = 'Статус заказа после оплаты';
const _JSHOP_YOO_SBBOL_LICENSE_TEXT2 = "<p>Любое использование Вами программы означает полное и безоговорочное принятие Вами условий лицензионного договора, размещенного по адресу <a href='https://yoomoney.ru/doc.xml?id=527132' target='_blank'>https://yoomoney.ru/doc.xml?id=527132</a> (далее – «Лицензионный договор»). Если Вы не принимаете условия Лицензионного договора в полном объёме, Вы не имеете права использовать программу в каких-либо целях.</p>";
const _JSHOP_YOO_SBBOL_NOTIFICATION_URL_LABEL = 'Адрес для уведомлений';
const _JSHOP_YOO_SBBOL_NOTIFICATION_URL_HELP_TEXT = 'Этот адрес понадобится, только если его попросят специалисты ЮKassa';
const _JSHOP_YOO_SBBOL_HEAD = 'Чтобы платежи через Сбербанк Бизнес Онлайн работали, магазин должен быть подключен к <a href="https://yookassa.ru/">ЮKassa</a>';
const _JSHOP_YOO_SBBOL_HELP_TEXT = 'При оплате через Сбербанк Бизнес Онлайн есть ограничение: в одном заказе могут быть только товары с одинаковой ставкой НДС. Если клиент захочет оплатить за один раз товары с разными ставками — мы покажем ему сообщение, что так сделать не получится.';
const _JSHOP_YOO_SBBOL_TAX_RATES_HEAD = 'Сопоставьте ставки НДС в вашем магазине со ставками для Сбербанка Бизнес Онлайн';
const _JSHOP_YOO_SBBOL_DESCRIPTION_TITLE = 'Описание платежа';
const _JSHOP_YOO_SBBOL_DESCRIPTION_HELP = 'Это описание транзакции, которое пользователь увидит при оплате, а вы — в личном кабинете ЮKassa. Например, «Оплата заказа №72».<br>
Чтобы в описание подставлялся номер заказа (как в примере), поставьте на его месте %order_id% (Оплата заказа №%order_id%).<br>
Ограничение для описания — 128 символов.';
const _JSHOP_YOO_SBBOL_DEFAULT_TAX_LABEL = 'Ставка по умолчанию';
const _JSHOP_YOO_SBBOL_WITHOUT_VAT = 'Без НДС';
const _JSHOP_YOO_SBBOL_TAX_HELP = 'Слева — ставка НДС в вашем магазине, справа — в ЮKassa. Пожалуйста, сопоставьте их.';
const _JSHOP_YOO_SBBOL_DESCRIPTION_DEFAULT_PLACEHOLDER = 'Оплата заказа №%order_id%';
const _JSHOP_YOO_SBBOL_ERROR_MESSAGE_CREATE_PAYMENT = 'Не удалось создать платёж, попробуйте выбрать другой способ оплаты.';