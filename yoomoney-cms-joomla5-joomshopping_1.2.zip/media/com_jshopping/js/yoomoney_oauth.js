jQuery(document).ready(function ($) {
    const buttonOauthConnect = $('button.btn-oauth-connect');
    const paymentId = $('input[name="payment_id"]').val();
    /**
     * Событие на кнопки Подключить магазин и Сменить магазин
     */
    buttonOauthConnect.click(function (e) {
        e.preventDefault();
        changeButton(true);
        fetchOauthLink();
    });

    /**
     * Запрос на бэк для получения ссылки на авторизацию в OAuth
     */
    function fetchOauthLink() {
        const formData = $('form#adminForm').serialize();
        $.ajax({
            method: 'GET',
            url: 'index.php',
            data: {
                option: 'com_jshopping',
                controller: 'payments',
                task: 'edit',
                payment_id: paymentId,
                subaction: 'get_oauth_url',
                form: formData
            },
            dataType: 'json',
            success: function (response) {
                if (response.oauth_url != null) {
                    showOauthWindow(response.oauth_url);
                } else {
                    addErrorBlock();
                }
            },
            error: function (response) {
                addErrorBlock();
                console.error(response.status, response.statusText);
            }
        });
    }

    /**
     * Показ окна с авторизацией в OAuth
     * @param url - Ссылка в OAuth
     */
    function showOauthWindow(url) {
        const oauthWindow = window.open(
            url,
            'Авторизация',
            'width=600,height=600, top=' + ((screen.height - 600) / 2) + ', left=' + ((screen.width - 600) / 2 + window.screenLeft) + ', menubar=no, toolbar=no, location=no, resizable=yes, scrollbars=no, status=yes');

        const timer = setInterval(function () {
            if (oauthWindow.closed) {
                clearInterval(timer);
                getOauthToken();
            }
        }, 1000);
    }

    /**
     * Инициализация получения OAuth токена
     */
    function getOauthToken() {
        $.ajax({
            method: 'GET',
            url: 'index.php',
            data: {
                option: 'com_jshopping',
                controller: 'payments',
                task: 'edit',
                payment_id: paymentId,
                subaction: 'get_oauth_token'
            },
            success: function (response) {
                if (response.status == null && response.error) {
                    addErrorBlock();
                    console.error(response);
                }
                if (response.error == null) {
                    location.reload();
                }
            },
            error: function (response) {
                addErrorBlock();
                console.error(response.status, response.statusText);
            }
        });
    }

    /**
     * Меняет состояние и текст кнопки
     * @param isDisabled - включение\отключение disabled режима кнопки
     * @param buttonText - текст для кнопки
     * @param isSpinner - включение\отключение режима прелоадера
     */
    function changeButton(isDisabled, buttonText = null, isSpinner = true) {
        buttonOauthConnect.attr('disabled', isDisabled);
        buttonOauthConnect.html(isSpinner === true ? '<span class="spinner qa-spinner"></span>' : buttonText);
    }

    /**
     * Добавляет блок с ошибкой при неуспешной oauth авторизации
     */
    function addErrorBlock() {
        const errorBlock = $('.connect-error');
        errorBlock.toggleClass('d-none d-block');
    }

    /**
     * Отображения хелпера к полю с url уведомлением для вебхуков
     * и установка значения для hidden поля с флагом на переустановку вебхуков
     */
    const notificationUrlInput = $('.yookassa-notify-url');
    const notificationUrlOld = notificationUrlInput.val();
    const isYookassaNewUrlHiddenField = $('#yookassa_new_url');
    notificationUrlInput.on('input', function() {
        const notificationUrlNew = notificationUrlInput.val();
        if (notificationUrlNew !== notificationUrlOld) {
            $('.change_url_helper').removeClass('d-none').addClass('d-block');
            isYookassaNewUrlHiddenField.val(1);
        } else {
            isYookassaNewUrlHiddenField.val(0);
        }
    });
});