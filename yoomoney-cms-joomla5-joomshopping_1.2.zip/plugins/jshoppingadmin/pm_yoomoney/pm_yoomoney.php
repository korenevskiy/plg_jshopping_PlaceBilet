<?php

/**
 * @package JoomShopping for Joomla!
 * @subpackage payment
 * @author YooMoney
 * @copyright Copyright (C) 2024 YooMoney. All rights reserved.
 */

use YooKassa\Common\Exceptions\ApiException;
use YooKassa\Common\Exceptions\BadApiRequestException;
use YooKassa\Common\Exceptions\ExtensionNotFoundException;
use YooKassa\Common\Exceptions\ForbiddenException;
use YooKassa\Common\Exceptions\InternalServerError;
use YooKassa\Common\Exceptions\NotFoundException;
use YooKassa\Common\Exceptions\ResponseProcessingException;
use YooKassa\Common\Exceptions\TooManyRequestsException;
use YooKassa\Common\Exceptions\UnauthorizedException;
use YooKassa\Model\Payment\PaymentStatus;
use YooKassa\Request\Payments\CreateCaptureRequest;
use YooMoney\Model\OrderModel;

defined('_JEXEC') or die('Restricted access');

require_once dirname(__FILE__) . '/../../../components/com_jshopping/payments/payment.php';
require_once dirname(__FILE__) . '/../../../components/com_jshopping/payments/pm_yoomoney/pm_yoomoney.php';
require_once dirname(__FILE__) . '/../../../components/com_jshopping/payments/pm_yoomoney/lib/Model/KassaSecondReceiptModel.php';

/**
 * Класс методов для обработки событий.
 */
class plgJshoppingAdminPm_yoomoney extends JPlugin
{
    /**
     * Обработчик события на изменение статуса заказа в админ панели.
     * При необходимости отправляет второй чек и создает записи в истории заказа.
     *
     * @param int $order_id Id заказа
     * @param string $status Новый статус заказа
     *
     * @return void
     * @throws ApiException
     * @throws BadApiRequestException
     * @throws ExtensionNotFoundException
     * @throws ForbiddenException
     * @throws InternalServerError
     * @throws NotFoundException
     * @throws ResponseProcessingException
     * @throws TooManyRequestsException
     * @throws UnauthorizedException
     */
    public function onBeforeChangeOrderStatusAdmin(int $order_id, string &$status): void
    {
        $paymentMethod = $this->getPaymentMethodTable();

        $all_payment_methods = $paymentMethod->getAllPaymentMethods();
        $pm_kassa            = null;

        foreach ($all_payment_methods as $pm) {
            $scriptName = ($pm->scriptname != '') ? $pm->scriptname : $pm->payment_class;
            if ($scriptName !== 'pm_yoomoney') {
                continue;
            }
            $pm_kassa = $pm;
            break;
        }

        if (!$pm_kassa) {
            return;
        }

        $pmconfig = $this->parsePaymentParams($pm_kassa->payment_params);

        $pm_yoomoney = new pm_yoomoney();
        $kassa = $pm_yoomoney->getKassaPaymentMethod($pmconfig);

        $pm_yoomoney->sendSecondReceipt($order_id, $kassa, $status);

        if (!$kassa->isEnableHoldMode()) {
            return;
        }

        $onHoldStatus   = $pmconfig['yookassa_hold_mode_on_hold_status'];
        $cancelStatus   = $pmconfig['yookassa_hold_mode_cancel_status'];
        $completeStatus = $pmconfig['kassa_transaction_end_status'];


        if (!in_array($status, array($completeStatus, $cancelStatus))) {
            return;
        }

        $order = $this->getOrderModel($order_id);

        if ($order->payment_method_id !== $pm_kassa->payment_id) {
            return;
        }

        if ($order->order_status !== $onHoldStatus) {
            return;
        }

        if ($status === $completeStatus) {
            $apiClient = $kassa->getClient();
            $payment = $apiClient->getPaymentInfo($pm_yoomoney->getDatabaseHelper()->getPaymentIdByOrderId($order->order_id));
            try {
                $builder = CreateCaptureRequest::builder();
                $builder->setAmount($order->order_total);

                if ($kassa->isSendReceipt()) {
                    $kassa->factoryReceipt($builder, $order->getAllItems(), $order);
                }

                $request = $builder->build();
                $payment = $apiClient->capturePayment($request, $payment->getId());
            } catch (\Exception $e) {
                $pm_yoomoney->log('error', 'Capture error: ' . $e->getMessage());
            }

            if (!$payment || $payment->getStatus() !== PaymentStatus::SUCCEEDED) {
                $status = $onHoldStatus;
                $pm_yoomoney->saveOrderHistory($order->order_id, _JSHOP_YOO_HOLD_MODE_CAPTURE_PAYMENT_FAIL);
                $pm_yoomoney->log('error', 'Capture payment error: capture failed');
                return;
            }
            $order->order_status = $completeStatus;
            $pm_yoomoney->saveOrderHistory($order->order_id, _JSHOP_YOO_HOLD_MODE_CAPTURE_PAYMENT_SUCCESS);


            $pm_yoomoney->sendSecondReceipt($order_id, $kassa, $completeStatus);

        }

        if ($status === $cancelStatus) {
            $apiClient = $kassa->getClient();
            $payment   = null;

            try {
                $payment = $apiClient->cancelPayment($order->transaction);
            } catch (\Exception $e) {
                $pm_yoomoney->log('error', 'Capture error: ' . $e->getMessage());
            }

            if (!$payment || $payment->getStatus() !== PaymentStatus::CANCELED) {
                $status = $onHoldStatus;
                $pm_yoomoney->saveOrderHistory($order->order_id, _JSHOP_YOO_HOLD_MODE_CANCEL_PAYMENT_FAIL);
                $pm_yoomoney->log('error', 'Cancel payment error: cancel failed');
                return;
            }
            $order->order_status = $cancelStatus;
            $pm_yoomoney->saveOrderHistory($order->order_id, _JSHOP_YOO_HOLD_MODE_CANCEL_PAYMENT_SUCCESS);
        }
    }

    /**
     * Парсит строку параметров в массив.
     *
     * @param string $params
     * @return array|null
     */
    private function parsePaymentParams(string $params): ?array
    {
        return json_decode($params, true);
    }

    /**
     * Получение таблицы платежных методов
     *
     * @return mixed
     */
    private function getPaymentMethodTable(): mixed
    {
        return JSFactory::getTable('paymentmethod', 'jshop');
    }

    /**
     * Обработка события перед сохранением модели платежного метода.
     *
     * @param array $post Входящие данные
     *
     * @return void
     * @throws Exception
     */
    public function onBeforeSavePayment(array &$post): void
    {
        if ($post['payment_class'] === 'pm_yoomoney_sbbol') {
            return;
        }

        $payment = $this->getPaymentMethodTable();
        $payment->load($post['payment_id']);

        $paymentParamsFromDB = $this->parsePaymentParams($payment->payment_params);

        $this->addFieldsToFormArray($post, $paymentParamsFromDB);
        $this->replaceWebhooksUrl($post);
    }

    /**
     * Добавление отсутствующих в форме данных по oauth.
     *
     * @param array $post Входящие данные
     * @param array|null $paymentParamsFromDB Сохраненные данные в БД
     *
     * @return void
     */
    private function addFieldsToFormArray(array &$post, ?array $paymentParamsFromDB = []): void
    {
        $nameFieldForSave = array(
            'shop_id',
            'state',
            'access_token',
            'expires_in'
        );

        $oauthDataArray = array();
        foreach ($paymentParamsFromDB as $key => $value) {
            if (in_array($key, $nameFieldForSave)) {
                $oauthDataArray[$key] = $value;
            }
        }

        $post['pm_params'] = array_merge($post['pm_params'], $oauthDataArray);
    }

    /**
     * Замена url вебхуков.
     *
     * @param array $post
     *
     * @return void
     * @throws Exception
     */
    private function replaceWebhooksUrl(array &$post): void
    {
        $isChangeUrl = (bool) $post['pm_params']['yookassa_new_url'];
        $notificationUrlNew = $post['pm_params']['notification_url'];
        unset($post['pm_params']['notification_url'], $post['pm_params']['yookassa_new_url']);
        if (!isset($post['pm_params']['kassamode']) || !$isChangeUrl) {
            return;
        }
        $pm_yoomoney = new pm_yoomoney();
        $webhookHelper = $pm_yoomoney->getOauthWebhooksHelper();

        try {
            $pm_yoomoney->log('info', 'Notification URL changed. Replacing webhooks.');
            $webhookHelper->replaceWebhooksWithNewUrl($notificationUrlNew);
        } catch (Exception $e) {
            $pm_yoomoney->log('error', 'Failed to replace webhooks URL', ['exception' => $e]);
            return;
        }
    }

    /**
     * Возвращает класс методов для работы с заказами.
     *
     * @param int $orderId Id заказа
     *
     * @return OrderModel
     */
    private function getOrderModel(int $orderId): OrderModel
    {
        return new OrderModel($orderId);
    }
}
