qr.js
=====

A javascript QR Code scanning library for html5 webcams

Run this on a server and view in a browser.

    python -m SimpleHTTPServer 4444
    
and navigate to `localhost:4444`

The user must grant permission to access the camera.


NOTE:
For android chrome the front-facing camera is used.
