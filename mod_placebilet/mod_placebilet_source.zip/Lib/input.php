<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */
 
namespace Joomla\Module\Placebilet\Administrator\Input;

//TicketData
class InputObject{
	public int $id = 0;
	public int $eventID = 0;
	public int $orderID = 0;
	public string $method = '';
	public string $QRcode = '';
	public string $format = '';
	public string $token = '';
	public string $action = '';
}