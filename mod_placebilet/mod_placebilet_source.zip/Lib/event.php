<?php

 
namespace API\Kultura\Pushka;

require_once __DIR__ . '/data.php';

class Event extends PushkaData{
	
/** Статус: active, visited, refunded, canceled* */	
public string $status = '';
	
/** ID мероприятия в PRO.Культура* */	
public string $session_event_id = '';
	
/** ID организации в Про.Культура* */	
public string $session_organization_id = '';
	
/** Дата/Время проведения сеанса (unix timestamp)* */	
public int $session_date = 0;
	
/** Адрес/описание места проведения мероприятия */	
public string $session_place = '';

/** Зал+Сектор+Ряд+Место */	
public string $session_params = '';
	   
	
	/**
	 * @var array $filter POST: Добавление билета в реестр
	 * Добавить в реестр информацию о билете, купленном по Пушкинской карте
	 * /tickets
	 */
	public static array $filter = [
		"status"=> "string",		// * Статус
		"session"=> [
			"event_id"=> "string",		//  *ID мероприятия в PRO.Культура
			"organization_id"=> "string",//*ID организации в Про.Культура
			"date"=> "int",				//  *Дата/Время проведения сеанса (unix timestamp)
			"place"=> "string",			//  Адрес/описание места проведения мероприятия
			"params"=> "string",		//  Зал+Сектор+Ряд+Место
			
		],
	];
//{
// "status": "active",
//  "session": {
//    "event_id": "string",
//    "organization_id": "string",
//    "date": 0,
//    "place": "string",
//    "params": "string"
//  }
//}
}