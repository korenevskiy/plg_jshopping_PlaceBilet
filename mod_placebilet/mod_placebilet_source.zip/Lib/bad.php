<?php

 
namespace API\Kultura\Pushka;

require_once __DIR__ . '/data.php';

/**
 * Ошибка данных
 */
class Bad extends PushkaData{
	
	/** *Код ошибки */
	public string $code = '';

	/** *Успех */
	public bool	$success = false;
	
	/** Сообщение ошибки */
	public string $message = '';

	/** Описание ошибки */	
	public string $description = '';

	public $result = false;
	
	/**
	 * @var array $filter POST: Добавление билета в реестр
	 * Добавить в реестр информацию о билете, купленном по Пушкинской карте
	 */
	public static array $filter = [
		"code"=> "string",			// * Код ошибки
		"description"=> "string",	// Описание ошибки 
		"success"=> "bool",			// * Успех
		"message"=> "string",		// Сообщение ошибки
	];
}