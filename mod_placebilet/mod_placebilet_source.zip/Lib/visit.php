<?php

 
namespace API\Kultura\Pushka;

require_once __DIR__ . '/data.php';

/**
 * Гашение билета
 */
class Visit extends PushkaData{

	/** Дата погашения билета (unix timestamp)* */	
	public int $visit_date;

	/** Статус билета: active, visited, refunded, canceled (*Обязательный для возврата*) */	
	public string $status  = '';

	/** Комментарий */	
	public string $comment  = '';
	   
	
	/**
	 * @var array $filter POST: Добавление билета в реестр
	 * Добавить в реестр информацию о билете, купленном по Пушкинской карте
	 * /tickets
	 */
	public static array $filter = [
		"visit_date"=> "int",		// * Код ошибки
		"status"=> "string",		// active, visited, refunded, canceled
		"comment"=> "string",		// Комментарий
	];
}