<?php

\defined('_JEXEC') or die;

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

use API\Kultura\Pushka\Event;
use Joomla\CMS\Language\Text as JText;
//use API\Kultura\Pushka\PushkaData;

 
extract($displayData);

/** 
 * @var API\Kultura\Pushka\Event
 * @param API\Kultura\Pushka\Event
 */

//$bilet = Event::new();
//$status;
//$session_place;
//$session_params;
//$session_date;
//$session_event_id;
//$session_organization_id;

//$status = strtoupper($status);
 
echo "<hr>";

if($session_date == 0){
	echo "<h4 class='statusPushka none'>";
	echo JText::_('JSHOP_PUSHKA_STATUS_NONE');
	echo "</h4>";
	return;
	// <pre><?= print_r($displayData, true) ? >  </pre>
}

?>
<h4 class="statusPushka <?= $status?>">
	<?= JText::_('JSHOP_PUSHKA_STATUS_'.strtoupper($status)) ?>
</h4>
<div>
	<?= $session_date ?> <br>
	<?= $session_params ?>  <br>
	<?= $session_place ?>  <br>
</div>
