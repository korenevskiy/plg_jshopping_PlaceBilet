<?php

\defined('_JEXEC') or die;

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

use API\Kultura\Pushka\Event;
use API\Kultura\Pushka\Bad;
use Joomla\CMS\Language\Text as JText;
//use API\Kultura\Pushka\PushkaData;

 
extract($displayData);

/** 
 * @var API\Kultura\Pushka\Event
 * @param API\Kultura\Pushka\Event
 */

//$bilet = Bad::new();
$code;
$description;
$result;


//$status = strtoupper($status);
?>
<hr>
 

<h4>
	<?= JText::_('JSHOP_PUSHKA_STATUS_'.strtoupper($code)) ?>
</h4>
<div>
	<?= JText::_($description) ?> / <?= $message ?>  
</div>
