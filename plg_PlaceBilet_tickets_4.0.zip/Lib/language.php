<?php
 /** ----------------------------------------------------------------------
 * plg_PlaceBilet - Plugin Joomshopping Component for CMS Joomla
 * ------------------------------------------------------------------------
 * author    Sergei Borisovich Korenevskiy
 * @copyright (C) 2019 //explorer-office.ru. All Rights Reserved. 
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 * @package		Jshopping
 * @subpackage  plg_placebilet
 * Websites: //explorer-office.ru/download/
 * Technical Support:  Forum - //fb.com/groups/multimodulefb.com/groups/placebilet/
 * Technical Support:  Forum - //vk.com/placebilet
 * -------------------------------------------------------------------------
 **/

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//use Joomla\String\StringHelper;
//class PlaceBiletLanguage implements Joomla\CMS\Language
//{
//    
//	public static function setString($string, $text = '', $lang)
//	{
//            if(isset())
//            
//		if (!isset(self::$languages[$lang . $debug]))
//		{
//                    self::$languages[$lang . $debug]-> =
//			//self::$languages[$lang . $debug] = new JLanguage($lang, $debug);
//		}
//
//		return self::$languages[$lang . $debug];
//	}
//    
//    
//	public static function getInstance($lang, $debug = false)
//	{
//		if (!isset(self::$languages[$lang . $debug]))
//		{
//			self::$languages[$lang . $debug] = new JLanguage($lang, $debug);
//		}
//
//		return self::$languages[$lang . $debug];
//	}
//}