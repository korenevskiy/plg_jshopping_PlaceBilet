<?php
 
/**
* @version      4.11.0 10.08.2014
* @author       MAXXmarketing GmbH
* @package      Jshopping
* @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
* @license      GNU/GPL
*/
defined('_JEXEC') or die();
jimport('joomla.html.pagination');
// toPrint($file);
class JshoppingControllerSearch_mod extends JshoppingControllerSearch{
    
    function result(){
        $word = PlaceBiletHelper::JRequest()->getString('search');
        return;
		
		parent::result();
         
    }
}