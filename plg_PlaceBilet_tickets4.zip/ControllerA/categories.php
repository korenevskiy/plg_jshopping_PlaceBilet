<?php
/**
* @version      4.14.4 20.05.2016
* @author       MAXXmarketing GmbH
* @package      Jshopping
* @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
* @license      GNU/GPL
*/

defined('_JEXEC') or die();

jimport('joomla.application.component.controller');

class JshoppingControllerCategoriesMod extends JshoppingControllerCategories{// extends JshoppingControllerBaseadmin
    
	function getFactory(){
		return $this->factory;
	}
	function setFactory($factory = null){
		if($factory)
			$this->factory = $factory;
	}

// Член требуемый для J4, для совместимости J3 отключен, но компенсируется $config['default_view'] в конструкторе
//	protected $name = 'Categories';
	
	protected $default_view = 'Categories';
	
    function __construct( $config = array(), \Joomla\CMS\MVC\Factory\MVCFactoryInterface $factory = null, $app = null, $input = null ){
        $this->nameController = 'categories';
        $this->nameModel = 'categories';
        parent::__construct($config, $factory, $app, $input); 
    }
    
    public function save(){ 
        $post = $this->input->post->getArray();
//        JDispatcher::getInstance()->trigger('onBeforeSaveCategory', array(&$post));		
        \JFactory::getApplication()->triggerEvent('onBeforeSaveCategory', array(&$post));
		
        parent::save();
    }
}