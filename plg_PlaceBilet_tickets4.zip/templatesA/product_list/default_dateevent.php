<td class="date_event">
    <?php 
	extract($displayData);
    //echo formatdate($product_date_added, 1);
    $week_Days = date('N', strtotime($date_event)); 
    $opacity = 0.8;
    if($week_Days == 6)
        $opacity = 0.3;
    if($week_Days < 6)
        $opacity = 0.1*$week_Days;
    $color = ($week_Days < 6)? "rgba(255,226,148,$opacity)":"rgba(132,224,219,$opacity)";
    echo "<div style='width:100px;background-color:$color;'>".strftime("%e ",strtotime($date_event)). JText::_(strftime("%B",strtotime($date_event))). strftime(" %G",strtotime($date_event)). '</div>'
            . '<b style="font-size:24px;">'.strftime("%R",strtotime($date_event))."</b><span style=' ' class=''> ".JText::_(strftime("%a",strtotime($date_event)))."</span>";//formatdate($date_event, 1). strftime("%R:%M",$date_event) Изменено product_date_added на date_event изменено-добавленно
    ?>
</td>