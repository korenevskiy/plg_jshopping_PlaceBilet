<?php
/**
* @version      
* @author       MAXXmarketing GmbH
* @package      Jshopping
* @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
* @license      GNU/GPL
*/

defined('_JEXEC') or die();

extract($displayData) ;

//foreach ($displayData as $var => $val)
//	$this->$var = $val;

//toPrint(array(get_object_vars($product)),'Procuct Properies',true, 'message' );

?>

<!-- <div class="bil"> -->
<div class="bilet">
        <?php if($params->text_prod_city&&$params->view_text)
		{ ?><div class="moskva Moscow city"><?=$params->text_prod_city?></div><?php }?>
        <?php if($params->text_prod_order && $params->view_text) 
		{ ?><div class="buttons controlZak order"><?=$params->text_prod_order?></div><?php }?>
        <h2><?php print $product->name?>
			<?php if ($config->show_product_code)
			{?> <span class="jshop_code_prod">(<?php print __('JSHOP_EAN')?>: <span id="product_code"><?php print $product->getEan();?></span>)</span><?php }?>
		</h2>
<!-- 		<div class="text_desc"> -->
<!-- 		<div class="date product"> -->
		<?php 
        $datetime = $td = strtotime($product->date_event);
        $dt = $product->date_event;
//toPrint($product->date_event,'$datetime',true, 'message' );
        ?>
<?php if($params->tagDateTimeWithLink ?? false){
	$product_url = $product->product_url ?: JRoute::_("index.php?option=com_jshopping&view=product&task=view&category_id=$product->main_category_id&product_id=$product->product_id");
	echo "<a href='$product_url'>" ;
}?>
				<time datetime="<?= $dt?>" class="date"  title="<?= $dt ?>">
					<?php if($params->tagDateTimeWithYear ?? false) 
						echo "<span class='lbl jtime'>" .  JText::_('JYEAR'). ":</span> <span class='year'>". date("Y", $td) . "</span><br/>" ?>
					<span class="lbl jdate"><?= JText::_('JDATE')?>:</span> <span class="day"><?= date("j", $td); ?></span><span class="month"  title="<?php echo $dt ?>"> <?= JText::_(date("F", $td))?></span><br/>
					<span class="lbl jday"><?= JText::_('JDAY')?>:</span> <span class="weekday"><?= JText::_(date("l", $td))?></span><br/>
					<span class="lbl jtime"><?= JText::_('JTIME')?>:</span> <span class="time"><?= date("H:i", $td); ?></span><br/>
				</time>
<?php if($params->tagDateTimeWithLink ?? false) echo "</a>" ?>
<!-- 			</div> -->
            <input type="hidden" name="date_event"   class="hide" value="<?php echo $product->date_event ?>" />
            <input type="hidden" name="date_modify"   class="hide" value="<?php echo $product->date_modify ?>" />
<!--         </div> -->
        <div class="jshop_short_description">
            <?php print $product->short_description; ?>
        </div>
</div>
<!-- </div> -->