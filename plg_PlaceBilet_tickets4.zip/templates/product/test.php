<?php
/**
* @version      
* @author       MAXXmarketing GmbH
* @package      Jshopping
* @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
* @license      GNU/GPL
*/

use \Joomla\CMS\Factory as JFactory;
use \Joomla\CMS\Document\HtmlDocument as JDocument;

defined('_JEXEC') or die();


if(class_exists('PlaceBiletHelper'))
    $params = \PlaceBiletHelper::$param->toObject();//Registry
    
settype($displayData, 'object');

//toPrint($displayData,'$html',true,'message');

?>

<div class="testAttr">

<?php 

echo "<h4>$displayData->title</h4>";


echo "<b>$displayData->cost</b>";

echo "<p>$displayData->description</p>";

?>

</div>