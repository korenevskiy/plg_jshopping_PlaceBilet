<?php
/*
* 154 - 311 нужный модуль строки,
* код добавленный начинается на 201 заканчивается на 301
* ==========================================================

* Show a notice so the user knows the ticket was checked in.
*/

function admin_notice() {

	if ( empty( $_GET['qr_checked_in'] ) ) {
		return;
	}

	// Use Human-readable ID Where Available for QR Check in Message.
	$ticket_id = absint( $_GET['qr_checked_in'] );
	$no_match = isset( $_GET['no_security_code_match'] ) ? absint( $_GET['no_security_code_match'] ) : false;
	$ticket_status = get_post_status( $ticket_id );
	$checked_status = get_post_meta( $ticket_id, '_tribe_qr_status', true );
	$ticket_unique_id = get_post_meta( $ticket_id, '_unique_id', true );
	$ticket_id = $ticket_unique_id === '' ? $ticket_id : $ticket_unique_id;

	// If the attendee was deleted.
	if ( false === $ticket_status || 'trash' === $ticket_status ) {
		echo '<div class="error"><p>';
		printf( esc_html__( 'The ticket with ID %s was deleted and cannot be checked-in.', 'event-tickets-plus' ), esc_html( $ticket_id ) );
		echo '</p></div>';

	// If Security Code does not match
	} elseif ( $no_match ) {
		echo '<div class="error"><p>';
		printf( esc_html__( 'The security code for ticket with ID %s does not match.', 'event-tickets-plus' ), esc_html( $ticket_id ) );
		echo '</p></div>';



	// If status is QR then display already checked-in warning.
	} elseif ( $checked_status ) {

		$order_idforcheckin1 = absint( $_GET['qr_checked_in'] );
		$order_idforcheckin = $order_idforcheckin1 - 1;
		
		//dd($order_idforcheckin);

		echo '<div class="error"><p>';
		printf( esc_html__( 'The ticket with ID %s has already been checked in.', 'event-tickets-plus' ), esc_html( $ticket_id ) );
		echo '</p></div>';

	// Otherwise, just check-in like normal.
	} else {


		$qrr = $ticket_id;

		$order_idforcheckin1 = absint( $_GET['qr_checked_in'] );
		$order_idforcheckin = $order_idforcheckin1 - 1;

		//$order_idforcheckin = $attendee['order_id'];

		//dd($qrr);

		global $wpdb;
		//$gos = $wpdb->get_row( "SELECT * FROM ticket_id WHERE ticket_kci = '$qrr'" );
		$gos = $wpdb->get_row( "SELECT * FROM ticket_id WHERE ticket_id = '$order_idforcheckin'" );

		$gosId = $gos->gos_id;
		//dd($gosId);

		$visit_date = time();

		//dd($visit_date);

		//settype($refaundDate, 'integer');

		$ticketId = $gosId;
		$url = 'https://pushka.gosuslugi.ru/api/v1/tickets/'. $ticketId . '/visit';
		// $ch = curl_init('https://pushka-uat.test.gosuslugi.ru/api/v1/tickets');

		//dd($url);

		$data = [
			'visit_date' => $visit_date
		];

		$jsonData = json_encode($data);

		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST,'PUT');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_TIMEOUT, 4000);
		curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
		curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer хххххххх']);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);

		$curlResult = curl_exec($ch);

		//dd($curlResult);

		if ($curlResult === FALSE) {
			$curlerror = curl_error($ch);
		}


		$curlinfo = curl_getinfo($ch);


		//$string = ($array);



		//new_str = $curlinfo;

		$new_str2 = serialize($curlinfo);
		$timeqr = time();
		$dateqr = date("Передача данных автоматическая d.m.y H:i");
		$localtime = time() + 25200;
		$visited_normal = date('d.m.y H:i', $localtime);


		//$time = time() + 10;
		//echo date('d.m.Y H:i:s', $localtime); // 03.12.2021 22:17:10


		$filename = __DIR__ . '/curlinfo.log';

		curl_close($ch);

		$array = json_decode($curlResult, true);



		//dd($result);

		$fh = fopen($filename, 'c');
		fseek($fh, 0, SEEK_END);
		fwrite($fh, PHP_EOL . $timeqr);
		fwrite($fh, PHP_EOL . $dateqr);
		fwrite($fh, PHP_EOL . $jsonData);
		fwrite($fh, PHP_EOL . $resultqr);
		fwrite($fh, PHP_EOL . $new_str);
		fclose($fh);





		//обновляем строку текущего заказа кодом безопасности $gos = $wpdb->get_row( "SELECT * FROM ticket_id WHERE ticket_kci = '$qrr'" );
		global $wpdb;

		$wpdb->update( 'ticket_id',
			//[ 'visited_unix' => $time],
			[ 'visited_normal' => $visited_normal],
			[ 'ticket_id' => $order_idforcheckin]
		);

		//dd($qrr);

		//return $array['id'];

		echo '<div class="updated"><p>';
		printf( esc_html__( 'The ticket with ID %s was checked in.', 'event-tickets-plus' ), esc_html( $ticket_id ) );
		echo '</p></div>';



		// Update the checked-in status when using the QR code here.
		update_post_meta( absint( $_GET['qr_checked_in'] ), '_tribe_qr_status', 1 );

	}

}