<?php
/*
Пример кода обмена с билетным реестром часть вторая
Данный код, опыт написания практически с нулевыми знаниями PHP, потому что было надо, и другого выхода не было. Но код работает, данные передает.

Данная информация предоставляется as is, и мы не несем никакой ответственности, если она будет работать некорректно, или не будет работать вовсе.
Информация предназначена для ознакомления с алгоритмом.
Перечень
часть первая,
передача barcode тут в тестовом режиме, в другой части будет barcode для предачи в приложение Госуслуги Культура

Передача данных в билетный реестр при посещении при сканировании QR кода сканером подключенным к компьютеру, передача данных в API visit date
Передача данных в билетный реестр при посещении при сканировании QR кода приложением на мобильном телефоне, передача данных в API visit date
Передача данных в билетный реестр при продаже билета, в Сбербанке, запрет покупки нескольких билетов по Пушке, передача данных в API создание записи в реестре это основной модуль передачи данных на Госуслуги и основной модуль оплаты билетов по Пушкинской карте через интернет
часть вторая

Передача данных в билетный реестр о посещении, при ручном гашении билетов в реестре проданных билетов интернет магазина (кнопкой “Погасить билет”), передача данных в API visit date
Передача данных в билетный реестр из страницы деталей заказа, выпадающее меню, правый верхний угол, “Отправка данных о гашении на Госуслуги” API visit date
Передача данных в билетный реестр о новом заказе, создание записи в реестре Госуслуг, из страницы деталей заказа, выпадающее меню, правый верхний угол, “Отправка данных заказа на Госуслуги”
Передача данных в билетный реестр о посещении, при ручном гашении билетов в реестре проданных билетов интернет магазина (кнопкой “Погасить билет”), передача данных в API visit date

Это гашение в разделе События кнопкой передача по AJAX,

348 - 477 нужный модуль строки,

код добавленный начинается на 383 заканчивается на 473
 */


//Metabox.php


/**
 * Class in charge of registering and displaying
 * the tickets metabox in the event edit screen.
 * Metabox will only be added if there's a
 * Tickets Pro provider (child of TribeTickets)
 * available.
 */

 class Tribe__Tickets__Metabox {



 /**

 * Configure all action and filters user by this Class

 *

 * @return void

 */

 public function hook() {

 add_action( 'add_meta_boxes', array( $this, 'configure' ) );



 add_action( 'tribe_events_tickets_bottom_right', array( $this, 'get_ticket_controls' ), 10, 2 );



 add_action( 'wp_ajax_tribe-ticket-panels', array( $this, 'ajax_panels' ) );



 add_action( 'wp_ajax_tribe-ticket-add', array( $this, 'ajax_ticket_add' ) );

 add_action( 'wp_ajax_tribe-ticket-edit', array( $this, 'ajax_ticket_edit' ) );

 add_action( 'wp_ajax_tribe-ticket-delete', array( $this, 'ajax_ticket_delete' ) );



 add_action( 'wp_ajax_tribe-ticket-checkin', array( $this, 'ajax_attendee_checkin' ) );

 add_action( 'wp_ajax_tribe-ticket-uncheckin', array( $this, 'ajax_attendee_uncheckin' ) );

 }



 /**

 * Configures the Tickets Editor into a Post Type

 *

 * @since 4.6.2

 *

 * @param string $post_type Which post type we are trying to configure

 *

 * @return void

 */

 public function configure( $post_type = null ) {

 $modules = Tribe__Tickets__Tickets::modules();

 if ( empty( $modules ) ) {

 return;

 }



 if ( ! in_array( $post_type, Tribe__Tickets__Main::instance()->post_types() ) ) {

 return;

 }



 add_meta_box(

 'tribetickets',

 esc_html( tribe_get_ticket_label_plural( 'meta_box_title' ) ),

 array( $this, 'render' ),

 $post_type,

 'normal',

 'high',

 array(

 '__back_compat_meta_box' => true,

 )

 );



 // If we get here means that we will need Thickbox

 add_thickbox();

 }



 /**

 * Render the actual Metabox

 *

 * @since 4.6.2

 *

 * @param int $post_id Which post we are dealing with

 *

 * @return string|bool

 */

 public function render( $post_id ) {

 $modules = Tribe__Tickets__Tickets::modules();



 if ( empty( $modules ) ) {

 return false;

 }



 $post = get_post( $post_id );



 // Prepare all the variables required.

 $start_date = date( 'Y-m-d H:00:00' );

 $end_date = date( 'Y-m-d H:00:00' );

 $start_time = Tribe__Date_Utils::time_only( $start_date, false );

 $end_time = Tribe__Date_Utils::time_only( $start_date, false );



 $show_global_stock = Tribe__Tickets__Tickets::global_stock_available();

 $tickets = Tribe__Tickets__Tickets::get_event_tickets( $post->ID );

 $global_stock = new Tribe__Tickets__Global_Stock( $post->ID );



 /** @var Tribe__Tickets__Admin__Views $admin_views */

 $admin_views = tribe( 'tickets.admin.views' );



 return $admin_views->template( [ 'editor', 'metabox' ], get_defined_vars() );

 }



 /**

 * Refreshes panels after ajax calls that change data

 *

 * @since 4.6.2

 *

 * @return string html content of the panels

 */

 public function ajax_panels() {

 $post_id = absint( tribe_get_request_var( 'post_id', 0 ) );



 // Didn't get a post id to work with - bail

 if ( ! $post_id ) {

 wp_send_json_error( esc_html__( 'Invalid Post ID', 'event-tickets' ) );

 }



 // Overwrites for a few templates that use get_the_ID() and get_post()

 global $post;



 $post = get_post( $post_id );

 $data = wp_parse_args( tribe_get_request_var( array( 'data' ), array() ), array() );

 $notice = tribe_get_request_var( 'tribe-notice', false );



 $data = Tribe__Utils__Array::get( $data, array( 'tribe-tickets' ), null );



 /** @var Tribe__Tickets__Tickets_Handler $tickets_handler */

 $tickets_handler = tribe( 'tickets.handler' );



 // Save if the info was passed

 if ( ! empty( $data ) ) {

 $tickets_handler->save_order( $post->ID, isset( $data['list'] ) ? $data['list'] : null );

 $tickets_handler->save_form_settings( $post->ID, isset( $data['settings'] ) ? $data['settings'] : null );

 }



 $return = $this->get_panels( $post );

 $return['notice'] = $this->notice( $notice );



 /**

 * Allows filtering the data by other plugins/ecommerce solutions©

 *

 * @since 4.6

 *

 * @param array the return data

 * @param int the post/event id

 */

 $return = apply_filters( 'tribe_tickets_ajax_refresh_tables', $return, $post->ID );



 wp_send_json_success( $return );

 }



 /**

 * Get the Panels for a given post.

 *

 * @since 4.6.2

 *

 * @param int|WP_Post $post

 * @param int $ticket_id

 *

 * @return array

 */

 public function get_panels( $post, $ticket_id = null ) {

 if ( ! $post instanceof WP_Post ) {

 $post = get_post( $post );

 }



 // Bail on invalid post.

 if ( ! $post instanceof WP_Post ) {

 return [];

 }



 // Overwrites for a few templates that use get_the_ID() and get_post()

 $GLOBALS['post'] = $post;



 // Let's create tickets list markup to return

 $tickets = Tribe__Tickets__Tickets::get_event_tickets( $post->ID );



 /** @var Tribe__Tickets__Admin__Views $admin_views */

 $admin_views = tribe( 'tickets.admin.views' );



 $panels = [

 'list' => $admin_views->template( 'editor/panel/list', [ 'post_id' => $post->ID, 'tickets' => $tickets ], false ),

 'settings' => $admin_views->template( 'editor/panel/settings', [ 'post_id' => $post->ID ], false ),

 'ticket' => $admin_views->template( 'editor/panel/ticket', [ 'post_id' => $post->ID, 'ticket_id' => $ticket_id ], false ),

 ];



 return $panels;

 }



 /**

 * Sanitizes the data for the new/edit ticket ajax call, and calls the child save_ticket function.

 *

 * @since 4.6.2

 * @since 4.10.9 Use customizable ticket name functions.

 */

 public function ajax_ticket_add() {

 $post_id = absint( tribe_get_request_var( 'post_id', 0 ) );



 if ( ! $post_id ) {

 wp_send_json_error( esc_html__( 'Invalid parent Post', 'event-tickets' ) );

 }



 /**

 * This is needed because a provider can implement a dynamic set of fields.

 * Each provider is responsible for sanitizing these values.

 */

 $data = wp_parse_args( tribe_get_request_var( array( 'data' ), array() ), array() );



 if ( ! $this->has_permission( $post_id, $_POST, 'add_ticket_nonce' ) ) {

 wp_send_json_error( esc_html( sprintf( __( 'Failed to add the %s. Refresh the page to try again.', 'event-tickets' ), tribe_get_ticket_label_singular( 'ajax_ticket_add_error' ) ) ) );

 }



 if ( ! isset( $data['ticket_provider'] ) || ! $this->module_is_valid( $data['ticket_provider'] ) ) {

 wp_send_json_error( esc_html__( 'Commerce Provider invalid', 'event-tickets' ) );

 }



 // Get the Provider

 $module = call_user_func( [ $data['ticket_provider'], 'get_instance' ] );



 if ( ! $module instanceof Tribe__Tickets__Tickets ) {

 return new WP_Error(

 'bad_request',

 __( 'Commerce Module invalid', 'event-tickets' ),

 [ 'status' => 400 ]

 );

 }



 // Do the actual adding

 $ticket_id = $module->ticket_add( $post_id, $data );



 // Successful?

 if ( $ticket_id ) {

 /**

 * Fire action when a ticket has been added

 *

 * @param int $post_id ID of parent "event" post

 */

 do_action( 'tribe_tickets_ticket_added', $post_id );

 } else {

 wp_send_json_error( esc_html( sprintf( __( 'Failed to add the %s', 'event-tickets' ), tribe_get_ticket_label_singular( 'ajax_ticket_add_error' ) ) ) );

 }



 $return = $this->get_panels( $post_id );

 $return['notice'] = $this->notice( 'ticket-add' );



 /**

 * Filters the return data for ticket add

 *

 * @param array $return Array of data to return to the ajax call

 * @param int $post_id ID of parent "event" post

 */

 $return = apply_filters( 'event_tickets_ajax_ticket_add_data', $return, $post_id );



 wp_send_json_success( $return );

 }



 /**

 * Returns the data from a single ticket to populate the edit form.

 *

 * @since 4.6.2

 * @since 4.10.9 Use customizable ticket name functions.

 * @since 4.12.3 Update detecting ticket provider to account for possibly inactive provider. Remove unused vars.

 */

 public function ajax_ticket_edit() {

 $post_id = absint( tribe_get_request_var( 'post_id', 0 ) );



 if ( ! $post_id ) {

 wp_send_json_error( esc_html__( 'Invalid parent Post', 'event-tickets' ) );

 }



 $ticket_id = absint( tribe_get_request_var( 'ticket_id', 0 ) );



 if ( ! $ticket_id ) {

 wp_send_json_error( esc_html( sprintf( __( 'Invalid %s', 'event-tickets' ), tribe_get_ticket_label_singular( 'ajax_ticket_edit_error' ) ) ) );

 }



 if ( ! $this->has_permission( $post_id, $_POST, 'edit_ticket_nonce' ) ) {

 wp_send_json_error( esc_html( sprintf( __( 'Failed to edit the %s. Refresh the page to try again.', 'event-tickets' ), tribe_get_ticket_label_singular( 'ajax_ticket_edit_error' ) ) ) );

 }



 $provider = tribe_tickets_get_ticket_provider( $ticket_id );



 if ( empty( $provider ) ) {

 wp_send_json_error( esc_html__( 'Commerce Module invalid', 'event-tickets' ) );

 }



 $return = $this->get_panels( $post_id, $ticket_id );



 /**

 * Provides an opportunity for final adjustments to the data used to populate

 * the edit-ticket form.

 *

 * @param array $return Data for the JSON response

 * @param int $post_id Post ID

 * @param int $ticket_id Ticket ID

 */

 $return = (array) apply_filters( 'tribe_events_tickets_ajax_ticket_edit', $return, $post_id, $ticket_id );



 wp_send_json_success( $return );

 }



 /**

 * Sanitizes the data for the delete ticket ajax call, and calls the child delete_ticket

 * function.

 *

 * @since 4.6.2

 */

 public function ajax_ticket_delete() {

 $post_id = absint( tribe_get_request_var( 'post_id', 0 ) );



 if ( ! $post_id ) {

 wp_send_json_error( esc_html__( 'Invalid parent Post', 'event-tickets' ) );

 }



 $ticket_id = absint( tribe_get_request_var( 'ticket_id', 0 ) );



 if ( ! $ticket_id ) {

 wp_send_json_error( esc_html( sprintf( __( 'Invalid %s', 'event-tickets' ), tribe_get_ticket_label_singular( 'ajax_ticket_delete_error' ) ) ) );

 }



 if ( ! $this->has_permission( $post_id, $_POST, 'remove_ticket_nonce' ) ) {

 wp_send_json_error( esc_html( sprintf( __( 'Failed to delete the %s. Refresh the page to try again.', 'event-tickets' ), tribe_get_ticket_label_singular( 'ajax_ticket_delete_error' ) ) ) );

 }



 $provider = tribe_tickets_get_ticket_provider( $ticket_id );



 if ( empty( $provider ) ) {

 wp_send_json_error( esc_html__( 'Commerce Module invalid', 'event-tickets' ) );

 }



 // Pass the control to the child object

 $return = $provider->delete_ticket( $post_id, $ticket_id );



 // Successfully deleted?

 if ( $return ) {

 $return = $this->get_panels( $post_id );

 $return['notice'] = $this->notice( 'ticket-delete' );



 /**

 * Fire action when a ticket has been deleted

 *

 * @param int $post_id ID of parent "event" post

 */

 do_action( 'tribe_tickets_ticket_deleted', $post_id );

 }



 wp_send_json_success( $return );

 }



 /**

 * Handles the check-in ajax call, and calls the checkin method.

 *

 * @since 4.6.2

 * @since 4.12.3 Use new helper method to account for possibly inactive ticket provider.

 */

 public function ajax_attendee_checkin() {

 $event_id = Tribe__Utils__Array::get( $_POST, 'event_ID', false );

 $attendee_id = Tribe__Utils__Array::get( $_POST, 'attendee_id', false );



 if ( empty( $attendee_id ) ) {

 wp_send_json_error( __( 'The attendee ID is missing from the request parameters.', 'event-tickets' ) );

 }



 $provider = Tribe__Utils__Array::get( $_POST, 'provider', false );



 $provider = Tribe__Tickets__Tickets::get_ticket_provider_instance( $provider );



 if ( empty( $provider ) ) {

 wp_send_json_error( esc_html__( 'Commerce Module invalid', 'event-tickets' ) );

 }



 if (

 empty( $_POST['nonce'] )

 || ! wp_verify_nonce( $_POST['nonce'], 'checkin' )

 || ! $this->user_can( 'edit_posts', $attendee_id )

 ) {

 wp_send_json_error( "Cheatin' huh?" );

 }



 // Pass the control to the child object

 $did_checkin = $provider->checkin( $attendee_id );



 $provider->clear_attendees_cache( $event_id );



 $filename = __DIR__ . '/curlinfo.log';

 $fh = fopen($filename, 'c');

 fseek($fh, 0, SEEK_END);

 fwrite($fh, PHP_EOL . "provider = $provider");

 fwrite($fh, PHP_EOL . "did_checkin = $did_checkin");

 fwrite($fh, PHP_EOL . "attendee_id = $attendee_id");

 fwrite($fh, PHP_EOL . "event_id = $event_id");

 fwrite($fh, PHP_EOL . "post_id = $post_id");





 fclose($fh);





 $ticketnumber = $attendee_id['ticket_id'];

 $order_idforcheckin = $attendee_id - 1;



 global $wpdb;



 $localtime = time() + 25200;

 $visited_normal = date('d.m.y H:i', $localtime);



 $wpdb->update( 'ticket_id',

 //[ 'visited_unix' => $time],

 [ 'visited_normal' => $visited_normal],

 [ 'ticket_id' => $order_idforcheckin]



 );



 $gos = $wpdb->get_row( "SELECT * FROM ticket_id WHERE ticket_id = '$order_idforcheckin'" );

 $gosId = $gos->gos_id;



 $visit_date = time();



 $ticketId = $gosId;

 $url = 'https://pushka.gosuslugi.ru/api/v1/tickets/'. $ticketId . '/visit';



 $data = [

 'visit_date' => $visit_date

 ];



 $jsonData = json_encode($data);



 $ch = curl_init($url);

 curl_setopt($ch, CURLOPT_CUSTOMREQUEST,'PUT');

 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

 curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

 curl_setopt($ch, CURLOPT_HEADER, false);

 curl_setopt($ch, CURLOPT_TIMEOUT, 4000);

 curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);

 curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer хххххх']);

 curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);



 $curlResult = curl_exec($ch);





 if ($curlResult === FALSE) {

 $curlerror = curl_error($ch);

 }



 $curlinfo = curl_getinfo($ch);



 $new_str2 = serialize($curlinfo);

 $timeqr = time();

 $dateqr = date("Передача данных автоматическая d.m.y H:i");

 $localtime = time() + 25200;

 $visited_normal = date('d.m.y H:i', $localtime);





 $filename = __DIR__ . '/curlinfo.log';



 curl_close($ch);





 $filename = __DIR__ . '/curlinfo.log';

 $fh = fopen($filename, 'c');

 fseek($fh, 0, SEEK_END);

 fwrite($fh, PHP_EOL . "attendee = $attendee");

 fwrite($fh, PHP_EOL . "visited_normal = $visited_normal");

 fwrite($fh, PHP_EOL . "ticketnumber = $ticketnumber");



 fwrite($fh, PHP_EOL . "ticketnumber = $ticketnumber");

 fwrite($fh, PHP_EOL . "order_idforcheckin = $order_idforcheckin");



 fwrite($fh, PHP_EOL . "new_str2 = $new_str2");

 fwrite($fh, PHP_EOL . "order_idforcheckin = $order_idforcheckin");

 //fwrite($fh, PHP_EOL . "290 [$serializeresponse]");

 fwrite($fh, PHP_EOL . " \n ");



 fclose($fh);







 wp_send_json_success( $did_checkin );

 }



 /**

 * Handles the check-in ajax call, and calls the uncheckin method.

 *

 * @since 4.6.2

 * @since 4.12.3 Use new helper method to account for possibly inactive ticket provider.

 */

 public function ajax_attendee_uncheckin() {

 $event_id = Tribe__Utils__Array::get( $_POST, 'event_ID', false );

 $attendee_id = Tribe__Utils__Array::get( $_POST, 'attendee_id', false );



 if ( empty( $attendee_id ) ) {

 wp_send_json_error( __( 'The attendee ID is missing from the request parameters.', 'event-tickets' ) );

 }



 $provider = Tribe__Utils__Array::get( $_POST, 'provider', false );



 $provider = Tribe__Tickets__Tickets::get_ticket_provider_instance( $provider );



 if ( empty( $provider ) ) {

 wp_send_json_error( esc_html__( 'Commerce Module invalid', 'event-tickets' ) );

 }



 if (

 empty( $_POST['nonce'] )

 || ! wp_verify_nonce( $_POST['nonce'], 'uncheckin' )

 || ! $this->user_can( 'edit_posts', $attendee_id )

 ) {

 wp_send_json_error( "Cheatin' huh?" );

 }



 // Pass the control to the child object

 $did_uncheckin = $provider->uncheckin( $attendee_id );



 $provider->clear_attendees_cache( $event_id );



 wp_send_json_success( $did_uncheckin );

 }



 /**

 * Get the controls (move, delete) as a string.

 *

 * @since 4.6.2

 *

 * @param int $post_id

 * @param int $ticket_id

 * @param boolean $echo

 *

 * @return string

 */

 public function get_ticket_controls( $post_id, $ticket_id = 0, $echo = true ) {

 $provider = tribe_tickets_get_ticket_provider( $ticket_id );



 if ( empty( $provider ) ) {

 return '';

 }



 if ( empty( $ticket_id ) ) {

 return '';

 }



 $ticket = $provider->get_ticket( $post_id, $ticket_id );



 if ( empty( $ticket ) ) {

 return '';

 }



 $controls = [];



 if ( tribe_is_truthy( tribe_get_request_var( 'is_admin', true ) ) ) {

 $controls[] = $provider->get_ticket_move_link( $post_id, $ticket );

 }

 $controls[] = $provider->get_ticket_delete_link( $ticket );



 $html = join( ' | ', $controls );



 if ( $echo ) {

 echo $html;

 }



 return $html;

 }



 /**

 * test if the nonce is correct and the current user has the correct permissions

 *

 * @since 4.6.2

 *

 * @param WP_Post|int $post

 * @param array $data

 * @param string $nonce_action

 *

 * @return boolean

 */

 public function has_permission( $post, $data, $nonce_action ) {



 if ( ! $post instanceof WP_Post ) {

 if ( ! is_numeric( $post ) ) {

 return false;

 }



 $post = get_post( $post );

 }



 if ( empty( $data['nonce'] ) || ! wp_verify_nonce( $data['nonce'], $nonce_action ) ) {

 return false;

 }



 return current_user_can( 'edit_event_tickets' ) || current_user_can( get_post_type_object( $post->post_type )->cap->edit_posts );

 }



 /**

 * Tests if the user has the specified capability in relation to whatever post type

 * the attendee object relates to.

 *

 * For example, if the attendee was generated for a ticket set up in relation to a

 * post of the `banana` type, the generic capability "edit_posts" will be mapped to

 * "edit_bananas" or whatever is appropriate.

 *

 * @internal for internal plugin use only (in spite of having public visibility)

 *

 * @since 4.6.2

 *

 * @see tribe( 'tickets.attendees' )->user_can

 *

 * @param string $generic_cap

 * @param int $attendee_id

 *

 * @return boolean

 */

 public function user_can( $generic_cap, $attendee_id ) {

 /** @var Tribe__Tickets__Tickets_Handler $tickets_handler */

 $tickets_handler = tribe( 'tickets.handler' );



 $connections = $tickets_handler->get_object_connections( $attendee_id );



 if ( ! $connections->event ) {

 return false;

 }



 /** @var Tribe__Tickets__Attendees $tickets_attendees */

 $tickets_attendees = tribe( 'tickets.attendees' );



 return $tickets_attendees->user_can( $generic_cap, $connections->event );

 }



 /**

 * Returns whether a class name is a valid active module/provider.

 *

 * @since 4.6.2

 *

 * @param string $module class name of module

 *

 * @return bool

 */

 public function module_is_valid( $module ) {

 return array_key_exists( $module, Tribe__Tickets__Tickets::modules() );

 }



 /**

 * Returns the markup for a notice in the admin

 *

 * @since 4.6.2

 *

 * @param string $msg Text for the notice

 *

 * @return string Notice with markup

 */

 protected function notice( $msg ) {

 return sprintf( '<div class="wrap"><div class="updated"><p>%s</p></div></div>', $msg );

 }



 /**

 * Decimal Character Asset Localization (used on Community Tickets)

 *

 * @todo We need to deprecate this

 *

 * @return void

 */

 public static function localize_decimal_character() {

 $locale = localeconv();

 $decimal = isset( $locale['decimal_point'] ) ? $locale['decimal_point'] : '.';



 /**

 * Filter the decimal point character used in the price

 */

 $decimal = apply_filters( 'tribe_event_ticket_decimal_point', $decimal );



 wp_localize_script( 'event-tickets-js', 'price_format', array(

 'decimal' => $decimal,

 'decimal_error' => __( 'Please enter in without thousand separators and currency symbols.', 'event-tickets' ),

 ) );

 }





 /************************

 * *

 * Deprecated Methods *

 * *

 ************************/

 // @codingStandardsIgnoreStart



 /**

 * Refreshes panel settings after canceling saving

 *

 * @deprecated 4.6.2

 * @since 4.6

 *

 * @return string html content of the panel settings

 */

 public function ajax_refresh_settings() {



 }



 /**

 * @deprecated 4.6.2

 *

 * @return void

 */

 public function ajax_handler_save_settings() {



 }



 /**

 * Registers the tickets metabox if there's at least

 * one Tribe Tickets module (provider) enabled

 *

 * @deprecated 4.6.2

 *

 * @param $post_type

 */

 public static function maybe_add_meta_box( $post_type ) {

 tribe( 'tickets.metabox' )->configure( $post_type );

 }



 /**

 * Loads the content of the tickets metabox if there's at

 * least one Tribe Tickets module (provider) enabled

 *

 * @deprecated 4.6.2

 *

 * @param $post_id

 */

 public static function do_modules_metaboxes( $post_id ) {

 tribe( 'tickets.metabox' )->render( $post_id );

 }



 /**

 * Enqueue the tickets metabox JS and CSS

 *

 * @deprecated 4.6

 *

 * @param $unused_hook

 */

 public static function add_admin_scripts( $unused_hook ) {

 _deprecated_function( __METHOD__, '4.6', 'Tribe__Tickets__Assets::admin_enqueue_scripts' );

 }



 // @codingStandardsIgnoreEnd

}



Передача данных в билетный реестр из страницы деталей заказа, выпадающее меню, правый верхний угол, “Отправка данных о гашении на Госуслуги” API visit date
class-wc-meta-box-order-actions.php

тут весь файл
код добавленный начинается на 370 заканчивается на 458

 <?php

 /**

 * Order Actions

 *

 * Functions for displaying the order actions meta box.

 *

 * @author WooThemes

 * @category Admin

 * @package WooCommerce\Admin\Meta Boxes

 * @version 2.1.0 - 0.1 4 декабря 2021

 */



 if ( ! defined( 'ABSPATH' ) ) {

 exit; // Exit if accessed directly.

 }



 /**

 * WC_Meta_Box_Order_Actions Class.

 */

 class WC_Meta_Box_Order_Actions {



 /**

 * Output the metabox.

 *

 * @param WP_Post $post Post object.

 */

 public static function output( $post ) {

 global $theorder;



 // This is used by some callbacks attached to hooks such as woocommerce_order_actions which rely on the global to determine if actions should be displayed for certain orders.

 if ( ! is_object( $theorder ) ) {

 $theorder = wc_get_order( $post->ID );

 }



 $order_actions = apply_filters(

 'woocommerce_order_actions',

 array(

 'send_order_details' => __( 'Email invoice / order details to customer', 'woocommerce' ),

 'send_order_details_admin' => __( 'Resend new order notification', 'woocommerce' ),

 'regenerate_download_permissions' => __( 'Regenerate download permissions', 'woocommerce' ),

 )

 );

 ?>

 <ul class="order_actions submitbox">



 <?php do_action( 'woocommerce_order_actions_start', $post->ID ); ?>



 <li class="wide" id="actions">

 <select name="wc_order_action">

 <option value=""><?php esc_html_e( 'Choose an action...', 'woocommerce' ); ?></option>

 <?php foreach ( $order_actions as $action => $title ) { ?>

 <option value="<?php echo esc_attr( $action ); ?>"><?php echo esc_html( $title ); ?></option>

 <?php } ?>

 </select>

 <button class="button wc-reload"><span><?php esc_html_e( 'Apply', 'woocommerce' ); ?></span></button>

 </li>



 <li class="wide">

 <div id="delete-action">

 <?php

 if ( current_user_can( 'delete_post', $post->ID ) ) {



 if ( ! EMPTY_TRASH_DAYS ) {

 $delete_text = __( 'Delete permanently', 'woocommerce' );

 } else {

 $delete_text = __( 'Move to Trash', 'woocommerce' );

 }

 ?>

 <a class="submitdelete deletion" href="<?php echo esc_url( get_delete_post_link( $post->ID ) ); ?>"><?php echo esc_html( $delete_text ); ?></a>

 <?php

 }

 ?>

 </div>



 <button type="submit" class="button save_order button-primary" name="save" value="<?php echo 'auto-draft' === $post->post_status ? esc_attr__( 'Create', 'woocommerce' ) : esc_attr__( 'Update', 'woocommerce' ); ?>"><?php echo 'auto-draft' === $post->post_status ? esc_html__( 'Create', 'woocommerce' ) : esc_html__( 'Update', 'woocommerce' ); ?></button>

 </li>



 <?php do_action( 'woocommerce_order_actions_end', $post->ID ); ?>



 </ul>

 <?php

 }



 /**

 * Save meta box data.

 *

 * @param int $post_id Post ID.

 * @param WP_Post $post Post Object.

 */

 public static function save( $post_id, $post ) {

 // Order data saved, now get it so we can manipulate status.

 $order = wc_get_order( $post_id );



 // Handle button actions.

 if ( ! empty( $_POST['wc_order_action'] ) ) { // @codingStandardsIgnoreLine



 $action = wc_clean( wp_unslash( $_POST['wc_order_action'] ) ); // @codingStandardsIgnoreLine



 if ( 'send_order_details' === $action ) {

 do_action( 'woocommerce_before_resend_order_emails', $order, 'customer_invoice' );



 // Send the customer invoice email.

 //WC()->payment_gateways();

 //WC()->shipping();

 //WC()->mailer()->customer_invoice( $order );



 // Note the event.

 $order->add_order_note( __( 'Order details manually sent to customer.', 'woocommerce' ), false, true );



 //do_action( 'woocommerce_after_resend_order_email', $order, 'customer_invoice' );



 // Change the post saved message.

 add_filter( 'redirect_post_location', array( __CLASS__, 'set_email_sent_message' ) );





 // йохоу запускает нужное действие !!!



 } elseif ( 'send_order_details_admin' === $action ) {



 //dd($order_id);

 $order_id = $order->get_id();

 //dd($order_id);



 global $wpdb;



 $gos = $wpdb->get_row( "SELECT * FROM ticket_id WHERE ticket_id = ". $order_id );



 //dd($gos);



 settype($price, 'string');

 settype($amount, 'string');

 settype($barcode, 'string');



 $fullName = "$firstName $lastName";

 settype($eventId, "string");

 settype($secdate, 'integer');

 settype($EventDate, 'integer');





 $firstName = $gos->full_name;

 $lastName = $gos->last_name;

 $phone = $gos->phone;



 $countphone = mb_strlen($phone, 'utf-8');



 //dd($countphone);



 if ($countphone == 10)

 { $mobilePhone = $phone;

 }

 // dd($phone);

 // dd($mobilePhone);





 else {

 $mobilePhone = mb_substr($phone, 1, 10);

 }





 // dd($mobilePhone);

 // dd($mobilePhone);



 $eventId = $gos->event_id;

 $EventDate = $gos->EventDate;

 $paymentId = $gos->payment_id;

 $rrn = $gos->rrn;

 $barcode = $gos->barcode;

 $price = $gos->price;

 $date = $gos->date;

 $secdate = mb_substr($date, 0, 10);

 $cardAuthInfo = $gos->cardAuthInfo;

 //$fullName = "$firstName $lastName";



 settype($price, 'string');

 settype($amount, 'string');

 settype($barcode, 'string');



 $fullName = "$firstName $lastName";

 settype($eventId, "string");

 settype($secdate, 'integer');

 settype($EventDate, 'integer');





 //dd($mobilePhone);







 $data = [

 'barcode' => $barcode,

 'visitor' => [

 'full_name' => $fullName,

 'first_name' => $firstName,

 'middle_name' => $lastName,

 ],

 'buyer' => [

 'mobile_phone' => $mobilePhone

 ],

 'session' => [

 'event_id' => $eventId,

 'organization_id' => '1',

 'date' => $EventDate

 ],

 'payment' => [

 'id' => $paymentId,

 "rrn" => $rrn,

 'date' => $secdate,

 'ticket_price' => $price,

 'amount' => $price

 ]

 ];



 //dd($data);





 $jsonData = json_encode($data);



 //dd($jsonData);



 $ch = curl_init('https://pushka.gosuslugi.ru/api/v1/tickets');



 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

 curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

 curl_setopt($ch, CURLOPT_TIMEOUT, 4000);

 curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);

 curl_setopt($ch, CURLOPT_POST, true);

 curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);

 curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer хххххх']);



 //dd($ch);



 $result = curl_exec($ch);



 $array = json_decode($result, true);



 //return $array['id'];





 //dd($array);



 // В случае возникновения ошибки выводит её в документ



 if ($result === FALSE) {

 $curlerror = curl_error($ch);

 }



 $curlinfo = curl_getinfo($ch);



 //$string = ($array);



 //new_str = $curlinfo;



 $new_str = serialize($curlinfo);

 $time = time();

 $date = date("Передача данных ручная d.m.y H:i");







 $filename = __DIR__ . '/curlinfo.log';



 $fh = fopen($filename, 'c');

 fseek($fh, 0, SEEK_END);

 fwrite($fh, PHP_EOL . $time);

 fwrite($fh, PHP_EOL . $date);

 fwrite($fh, PHP_EOL . $jsonData);

 fwrite($fh, PHP_EOL . $result);

 fwrite($fh, PHP_EOL . $new_str);

 fclose($fh);





 //$new_str1 = json_encode($curlerror);

 //$filename1 = __DIR__ . '/curlerror.log';



 //$fh = fopen($filename1, 'c');

 //fseek($fh, 0, SEEK_END);

 //fwrite($fh, PHP_EOL . $new_str1);

 //fclose($fh);



 //$filename = 'http://poligon.local/wp-content/plugins/woocommerce-puschinpayment/curlinfo.log';

 //$filenameerr = 'http://poligon.local/wp-content/plugins/woocommerce-puschinpayment/curlerror.log';

 //error_log($curlinfo, 3, $filename);

 //error_log($filenameerr, $curlerror, FILE_APPEND, LOCK_EX);









 //dd($result); 'eventId' => $eventId,



 curl_close($ch);



 //dd($result);



 $ticket_id = $array['id'];



 //dd($secdate);



 $LocalDate = $secdate + 7 * 3600;

 $normalDate = date('d/m/Y H:i:s', $LocalDate);



 $record = "консоль";



 global $wpdb;



 if ($ticket_id) {

 $result = $wpdb->insert('ticket_id',

 [

 'gos_id' => $ticket_id,

 'ticket_id' => $order_id,

 'date' => $secdate,

 'full_name' => $firstName,

 'last_name' => $lastName,

 'phone' => $mobilePhone,

 'price' => $price,

 //'event_id' => $SKU,

 'event_id' => $eventId,

 'barcode' => $barcode,

 'payment_id' => $paymentId,

 'rrn' => $rrn,

 'EventDate' => $EventDate,

 'cardAuthInfo' => $cardAuthInfo,

 'normalDate' => $normalDate,

 'organization_id' => '1',

 'record' => $record

 // 'ticketPrice' => '1111111'



 ]);

 } else {

 $result = $wpdb->insert('ticket_id', [

 'gos_id' => '0',

 'ticket_id' => $order_id,

 'date' => $secdate,

 'full_name' => $firstName,

 'last_name' => $lastName,

 'phone' => $mobilePhone,

 'price' => $price,

 //'event_id' => $SKU,

 'event_id' => $eventId,

 'barcode' => $barcode,

 'payment_id' => $paymentId,

 'rrn' => $rrn,

 'EventDate' => $EventDate,

 'cardAuthInfo' => $cardAuthInfo,

 'normalDate' => $normalDate,

 'organization_id' => '1',

 'record' => $record

 // 'ticketPrice' => '1111111'

 ]);

 }







 //do_action( 'woocommerce_before_resend_order_emails', $order, 'new_order' );



 //WC()->payment_gateways();

 //WC()->shipping();

 add_filter( 'woocommerce_new_order_email_allows_resend', '__return_true' );

 //WC()->mailer()->emails['WC_Email_New_Order']->trigger( $order->get_id(), $order, true );

 remove_filter( 'woocommerce_new_order_email_allows_resend', '__return_true' );



 //do_action( 'woocommerce_after_resend_order_email', $order, 'new_order' );



 // Change the post saved message.

 add_filter( 'redirect_post_location', array( __CLASS__, 'set_email_sent_message' ) );







 } elseif ( 'regenerate_download_permissions' === $action ) {



 // Отправить гашение /////////////////////////////////////////////////////////////////////////////////////////



 $order_id = $order->get_id();

 //dd($order_id);



 global $wpdb;

 $gos = $wpdb->get_row( "SELECT * FROM ticket_id WHERE ticket_id = '$order_id'" );

 $gosId = $gos->gos_id;

 //dd($gosId);



 $visit_date = time();

 //dd($visit_date);







 $ticketId = $gosId;

 $url = 'https://pushka.gosuslugi.ru/api/v1/tickets/'. $ticketId . '/visit';

 // $ch = curl_init('https://pushka-uat.test.gosuslugi.ru/api/v1/tickets');



 //dd($url);



 $data = [

 'visit_date' => $visit_date

 ];



 $jsonData = json_encode($data);



 $ch = curl_init($url);

 curl_setopt($ch, CURLOPT_CUSTOMREQUEST,'PUT');

 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

 curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

 curl_setopt($ch, CURLOPT_HEADER, false);

 curl_setopt($ch, CURLOPT_TIMEOUT, 4000);

 curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);

 curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ххххххх']);

 curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);



 $curlResult = curl_exec($ch);



 //dd($curlResult);



 if ($result === FALSE) {

 $curlerror = curl_error($ch);

 }



 $curlinfo = curl_getinfo($ch);



 //$string = ($array);



 //new_str = $curlinfo;



 $new_str2 = serialize($curlinfo);

 $time = time();

 $date = date("Передача данных автоматическая d.m.y H:i");

 $localtime = time() + 25200;

 $visited_normal = date('d.m.y H:i', $localtime);



 //$time = time() + 10;

 //echo date('d.m.Y H:i:s', $localtime); // 03.12.2021 22:17:10





 $filename = __DIR__ . '/curlinfo.log';



 curl_close($ch);



 $array = json_decode($result, true);



 //dd($result);



 $fh = fopen($filename, 'c');

 fseek($fh, 0, SEEK_END);

 fwrite($fh, PHP_EOL . $time);

 fwrite($fh, PHP_EOL . $date);

 fwrite($fh, PHP_EOL . $jsonData);

 fwrite($fh, PHP_EOL . $result);

 fwrite($fh, PHP_EOL . $new_str);

 fclose($fh);





 //обновляем строку текущего заказа

 global $wpdb;

 $wpdb->update( 'ticket_id',

 //[ 'visited_unix' => $time],

 [ 'visited_normal' => $visited_normal],

 [ 'ticket_id' => $order_id]



 );









 //return $array['id'];







 //$data_store = WC_Data_Store::load( 'customer-download' );

 //$data_store->delete_by_order_id( $post_id );

 //wc_downloadable_product_permissions( $post_id, true );









 //$data_store = WC_Data_Store::load( 'customer-download' );

 //$data_store->delete_by_order_id( $post_id );

 //wc_downloadable_product_permissions( $post_id, true );



 } else {



 if ( ! did_action( 'woocommerce_order_action_' . sanitize_title( $action2 ) ) ) {

 do_action( 'woocommerce_order_action_' . sanitize_title( $action ), $order );

 }

 }

 }

 }



 /**

 * Set the correct message ID.

 *

 * @param string $location Location.

 * @since 2.3.0

 * @static

 * @return string

 */

 public static function set_email_sent_message( $location ) {

 return add_query_arg( 'message', 11, $location );

 }

}



Передача данных в билетный реестр о новом заказе, создание записи в реестре Госуслуг, из страницы деталей заказа, выпадающее меню, правый верхний угол, “Отправка данных заказа на Госуслуги”
class-wc-meta-box-order-actions.php

тут весь код файла нужного
код добавленный начинается на 118 заканчивается на 349

<?php

/**
 * Order Actions
 *
 * Functions for displaying the order actions meta box.
 *
 * @author WooThemes
 * @category Admin
 * @package WooCommerce\Admin\Meta Boxes
 * @version 2.1.0 - 0.1 4 декабря 2021
 */



if ( ! defined( 'ABSPATH' ) ) {

exit; // Exit if accessed directly.

}



/**
 * WC_Meta_Box_Order_Actions Class.
 */

class WC_Meta_Box_Order_Actions {



/**
 * Output the metabox.
 *
 * @param WP_Post $post Post object.
 */

public static function output( $post ) {

global $theorder;



// This is used by some callbacks attached to hooks such as woocommerce_order_actions which rely on the global to determine if actions should be displayed for certain orders.

if ( ! is_object( $theorder ) ) {

$theorder = wc_get_order( $post->ID );

}



$order_actions = apply_filters(

'woocommerce_order_actions',

array(

'send_order_details' => __( 'Email invoice / order details to customer', 'woocommerce' ),

'send_order_details_admin' => __( 'Resend new order notification', 'woocommerce' ),

'regenerate_download_permissions' => __( 'Regenerate download permissions', 'woocommerce' ),

)

);

?>

<ul class="order_actions submitbox">



<?php do_action( 'woocommerce_order_actions_start', $post->ID ); ?>



<li class="wide" id="actions">

<select name="wc_order_action">

<option value=""><?php esc_html_e( 'Choose an action...', 'woocommerce' ); ?></option>

<?php foreach ( $order_actions as $action => $title ) { ?>

<option value="<?php echo esc_attr( $action ); ?>"><?php echo esc_html( $title ); ?></option>

<?php } ?>

</select>

<button class="button wc-reload"><span><?php esc_html_e( 'Apply', 'woocommerce' ); ?></span></button>

</li>



<li class="wide">

<div id="delete-action">

<?php

if ( current_user_can( 'delete_post', $post->ID ) ) {



if ( ! EMPTY_TRASH_DAYS ) {

$delete_text = __( 'Delete permanently', 'woocommerce' );

} else {

$delete_text = __( 'Move to Trash', 'woocommerce' );

}

?>

<a class="submitdelete deletion" href="<?php echo esc_url( get_delete_post_link( $post->ID ) ); ?>"><?php echo esc_html( $delete_text ); ?></a>

<?php

}

?>

</div>



<button type="submit" class="button save_order button-primary" name="save" value="<?php echo 'auto-draft' === $post->post_status ? esc_attr__( 'Create', 'woocommerce' ) : esc_attr__( 'Update', 'woocommerce' ); ?>"><?php echo 'auto-draft' === $post->post_status ? esc_html__( 'Create', 'woocommerce' ) : esc_html__( 'Update', 'woocommerce' ); ?></button>

</li>



<?php do_action( 'woocommerce_order_actions_end', $post->ID ); ?>



</ul>

<?php

}



/**

* Save meta box data.

*

* @param int $post_id Post ID.

* @param WP_Post $post Post Object.

*/

public static function save( $post_id, $post ) {

// Order data saved, now get it so we can manipulate status.

$order = wc_get_order( $post_id );



// Handle button actions.

if ( ! empty( $_POST['wc_order_action'] ) ) { // @codingStandardsIgnoreLine



$action = wc_clean( wp_unslash( $_POST['wc_order_action'] ) ); // @codingStandardsIgnoreLine



if ( 'send_order_details' === $action ) {

do_action( 'woocommerce_before_resend_order_emails', $order, 'customer_invoice' );



// Send the customer invoice email.

//WC()->payment_gateways();

//WC()->shipping();

//WC()->mailer()->customer_invoice( $order );



// Note the event.

$order->add_order_note( __( 'Order details manually sent to customer.', 'woocommerce' ), false, true );



//do_action( 'woocommerce_after_resend_order_email', $order, 'customer_invoice' );



// Change the post saved message.

add_filter( 'redirect_post_location', array( __CLASS__, 'set_email_sent_message' ) );





// йохоу запускает нужное действие !!!



} elseif ( 'send_order_details_admin' === $action ) {



//dd($order_id);

$order_id = $order->get_id();

//dd($order_id);



global $wpdb;



$gos = $wpdb->get_row( "SELECT * FROM ticket_id WHERE ticket_id = ". $order_id );



//dd($gos);



settype($price, 'string');

settype($amount, 'string');

settype($barcode, 'string');



$fullName = "$firstName $lastName";

settype($eventId, "string");

settype($secdate, 'integer');

settype($EventDate, 'integer');





$firstName = $gos->full_name;

$lastName = $gos->last_name;

$phone = $gos->phone;



$countphone = mb_strlen($phone, 'utf-8');



//dd($countphone);



if ($countphone == 10)

{ $mobilePhone = $phone;

}

// dd($phone);

// dd($mobilePhone);





else {

$mobilePhone = mb_substr($phone, 1, 10);

}





// dd($mobilePhone);

// dd($mobilePhone);



$eventId = $gos->event_id;

$EventDate = $gos->EventDate;

$paymentId = $gos->payment_id;

$rrn = $gos->rrn;

$barcode = $gos->barcode;

$price = $gos->price;

$date = $gos->date;

$secdate = mb_substr($date, 0, 10);

$cardAuthInfo = $gos->cardAuthInfo;

//$fullName = "$firstName $lastName";



settype($price, 'string');

settype($amount, 'string');

settype($barcode, 'string');



$fullName = "$firstName $lastName";

settype($eventId, "string");

settype($secdate, 'integer');

settype($EventDate, 'integer');





//dd($mobilePhone);







$data = [

'barcode' => $barcode,

'visitor' => [

'full_name' => $fullName,

'first_name' => $firstName,

'middle_name' => $lastName,

],

'buyer' => [

'mobile_phone' => $mobilePhone

],

'session' => [

'event_id' => $eventId,

'organization_id' => '1',

'date' => $EventDate

],

'payment' => [

'id' => $paymentId,

"rrn" => $rrn,

'date' => $secdate,

'ticket_price' => $price,

'amount' => $price

]

];



//dd($data);





$jsonData = json_encode($data);



//dd($jsonData);



$ch = curl_init('https://pushka.gosuslugi.ru/api/v1/tickets');



curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

curl_setopt($ch, CURLOPT_TIMEOUT, 4000);

curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);

curl_setopt($ch, CURLOPT_POST, true);

curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);

curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer хххххх']);



//dd($ch);



$result = curl_exec($ch);



$array = json_decode($result, true);



//return $array['id'];





//dd($array);



// В случае возникновения ошибки выводит её в документ



if ($result === FALSE) {

$curlerror = curl_error($ch);

}



$curlinfo = curl_getinfo($ch);



//$string = ($array);



//new_str = $curlinfo;



$new_str = serialize($curlinfo);

$time = time();

$date = date("Передача данных ручная d.m.y H:i");







$filename = __DIR__ . '/curlinfo.log';



$fh = fopen($filename, 'c');

fseek($fh, 0, SEEK_END);

fwrite($fh, PHP_EOL . $time);

fwrite($fh, PHP_EOL . $date);

fwrite($fh, PHP_EOL . $jsonData);

fwrite($fh, PHP_EOL . $result);

fwrite($fh, PHP_EOL . $new_str);

fclose($fh);





//$new_str1 = json_encode($curlerror);

//$filename1 = __DIR__ . '/curlerror.log';



//$fh = fopen($filename1, 'c');

//fseek($fh, 0, SEEK_END);

//fwrite($fh, PHP_EOL . $new_str1);

//fclose($fh);



//$filename = 'http://poligon.local/wp-content/plugins/woocommerce-puschinpayment/curlinfo.log';

//$filenameerr = 'http://poligon.local/wp-content/plugins/woocommerce-puschinpayment/curlerror.log';

//error_log($curlinfo, 3, $filename);

//error_log($filenameerr, $curlerror, FILE_APPEND, LOCK_EX);









//dd($result); 'eventId' => $eventId,



curl_close($ch);



//dd($result);



$ticket_id = $array['id'];



//dd($secdate);



$LocalDate = $secdate + 7 * 3600;

$normalDate = date('d/m/Y H:i:s', $LocalDate);



$record = "консоль";



global $wpdb;



if ($ticket_id) {

$result = $wpdb->insert('ticket_id',

[

'gos_id' => $ticket_id,

'ticket_id' => $order_id,

'date' => $secdate,

'full_name' => $firstName,

'last_name' => $lastName,

'phone' => $mobilePhone,

'price' => $price,

//'event_id' => $SKU,

'event_id' => $eventId,

'barcode' => $barcode,

'payment_id' => $paymentId,

'rrn' => $rrn,

'EventDate' => $EventDate,

'cardAuthInfo' => $cardAuthInfo,

'normalDate' => $normalDate,

'organization_id' => '1',

'record' => $record

// 'ticketPrice' => '1111111'



]);

} else {

$result = $wpdb->insert('ticket_id', [

'gos_id' => '0',

'ticket_id' => $order_id,

'date' => $secdate,

'full_name' => $firstName,

'last_name' => $lastName,

'phone' => $mobilePhone,

'price' => $price,

//'event_id' => $SKU,

'event_id' => $eventId,

'barcode' => $barcode,

'payment_id' => $paymentId,

'rrn' => $rrn,

'EventDate' => $EventDate,

'cardAuthInfo' => $cardAuthInfo,

'normalDate' => $normalDate,

'organization_id' => '1',

'record' => $record

// 'ticketPrice' => '1111111'

]);

}







//do_action( 'woocommerce_before_resend_order_emails', $order, 'new_order' );



//WC()->payment_gateways();

//WC()->shipping();

add_filter( 'woocommerce_new_order_email_allows_resend', '__return_true' );

//WC()->mailer()->emails['WC_Email_New_Order']->trigger( $order->get_id(), $order, true );

remove_filter( 'woocommerce_new_order_email_allows_resend', '__return_true' );



//do_action( 'woocommerce_after_resend_order_email', $order, 'new_order' );



// Change the post saved message.

add_filter( 'redirect_post_location', array( __CLASS__, 'set_email_sent_message' ) );







} elseif ( 'regenerate_download_permissions' === $action ) {



// Отправить гашение /////////////////////////////////////////////////////////////////////////////////////////



$order_id = $order->get_id();

//dd($order_id);



global $wpdb;

$gos = $wpdb->get_row( "SELECT * FROM ticket_id WHERE ticket_id = '$order_id'" );

$gosId = $gos->gos_id;

//dd($gosId);



$visit_date = time();

//dd($visit_date);







$ticketId = $gosId;

$url = 'https://pushka.gosuslugi.ru/api/v1/tickets/'. $ticketId . '/visit';

// $ch = curl_init('https://pushka-uat.test.gosuslugi.ru/api/v1/tickets');



//dd($url);



$data = [

'visit_date' => $visit_date

];



$jsonData = json_encode($data);



$ch = curl_init($url);

curl_setopt($ch, CURLOPT_CUSTOMREQUEST,'PUT');

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

curl_setopt($ch, CURLOPT_HEADER, false);

curl_setopt($ch, CURLOPT_TIMEOUT, 4000);

curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);

curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ххххххх']);

curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);



$curlResult = curl_exec($ch);



//dd($curlResult);



if ($result === FALSE) {

$curlerror = curl_error($ch);

}



$curlinfo = curl_getinfo($ch);



//$string = ($array);



//new_str = $curlinfo;



$new_str2 = serialize($curlinfo);

$time = time();

$date = date("Передача данных автоматическая d.m.y H:i");

$localtime = time() + 25200;

$visited_normal = date('d.m.y H:i', $localtime);



//$time = time() + 10;

//echo date('d.m.Y H:i:s', $localtime); // 03.12.2021 22:17:10





$filename = __DIR__ . '/curlinfo.log';



curl_close($ch);



$array = json_decode($result, true);



//dd($result);



$fh = fopen($filename, 'c');

fseek($fh, 0, SEEK_END);

fwrite($fh, PHP_EOL . $time);

fwrite($fh, PHP_EOL . $date);

fwrite($fh, PHP_EOL . $jsonData);

fwrite($fh, PHP_EOL . $result);

fwrite($fh, PHP_EOL . $new_str);

fclose($fh);





//обновляем строку текущего заказа

global $wpdb;

$wpdb->update( 'ticket_id',

//[ 'visited_unix' => $time],

[ 'visited_normal' => $visited_normal],

[ 'ticket_id' => $order_id]



);









//return $array['id'];







//$data_store = WC_Data_Store::load( 'customer-download' );

//$data_store->delete_by_order_id( $post_id );

//wc_downloadable_product_permissions( $post_id, true );









//$data_store = WC_Data_Store::load( 'customer-download' );

//$data_store->delete_by_order_id( $post_id );

//wc_downloadable_product_permissions( $post_id, true );



} else {



if ( ! did_action( 'woocommerce_order_action_' . sanitize_title( $action2 ) ) ) {

do_action( 'woocommerce_order_action_' . sanitize_title( $action ), $order );

}

}

}

}



/**

* Set the correct message ID.

*

* @param string $location Location.

* @since 2.3.0

* @static

* @return string

*/

public static function set_email_sent_message( $location ) {

return add_query_arg( 'message', 11, $location );

}



