<?php

/*
Пример кода обмена с билетным реестром часть первая
Данный код, опыт написания практически с нулевыми знаниями PHP, потому что было надо, и другого выхода не было. Но код работает, данные передает.

Данная информация предоставляется as is, и мы не несем никакой ответственности, если она будет работать некорректно, или не будет работать вовсе.
Информация предназначена для ознакомления с алгоритмом.
Перечень
часть первая, передача barcode тут в тестовом режиме, в другой части будет barcode для предачи в приложение Госуслуги Культура

Передача данных в билетный реестр при посещении при сканировании QR кода сканером подключенным к компьютеру, передача данных в API visit date
Передача данных в билетный реестр при посещении при сканировании QR кода приложением на мобильном телефоне, передача данных в API visit date
Передача данных в билетный реестр при продаже билета, в Сбербанке, запрет покупки нескольких билетов по Пушке, передача данных в API создание записи в реестре это основной модуль передачи данных на Госуслуги и основной модуль оплаты билетов по Пушкинской карте через интернет
часть вторая

Передача данных в билетный реестр о посещении, при ручном гашении билетов в реестре проданных билетов интернет магазина (кнопкой “Погасить билет”), передача данных в API visit date
Передача данных в билетный реестр из страницы деталей заказа, выпадающее меню, правый верхний угол, “Отправка данных о гашении на Госуслуги” API visit date
Передача данных в билетный реестр о новом заказе, создание записи в реестре Госуслуг, из страницы деталей заказа, выпадающее меню, правый верхний угол, “Отправка данных заказа на Госуслуги”
Передача данных в билетный реестр при посещении при сканировании QR кода сканером подключенным к компьютеру, передача данных в API visit date

*/

//Передача данных в билетный реестр при продаже билета, в Сбербанке, запрет покупки нескольких билетов по Пушке, передача данных в API создание записи в реестре это основной модуль передачи данных на Госуслуги и основной модуль оплаты билетов по Пушкинской карте через интернет


/**
 * Plugin Name: WooCommerce Пушкинская карта
 * Plugin URI:
 * Description: Добавляет оплату через Пушкинскую карту в WooCommerce. 5.01.2022
 * Version: 1.1.49
 * Author:
 * Author URI:
 */



if (!defined('ABSPATH')) exit;

require_once(ABSPATH . 'wp-admin/includes/plugin.php');

require_once(__DIR__ . '/include.php');



add_filter('plugin_row_meta', 'puskhin_register_plugin_links', 10, 2);

function puskhin_register_plugin_links($links, $file)
{
	$base = plugin_basename(__FILE__);
	if ($file == $base) {
		$links[] = '<a href="admin.php?page=wc-settings&tab=checkout§ion=puskhinpayment">' . __('Settings', 'woocommerce') . '</a>';
	}
	return $links;
}





add_action('plugins_loaded', 'woocommerce_puskhin', 0);

function woocommerce_puskhin(){
	load_plugin_textdomain('wc-puskhin-text-domain', false, dirname(plugin_basename(__FILE__)) . '/lang');

	if (!class_exists('WC_Payment_Gateway'))
		return;
	if (class_exists('WC_puskhin'))
		return;


class WC_puskhin extends WC_Payment_Gateway{

	public $currency_codes = array(
		'USD' => '840',
		'UAH' => '980',
		'RUB' => '643',
		'RON' => '946',
		'KZT' => '398',
		'KGS' => '417',
		'JPY' => '392',
		'GBR' => '826',
		'EUR' => '978',
		'CNY' => '156',
		'BYR' => '974',
	'BYN' => '933'
	);



	public function __construct()	{

	$this->id = 'puskhin';
	$icon_path = is_file(__DIR__ . DIRECTORY_SEPARATOR . 'puskin.png') ? plugin_dir_url(__FILE__) . 'puskin.png' : null;

	$this->method_title = "puskhin";
	$this->method_description = __('Online acquiring and payment processing.', 'wc-puskhin-text-domain');

	// Load the settings
	$this->init_form_fields();
	$this->init_settings();

	// Endpoints
	$this->prod_url = RBS_PROD_URL;
	$this->test_url = RBS_TEST_URL;
	$this->logging = RBS_ENABLE_LOGGING;
	$this->fiscale_options = RBS_ENABLE_FISCALE_OPTIONS;

	// Define user set variables
	$this->title = $this->get_option('title');
	$this->merchant = $this->get_option('merchant');
	$this->password = $this->get_option('password');
	$this->test_mode = $this->get_option('test_mode');
	$this->stage_mode = $this->get_option('stage_mode');
	$this->description = $this->get_option('description');
	$this->order_status = $this->get_option('order_status');
	$this->icon = $icon_path;

	$this->send_order = $this->get_option('send_order');
	$this->tax_system = $this->get_option('tax_system');
	$this->tax_type = $this->get_option('tax_type');

	$this->success_url = $this->get_option('success_url');
	$this->fail_url = $this->get_option('fail_url');
	// $this->version = $this->get_option('version');
	$this->paymentMethodType = $this->get_option('paymentMethodType');
	$this->paymentObjectType = $this->get_option('paymentObjectType');
	$this->paymentObjectType_delivery = $this->get_option('paymentMethodType_delivery');

	$this->pData = get_plugin_data(__FILE__);
	$this->measurement_name = RBS_MEASUREMENT_NAME;

	// Actions
	add_action('valid-puskhin-standard-ipn-request', array($this, 'successful_request'));
	add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));

	// Save options
	add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
	// add_action( 'woocommerce_payment_complete_order_status', 'puskhin_change_status_function' );

	if (!$this->is_valid_for_use()) {
		$this->enabled = false;
	}



	$this->callback();

	}

	public function sendTicketBase($firstName, $lastName, $mobilePhone, $price, $date, $eventId, $barcode, $paymentId, $rrn, $EventDate){

		settype($price, 'string');
		settype($amount, 'string');
		settype($barcode, 'string');

		settype($now, "integer");
		$fullName = "$firstName $lastName";
		settype($eventId, "string");
		settype($SKU, "string");

		$secdate = mb_substr($date, 0, 10);
		settype($secdate, 'integer');
		settype($EventDate, 'integer');


		$data = [
			'barcode' => $barcode,
			'visitor' => [
				'full_name' => $fullName,
				'first_name' => $firstName,
				'last_name' => $lastName,
			],
				'buyer' => [
				'mobile_phone' => $mobilePhone
			],
			'session' => [
				'event_id' => $eventId,
				'organization_id' => '1',
				'date' => $EventDate,
			],
			'payment' => [
				'id' => $paymentId,
				"rrn" => $rrn,
				'date' => $secdate,
				'ticket_price' => $price,
				'amount' => $price
			]
		];

		$jsonData = json_encode($data);

		$ch = curl_init('https://pushka.gosuslugi.ru/api/v1/tickets');

		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_TIMEOUT, 4000);
		curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
		curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer хххххххх']);

		$result = curl_exec($ch);
		$curlinfo = curl_getinfo($ch);
		$localtime = time() + 25200;
		$paid_normal = date('d.m.y H:i', $localtime);

		$new_strcurl99 = serialize($curlinfo);

		$jsonDataH = 'jsonData';

		$filename = __DIR__ . '/curlinfo.log';

		$fh = fopen($filename, 'c');
		fseek($fh, 0, SEEK_END);
		fwrite($fh, PHP_EOL . "[$paid_normal] 181 public function sendTicketBase ");

		// fwrite($fh, PHP_EOL . $jsonDataH);
		//fwrite($fh, PHP_EOL . $jsonData);
		fwrite($fh, PHP_EOL . "185 [$result] \n");
		//fwrite($fh, PHP_EOL . $new_strcurl99);
		fclose($fh);
		curl_close($ch);
		$array = json_decode($result, true);

		return $array['id'];
	}


	public function sendTicketDataToDatabase ($order_id, $ticket_id, $secdate, $fullName, $mobilePhone, $price, $eventId, $barcode, $paymentId, $rrn, $lastName, $EventDate, $cardAuthInfo, $normalDate, $Normal_Place){

		global $wpdb;

		if ($ticket_id) {

			$result = $wpdb->insert('ticket_id',
			[
				'gos_id' => $ticket_id,
				'ticket_id' => $order_id,
				'date' => $secdate,
				'full_name' => $fullName,
				'last_name' => $lastName,
				'phone' => $mobilePhone,
				'price' => $price,
				'event_id' => $eventId,
				'barcode' => $barcode,
				'payment_id' => $paymentId,
				'rrn' => $rrn,
				'EventDate' => $EventDate,
				'cardAuthInfo' => $cardAuthInfo,
				'normalDate' => $normalDate,
				'organization_id' => '1',
				'Normal_Place' => $Normal_Place
			]);
		} else {
			$result = $wpdb->insert('ticket_id', [
				'gos_id' => '0',
				'ticket_id' => $order_id,
				'date' => $secdate,
				'full_name' => $fullName,
				'last_name' => $lastName,
				'phone' => $mobilePhone,
				'price' => $price,
				'event_id' => $eventId,
				'barcode' => $barcode,
				'payment_id' => $paymentId,
				'rrn' => $rrn,
				'EventDate' => $EventDate,
				'cardAuthInfo' => $cardAuthInfo,
				'normalDate' => $normalDate,
				'organization_id' => '1',
				'Normal_Place' => $Normal_Place
			]);
		}

		return $result;
	}

	public function process_admin_options()	{

		if ($this->test_mode == 'yes') {
				$action_adr = $this->test_url;
				// "mportal-uat" error for some ONE bank
				$gate_url = str_replace("payment/rest", "mportal-uat/mvc/public/merchant/update", $action_adr);
			} else {
				$action_adr = $this->prod_url;
				$gate_url = str_replace("payment/rest", "mportal/mvc/public/merchant/update", $action_adr);
		}

		$gate_url .= substr($this->merchant, 0, -4); // we guess username = login w/o "-api"

		$callback_addresses_string = get_option('siteurl') . "?wc-api=WC_puskhin&puskhin=callback";
		$response = $this->_updateRBSCallback($this->merchant, $this->password, $gate_url, $callback_addresses_string);

		if (RBS_ENABLE_LOGGING === true) {
			$this->writeRBSLog("[callback_addresses_string]: " . $callback_addresses_string . "\n[262 RESPONSE]: " . $response);
		}
		parent::process_admin_options();

	}

	public function _updateRBSCallback($login, $password, $action_address, $callback_addresses_string){
		$headers = array(
			'Content-Type:application/json',
			'Authorization: Basic ' . base64_encode($login . ":" . $password)
		);
		
		$data['callbacks_enabled'] = true;
		$data['callback_addresses'] = $callback_addresses_string;
		$data['callback_operations'] = "deposited,approved,declinedByTimeout";

		$response = $this->_sendRBSData(json_encode($data), $action_address, $headers);

		$localtime = new DateTime();
		$paid_normal = $localtime->format('Y-m-d H:i:s:u');
		$serializeresponse = serialize($response);
		$filename = __DIR__ . '/curlinfo.log';
		$fh = fopen($filename, 'c');
		fseek($fh, 0, SEEK_END);
		fwrite($fh, PHP_EOL . "[$paid_normal] 289 public function _updateRBSCallback ");
		fwrite($fh, PHP_EOL . "290 [$serializeresponse]");
		fwrite($fh, PHP_EOL . "291 \n ");
		fclose($fh);

		return $response;

	}

	// СБЕР ПЕРЕДАЧА ДАНННЫХ

	public function _sendRBSData($data, $action_address, $headers = array())
	{
		$ch = curl_init();

		curl_setopt_array($ch, array(
			CURLOPT_HTTPHEADER => $headers,
			CURLOPT_VERBOSE => true,
			CURLOPT_SSL_VERIFYHOST => false,
			CURLOPT_SSL_VERIFYPEER => false,
			CURLOPT_URL => $action_address,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => $data,
			CURLOPT_ENCODING, "gzip",
			CURLOPT_ENCODING, '',
		));

		$response = curl_exec($ch);
		curl_close($ch);
		
		// ЛОГИРУЕМ ПЕРЕДАЧУ ДАННЫХ СБЕРА
		//$localtime = time() + 25200;

		// $paid_normal = date('d.m.y H:i', $localtime);

		$localtime = new DateTime();
		$paid_normal = $localtime->format('Y-m-d H:i:s:u');

		$serializeresponse = serialize($response);

		$filename = __DIR__ . '/curlinfo.log';
		$fh = fopen($filename, 'c');
		fseek($fh, 0, SEEK_END);

		fwrite($fh, PHP_EOL . "[$paid_normal] 327 public function _sendRBSData");
		fwrite($fh, PHP_EOL . "328 ОТВЕТ ОТ СБЕРА ПОКАЗЫВАЕТ БАНД ОТКЛЮЧЕН ТАК КАК БОЛЬШОЙ serializeresponse");
		fwrite($fh, PHP_EOL . "329 action_adr [$action_address] \n ");
		fclose($fh);

		return $response;

	}



	public function callback(){

		if (isset($_GET['puskhin'])) {
			$action = $_GET['puskhin'];

			if ($this->test_mode == 'yes') {
				$action_adr = $this->test_url;
			} else {
				$action_adr = $this->prod_url;
			}
			
			$action_adr .= 'getOrderStatusExtended.do';

			$args = array(
				'userName' => $this->merchant,
				'password' => $this->password,
				// 'orderId' => $args['orderId'] = isset($_GET['mdOrder']) ? $_GET['mdOrder'] : null
				// ЛОГИРУЕМ ПЕРЕДАЧУ ДАННЫХ СБЕРА
			);



			$localtime = new DateTime();
			$paid_normal = $localtime->format('Y-m-d H:i:s:u');
			$serializeargs = serialize($args);

			$filename = __DIR__ . '/curlinfo.log';
			$fh = fopen($filename, 'c');
			fseek($fh, 0, SEEK_END);
			fwrite($fh, PHP_EOL . "[$paid_normal] 371 public function callback action = [$action] ");
			fwrite($fh, PHP_EOL . "372 ПЕРЕДАЧА ЛОГИНА ПАРОЛЯ В СБЕРЕ [$serializeargs]");
			fwrite($fh, PHP_EOL . "373 switch case = [$action] \n ");
			fclose($fh);

			switch ($action) {

				case "result":
					//by returnUrl
					$args['orderId'] = isset($_GET['orderId']) ? $_GET['orderId'] : null;

					// we already know internal order_id from returnUrl
					$order_id = $_GET['order_id'];
					$order = new WC_Order($order_id);

					$response = $this->_sendRBSData(http_build_query($args, '', '&'), $action_adr);
					$responseArrayData = json_decode($response, true);
					$firstName = $responseArrayData['merchantOrderParams'][1]['value'];
					$lastName = $responseArrayData['merchantOrderParams'][5]['value'];

					$phone = $responseArrayData['payerData']['phone'];
					$price = mb_substr($responseArrayData['amount'], 0, -2);
					$date = $responseArrayData['authDateTime'];
					$eventId = mb_substr($responseArrayData['orderBundle']['cartItems']['items'][0]['itemCode'], 2, 7);
					$barcode = random_int(1000000000,9999999999);
					$paymentId = $responseArrayData['orderNumber'];
					$rrn = $responseArrayData['authRefNum'];
					$EventDate = mb_substr($responseArrayData['orderBundle']['cartItems']['items'][0] ['itemCode'], 10, 10);
					$cardAuthInfo = $responseArrayData['cardAuthInfo']['maskedPan'];
					$secdate = mb_substr($date, 0, 10);
					$LocalDate = $secdate + 7 * 3600;
					$normalDate = date('d/m/Y H:i:s', $LocalDate);

					$Normal_Place = mb_substr($responseArrayData['orderBundle']['cartItems']['items'][0] ['itemCode'], 21, 30);

					$str_len_phone = strlen($phone);

					if ($str_len_phone == 10){
						$mobilePhone = $phone;	
					}
					else {
						$mobilePhone = mb_substr($phone, 1, 10);
					}

					// ПИШЕМ ЛОГ ОБМЕНА СО СБЕРОМ
					$responseArrayDataString = serialize($responseArrayData);

					$localtime = new DateTime();
					$paid_normal = $localtime->format('Y-m-d H:i:s:u');

					$filename = __DIR__ . '/curlinfo.log';
					$fh = fopen($filename, 'c');
					fseek($fh, 0, SEEK_END);
					fwrite($fh, PHP_EOL . " ");
					fwrite($fh, PHP_EOL . "[$paid_normal] 429 switch case = [$action] ");
					fwrite($fh, PHP_EOL . "432 responseArrayDataString \n");
					//fwrite($fh, PHP_EOL . $new_str);
					fclose($fh);
					//закончили обмен со Сбером

					$ticketId = $this->sendTicketBase($firstName, $lastName, $mobilePhone, $price, $date, $eventId, $barcode, $paymentId, $rrn, $EventDate);

					$this->sendTicketDataToDatabase($order_id, $ticketId, $secdate, $firstName, $mobilePhone, $price, $eventId, $barcode, $paymentId, $rrn, $lastName, $EventDate, $cardAuthInfo, $normalDate, $Normal_Place);
					$response = json_decode($response, true);
					$orderStatus = $response['orderStatus'];

					if ($orderStatus == '1' || $orderStatus == '2') {
						if (!empty($this->success_url)) {
							$localtime = new DateTime();
							$paid_normal = $localtime->format('Y-m-d H:i:s:u');

							$filename = __DIR__ . '/curlinfo.log';
							$fh = fopen($filename, 'c');
							fseek($fh, 0, SEEK_END);
							fwrite($fh, PHP_EOL . "[$paid_normal] 463");
							fwrite($fh, PHP_EOL . "464 НОМЕР МЕТКИ сам заказ $order");
							fwrite($fh, PHP_EOL . "465 номер заказа старница итого $order_id");
							fwrite($fh, PHP_EOL . "466 orderStatus $orderStatus \n ");
							//fwrite($fh, PHP_EOL . "orderStatus $orderStatus" );
							//fwrite($fh, PHP_EOL . "orderStatus $orderStatus" );
							fclose($fh);
							//закончена страница итого

							WC()->cart->empty_cart();
							wp_redirect($this->success_url . "?order_id=" . $order_id);
							exit;

						}
						wp_redirect($this->get_return_url($order));

						$localtime = new DateTime();
						$paid_normal = $localtime->format('Y-m-d H:i:s:u');
						$filename = __DIR__ . '/curlinfo.log';
						$fh = fopen($filename, 'c');
						fseek($fh, 0, SEEK_END);
						fwrite($fh, PHP_EOL . "[$paid_normal] 489 public function callback switch case = [$action] exit \n ");
						fclose($fh);

						exit;
					} else {

						if (!empty($this->fail_url)) {
							wp_redirect($this->fail_url . "?order_id=" . $order_id);
							exit;
						}
						wc_add_notice(__('There was an error while processing payment<br/>', 'wc-puskhin-text-domain') . $response['actionCodeDescription'], 'error');
						wp_redirect($order->get_cancel_order_url());
						exit;
					}
					break;

				case "callback":
					//by callback
					$args['orderId'] = isset($_GET['mdOrder']) ? $_GET['mdOrder'] : null;

					$response = $this->_sendRBSData(http_build_query($args, '', '&'), $action_adr);

					if (RBS_ENABLE_LOGGING === true) {
						$logData = $args;
						$logData['password'] = '**removed from log**';
						$this->writeRBSLog("[491 REQUEST CB]: " . $action_adr . ": " . print_r($logData, true) . "\n[RESPONSE]: " . print_r($response, true));
					}

					$response = json_decode($response, true);

					// we should parse orderNumber for know internal order_id from $response
					$p = explode("_", $response['orderNumber']);
					$order_id = $p[0];
					$order = new WC_Order($order_id);
					$orderStatus = $response['orderStatus'];

					$orderdata = $order->get_data();
					$order_statuscon = $this->get_option('order_status');
					$serialize_order = serialize($orderdata);

					if ($order_statuscon == 'wc-processing') {
						$order_statusset = 'processing';				
					}
					else {
						$order_statusset = 'pending';
					}
					$ordergetstatus = $order->get_status();

					$localtime = new DateTime();
					$paid_normal = $localtime->format('Y-m-d H:i:s:u');

					$filename = __DIR__ . '/curlinfo.log';
					$fh = fopen($filename, 'c');
					fseek($fh, 0, SEEK_END);
					fwrite($fh, PHP_EOL . " ");
					fwrite($fh, PHP_EOL . "[$paid_normal] 521 BEFOR update_status ");
					//fwrite($fh, PHP_EOL . "serialize_order = $serialize_order");
					fwrite($fh, PHP_EOL . "orderStatus SBER = $orderStatus");
					fwrite($fh, PHP_EOL . "order_id = $order_id ");
					fwrite($fh, PHP_EOL . "order_statuscon = $order_statuscon ");
					fwrite($fh, PHP_EOL . "order_statusset = $order_statusset ");
					fwrite($fh, PHP_EOL . "orderStatus ORDER = $ordergetstatus \n" );

					if ($ordergetstatus == 'trash' || $ordergetstatus == 'completed' ) {
						exit;
					}

					if ($orderStatus == '1' || $orderStatus == '2') {

						//$order->update_status($this->order_status, __('Payment successful', 'wc-puskhin-text-domain'));

						// ЗАПИСЫВАЕМ ОРДЕР СТАТУС ПОЛУЧЕННЫЙ ОТ СБЕРА

						$ordergetstatus = $order->get_status();

						//$localtime = time() + 25200;
						//$paid_normal = date('d.m.y H:i', $localtime);

						$localtime = new DateTime();
						$paid_normal = $localtime->format('Y-m-d H:i:s:u');

						$filename = __DIR__ . '/curlinfo.log';
						$fh = fopen($filename, 'c');
						fseek($fh, 0, SEEK_END);
						//fwrite($fh, PHP_EOL . " ");
						fwrite($fh, PHP_EOL . "[$paid_normal] 578 AFTER update_status ");
						fwrite($fh, PHP_EOL . "579 orderStatus SBER = $orderStatus ");
						fwrite($fh, PHP_EOL . "580 order_id = $order_id");
						fwrite($fh, PHP_EOL . "581 orderStatus ORDER = $ordergetstatus \n");
						fclose($fh);

						//$order->payment_complete();

						$ordergetstatus = $order->get_status();

						//$localtime = time() + 25200;
						//$paid_normal = date('d.m.y H:i', $localtime);

						$localtime = new DateTime();
						$paid_normal = $localtime->format('Y-m-d H:i:s:u');

						$filename = __DIR__ . '/curlinfo.log';
						$fh = fopen($filename, 'c');
						fseek($fh, 0, SEEK_END);
						//fwrite($fh, PHP_EOL . " ");
						fwrite($fh, PHP_EOL . "[$paid_normal] 598 AFTER payment_complete ");
						fwrite($fh, PHP_EOL . "599 orderStatus SBER = $orderStatus ");
						fwrite($fh, PHP_EOL . "600 order_id = $order_id");
						fwrite($fh, PHP_EOL . "601 orderStatus ORDER = $ordergetstatus \n");
						fclose($fh);

						/* $localtime = time() + 25200;
						$paid_normal = date('d.m.y H:i', $localtime);
						$serializeorder = serialize($order);
						$filename = __DIR__ . '/curlinfo.log';
						$fh = fopen($filename, 'c');
						fseek($fh, 0, SEEK_END);
						fwrite($fh, PHP_EOL . $paid_normal);
						fwrite($fh, PHP_EOL . "513 НОМЕР МЕТКИ orderStatus $orderStatus" );
						//fwrite($fh, PHP_EOL . "514 result $serializeorder");
						fclose($fh);
						*/

						try {
							wc_reduce_stock_levels($order_id);
						} catch (Exception $e) {
						//noop
						}


						// ВОЗМОЖНЫЕ МЕТКИ ВТОРАЯ

						// $localtime = time() + 25200;
						// $paid_normal = date('d.m.y H:i', $localtime);

						$localtime = new DateTime();
						$paid_normal = $localtime->format('Y-m-d H:i:s:u');

						$filename = __DIR__ . '/curlinfo.log';
						$fh = fopen($filename, 'c');
						fseek($fh, 0, SEEK_END);
						fwrite($fh, PHP_EOL . "[$paid_normal] 635 ВРЕМЯ ПЕРЕДАЧИ ПОСЛЕДНЯЯ? ЭТО ПОСЛЕ payment_complete ВТОРАЯ \n");
						fclose($fh);

					} else {
						$order->update_status('failed', __('Payment failed', 'wc-puskhin-text-domain'));
						$order->cancel_order();
					}

					break;
			}
			exit;
		}
	}



	/**
	* Check if this gateway is enabled and available in the user's country
	*/

	function is_valid_for_use(){
		return true;
	}

	/*
	* Admin Panel Options
	*/

	public function admin_options(){
		?>

		<h3>puskhin</h3>
		<p><?php _e("Allow customers to conveniently checkout directly with ", 'wc-puskhin-text-domain'); ?><?php echo RBS_PAYMENT_NAME; ?></p>

		<?php if ($this->is_valid_for_use()) : ?>

			<table class="form-table">
			<?php
			// Generate the HTML For the settings form.
			$this->generate_settings_html();
			?>
			</table>
		
		<?php else : ?>
		
			<div class="inline error"><p>
			<strong><?php _e('Error: ', 'woocommerce'); ?></strong>: <?php echo $this->id; ?><?php _e(' does not support your currency.', 'wc-puskhin-text-domain'); ?>
			</p></div>
		
		<?php endif;
	}



	/*
	* Initialise Gateway Settings Form Fields
	*/

	function init_form_fields(){
		// ВОЗМОЖНЫЕ МЕТКИ ДЕСЯТАЯ

		// $localtime = time() + 25200;
		// $paid_normal = date('d.m.y H:i', $localtime);

		$localtime = new DateTime();
		$paid_normal = $localtime->format('Y-m-d H:i:s:u');

		$filename = __DIR__ . '/curlinfo.log';
		$fh = fopen($filename, 'c');
		fseek($fh, 0, SEEK_END);
		//fwrite($fh, PHP_EOL . "577 ВРЕМЯ ПЕРЕДАЧИ после идёт form_fields = array о прикол это function init_form_fields $paid_normal"); ЗАКОМЕНТИЛ ПОТОМУ ЧТО В РЕЖИМЕ ОЖИДАЕНИЯ ЗАСПАВЛИВАЕТ ВСЁ
		fclose($fh);

		$form_fields = array(
			'enabled' => array(
				'title' => __('Enable/Disable', 'wc-puskhin-text-domain'),
				'type' => 'checkbox',
				'label' => __('Enable', 'woocommerce') . " puskhin",
				'default' => 'yes'
			),
			'title' => array(
				'title' => __('Title', 'wc-puskhin-text-domain'),
				'type' => 'text',
				'description' => __('Title displayed to your customer when they make their order.', 'wc-puskhin-text-domain'),
				'desc_tip' => true,
			),
			'merchant' => array(
				'title' => __('Login-API', 'wc-puskhin-text-domain'),
				'type' => 'text',
				'default' => '',
				'desc_tip' => true,
			),
			'password' => array(
				'title' => __('Password', 'wc-puskhin-text-domain'),
				'type' => 'password',
				'default' => '',
				'desc_tip' => true,
			),
			'test_mode' => array(
				'title' => __('Test mode', 'wc-puskhin-text-domain'),
				'type' => 'checkbox',
				'label' => __('Enable', 'woocommerce'),
				'description' => __('In this mode no actual payments are processed.', 'wc-puskhin-text-domain'),
				'default' => 'no'
			),
			'stage_mode' => array(
				'title' => __('Payments type', 'wc-puskhin-text-domain'),
				'type' => 'select',
				'class' => 'wc-enhanced-select',
				'default' => 'one-stage',
				'options' => array(
					'one-stage' => __('One-phase payments', 'wc-puskhin-text-domain'),
					'two-stage' => __('Two-phase payments', 'wc-puskhin-text-domain'),
				),
			),
			'description' => array(
				'title' => __('Description', 'wc-puskhin-text-domain'),
				'type' => 'textarea',
				'description' => __('Payment description displayed to your customer.', 'wc-puskhin-text-domain'),
			),
			'order_status' => array(
				'title' => __('Payed order status', 'wc-puskhin-text-domain'),
				'type' => 'select',
				'class' => 'wc-enhanced-select',
				'description' => __('Payed order status.', 'wc-puskhin-text-domain'),
				'default' => 'wc-completed',
				'desc_tip' => true,
				'options' => array(
					'wc-processing' => _x('Processing', 'Order status', 'woocommerce'),
					'wc-completed' => _x('Completed', 'Order status', 'woocommerce'),
				),
			),
			'success_url' => array(
				'title' => __('success_url', 'woocommerce'),
				'type' => 'text',
				'description' => __('Page your customer will be redirected to after a <b>successful payment</b>.<br/>Leave this field blank, if you want to use default settings.', 'wc-puskhin-text-domain'),
			),
				'fail_url' => array(
				'title' => __('fail_url', 'woocommerce'),
				'type' => 'text',
				'description' => __('Page your customer will be redirected to after an <b>unsuccessful payment</b>.<br/>Leave this field blank, if you want to use default settings.', 'wc-puskhin-text-domain'),
			),
		);

		// ВОЗМОЖНЫЕ МЕТКИ ВОСЬМАЯ

		// $localtime = time() + 25200;
		// $paid_normal = date('d.m.y H:i', $localtime);

		$localtime = new DateTime();
		$paid_normal = $localtime->format('Y-m-d H:i:s:u');



		$filename = __DIR__ . '/curlinfo.log';
		$fh = fopen($filename, 'c');
		fseek($fh, 0, SEEK_END);
		//fwrite($fh, PHP_EOL . "651 ВРЕМЯ ПЕРЕДАЧИ это внутри форм филдс тока эррей экстендид $paid_normal"); В РЕЖИМЕР ОЖИДАНИЯ ЗАСПАМЛИВАЕТ ВСЁ
		fclose($fh);



		$form_fields_ext = array(
			'send_order' => array(
				'title' => __("Send cart data<br />(including customer info)", 'wc-puskhin-text-domain'),
				'type' => 'checkbox',
				'label' => __('Enable', 'woocommerce'),
				'description' => __('If this option is enabled order receipts will be created and sent to your customer and to the revenue service.<br/>This is a paid option, contact your bank to enable it. If you use it, configure VAT settings. VAT is calculated according to the Russian legislation. VAT amounts calculated by your store may differ from the actual VAT amounts that can be applied.', 'wc-puskhin-text-domain'),
				'default' => 'no'
			),

			'tax_system' => array(
				'title' => __('Tax system', 'wc-puskhin-text-domain'),
				'type' => 'select',
				'class' => 'wc-enhanced-select',
				'default' => '0',
				'options' => array(
					'0' => __('General', 'wc-puskhin-text-domain'),
					'1' => __('Simplified, income', 'wc-puskhin-text-domain'),
					'2' => __('Simplified, income minus expences', 'wc-puskhin-text-domain'),
					'3' => __('Unified tax on imputed income', 'wc-puskhin-text-domain'),
					'4' => __('Unified agricultural tax', 'wc-puskhin-text-domain'),
					'5' => __('Patent taxation system', 'wc-puskhin-text-domain'),
				),
			),

			'tax_type' => array(
				'title' => __('Default VAT', 'wc-puskhin-text-domain'),
				'type' => 'select',
				'class' => 'wc-enhanced-select',
				'default' => '0',
				'options' => array(
					'0' => __('No VAT', 'wc-puskhin-text-domain'),
					'1' => __('VAT 0%', 'wc-puskhin-text-domain'),
					'2' => __('VAT 10%', 'wc-puskhin-text-domain'),
					'3' => __('VAT 18%', 'wc-puskhin-text-domain'),
					'6' => __('VAT 20%', 'wc-puskhin-text-domain'),
					'4' => __('VAT applicable rate 10/110', 'wc-puskhin-text-domain'),
					'5' => __('VAT applicable rate 18/118', 'wc-puskhin-text-domain'),
					'7' => __('VAT applicable rate 20/120', 'wc-puskhin-text-domain'),
				),
			),

			// 'version' => array(
			// 'title' => __('Fiscal document format', 'wc-puskhin-text-domain'),
			// 'type' => 'select',
			// 'class' => 'wc-enhanced-select',
			// 'default' => 'v10',
			// 'options' => array(
			// 'v10' => __('FFD 1.0', 'wc-puskhin-text-domain'),
			// 'v105' => __('FFD 1.05', 'wc-puskhin-text-domain'),
			//// 'v11' => __('FFD 1.1', 'wc-puskhin-text-domain'),
			// ),
			// 'description' => __('Also specify the version in your bank web account and in your fiscal service web account.', 'wc-puskhin-text-domain'),
			// ),

			'paymentMethodType' => array(
				'title' => __('Payment type', 'wc-puskhin-text-domain'),
				'type' => 'select',
				'class' => 'wc-enhanced-select',
				'default' => '1',
				'options' => array(
					'1' => __('Full prepayment', 'wc-puskhin-text-domain'),
					'2' => __('Partial prepayment', 'wc-puskhin-text-domain'),
					'3' => __('Advance payment', 'wc-puskhin-text-domain'),
					'4' => __('Full payment', 'wc-puskhin-text-domain'),
					'5' => __('Partial payment with further credit', 'wc-puskhin-text-domain'),
					'6' => __('No payment with further credit', 'wc-puskhin-text-domain'),
					'7' => __('Payment on credit', 'wc-puskhin-text-domain'),
				),
			// 'description' => __('Used in FFD starting from 1.05', 'wc-puskhin-text-domain'),
			),
			'paymentMethodType_delivery' => array(
				'title' => __('Payment type for delivery', 'wc-puskhin-text-domain'),
				'type' => 'select',
				'class' => 'wc-enhanced-select',
				'default' => '1',
				'options' => array(
					'1' => __('Full prepayment', 'wc-puskhin-text-domain'),
					'2' => __('Partial prepayment', 'wc-puskhin-text-domain'),
					'3' => __('Advance payment', 'wc-puskhin-text-domain'),
					'4' => __('Full payment', 'wc-puskhin-text-domain'),
					'5' => __('Partial payment with further credit', 'wc-puskhin-text-domain'),
					'6' => __('No payment with further credit', 'wc-puskhin-text-domain'),
					'7' => __('Payment on credit', 'wc-puskhin-text-domain'),
				),
			// 'description' => __('Used in FFD starting from 1.05', 'wc-puskhin-text-domain'),
			),
			'paymentObjectType' => array(
				'title' => __('Type of goods and services', 'wc-puskhin-text-domain'),
				'type' => 'select',
				'class' => 'wc-enhanced-select',
				'default' => '1',
				'options' => array(
					'1' => __('Goods', 'wc-puskhin-text-domain'),
					'2' => __('Excised goods', 'wc-puskhin-text-domain'),
					'3' => __('Job', 'wc-puskhin-text-domain'),
					'4' => __('Service', 'wc-puskhin-text-domain'),
					'5' => __('Stake in gambling', 'wc-puskhin-text-domain'),
					// '6' => __('Gambling gain', 'wc-puskhin-text-domain'),
					'7' => __('Lottery ticket', 'wc-puskhin-text-domain'),
					// '8' => __('Lottery gain', 'wc-puskhin-text-domain'),
					'9' => __('Intellectual property provision', 'wc-puskhin-text-domain'),
					'10' => __('Payment', 'wc-puskhin-text-domain'),
					'11' => __("Agent's commission", 'wc-puskhin-text-domain'),
					'12' => __('Combined', 'wc-puskhin-text-domain'),
					'13' => __('Other', 'wc-puskhin-text-domain'),
				),
			// 'description' => __('Used in FFD starting from 1.05', 'wc-puskhin-text-domain'),
			),
		);



		// ВОЗМОЖНЫЕ МЕТКИ ДЕВЯТАЯ
		$localtime = time() + 25200;
		$paid_normal = date('d.m.y H:i', $localtime);
		$filename = __DIR__ . '/curlinfo.log';
		$fh = fopen($filename, 'c');
		fseek($fh, 0, SEEK_END);
		//fwrite($fh, PHP_EOL . "768 ВРЕМЯ ПЕРЕДАЧИ и это последняя строка this->form_fields = form_fields $paid_normal"); ВО ВРЕМЯ ОЖИДАНИЯ ЗАСПАМЛИВАЕТ ВСЁ
		fclose($fh);

		if (RBS_ENABLE_FISCALE_OPTIONS === true) {
			$form_fields = array_merge($form_fields, $form_fields_ext);
		}

		$this->form_fields = $form_fields;
	}



	function get_product_price_with_discount($price, $type, $c_amount, &$order_data)	{

		switch ($type) {

			case 'percent':
				$new_price = ceil($price * (1 - $c_amount / 100));
				// remove this discount from discount_total

				$order_data['discount_total'] -= ($price - $new_price);

			break;
			// case 'fixed_cart':
				// //wrong
				// $new_price = $price;
				// break;

			case 'fixed_product':
				$new_price = $price - $c_amount;

				// remove this discount from discount_total
				$order_data['discount_total'] -= $c_amount / 100;
				break;

			default:
				$new_price = $price;

		}
		return $new_price;
	}



	/*
	* Generate the dibs button link
	*/

	public function generate_form($order_id){
		// ВОЗМОЖНЫЕ МЕТКИ

		// $localtime = time() + 25200;
		// $paid_normal = date('d.m.y H:i', $localtime);



		$localtime = new DateTime();
		$paid_normal = $localtime->format('Y-m-d H:i:s:u');

		$filename = __DIR__ . '/curlinfo.log';
		$fh = fopen($filename, 'c');
		fseek($fh, 0, SEEK_END);
		fwrite($fh, PHP_EOL . "[$paid_normal] 965 public function generate_form \n");
		fclose($fh);

		$order = new WC_Order($order_id);
		$amount = $order->get_total() * 100;

		// COUPONS
		$coupons = array();

		global $woocommerce;

		if (!empty($woocommerce->cart->applied_coupons)) {
			foreach ($woocommerce->cart->applied_coupons as $code) {
				$coupons[] = new WC_Coupon($code);
			}
		}



		if ($this->test_mode == 'yes') {
			$action_adr = $this->test_url;
		} else {
			$action_adr = $this->prod_url;
		}



		$extra_url_param = '';
		if ($this->stage_mode == 'two-stage') {
			$action_adr .= 'registerPreAuth.do';
		} else if ($this->stage_mode == 'one-stage') {
			$extra_url_param = '&wc-callb=callback_function';
			$action_adr .= 'register.do';
		}

		$order_data = $order->get_data();


		$language = substr(get_bloginfo("language"), 0, 2);

		//fix Gate bug locale2country
		switch ($language) {
			case ('uk'):
				$language = 'ua';
				break;
			case ('be'):
				 $language = 'by';
				 break;
		}



		 $jsonParams_array = array(
			'CMS' => 'Wordpress ' . get_bloginfo('version') . " + woocommerce version: " . wpbo_get_woo_version_number(),
			'Module-Version' => $this->pData['Version'],
		 );



		 if (!empty($order_data['billing']['email'])) {
			$jsonParams_array['email'] = $order_data['billing']['email'];

		 }

		 if (!empty($order_data['billing']['phone'])) {
			$jsonParams_array['phone'] = preg_replace("/(\W*)/", "", $order_data['billing']['phone']);

		 }





		 if (!empty($order_data['billing']['first_name'])) {
			$jsonParams_array['payerFirstName'] = $order_data['billing']['first_name'];
		 }

		 if (!empty($order_data['billing']['last_name'])) {
			$jsonParams_array['payerLastName'] = $order_data['billing']['last_name'];
		 }

		 if (!empty($order_data['billing']['address_1'])) {
			$jsonParams_array['postAddress'] = $order_data['billing']['address_1'];
		 }

		 if (!empty($order_data['billing']['city'])) {
			$jsonParams_array['payerCity'] = $order_data['billing']['city'];
		 }

		 if (!empty($order_data['billing']['state'])) {
			 $jsonParams_array['payerState'] = $order_data['billing']['state'];
		 }

		 if (!empty($order_data['billing']['postcode'])) {
			$jsonParams_array['payerPostalCode'] = $order_data['billing']['postcode'];
		 }
		 
		 if (!empty($order_data['billing']['country'])) {
			 $jsonParams_array['payerCountry'] = $order_data['billing']['country'];
		 }



		 // prepare args array

		 $args = array(
			'userName' => $this->merchant,
			'password' => $this->password,
			'amount' => $amount,
		   // 'description' => $order_data['billing']['first_name'] . ' ' . $order_data['billing']['last_name'],
			'language' => $language,
			'returnUrl' => get_option('siteurl') . '?wc-api=WC_puskhin&puskhin=result&order_id=' . $order_id . $extra_url_param,
			'currency' => $this->currency_codes[get_woocommerce_currency()],
			'jsonParams' => json_encode($jsonParams_array),
		 );



		 if ($this->send_order == 'yes' && $this->fiscale_options === true) {

			$args['taxSystem'] = $this->tax_system;

			$order_items = $order->get_items();

			$order_timestamp_created = $order_data['date_created']->getTimestamp();

			$items = array();
			$itemsCnt = 1;


			foreach ($order_items as $value) {

			   $item = array();
			   $tax = new WC_Tax();
			   $product_variation_id = $value['variation_id'];

			   if ($product_variation_id) {

				  $product = new WC_Product_Variation($value['variation_id']);
				  $item_code = $itemsCnt . "-" . $value['variation_id'];

			   } else {
				  $product = new WC_Product($value['product_id']);

				  $SKU = $product->get_sku();

				  $item_code = $SKU;

				  //$item_code = $itemsCnt . "-" . $value['product_id'];
			   }

			   if (get_option("woocommerce_calc_taxes") == "no") { // PLUG-4056
				   $item_rate = -1;
			   } else {

				  $base_tax_rates = $tax->get_base_tax_rates($product->get_tax_class(true));
				  
				  if (!empty($base_tax_rates)) {
					  $rates = array_shift($tax->get_rates($product->get_tax_class()));
					  $item_rate = round(array_shift($rates));
				  } else {
					  $item_rate = -1;
				  }
			  }

			   if ($item_rate == 20) {
				   $tax_type = 6;
			   } else if ($item_rate == 18) {

				   $tax_type = 3;
			   } else if ($item_rate == 10) {
				   $tax_type = 2;
			   } else if ($item_rate == 0) {
				   $tax_type = 1;
			   } else {
				   $tax_type = $this->tax_type;
			   }

			   $product_price = round(($product->get_price()) * 100);

			   if ($product->get_type() == 'variation') {
			//TODO
				}

			   // if discount (coupon etc)
			   // see DISCOUNT SECTION
			  // foreach ($coupons as $coupon) {
			  // $coupon_amount = $coupon->get_amount() * 100;
			  // $product_price = $this->get_product_price_with_discount($product_price, $coupon->get_discount_type(), $coupon_amount, $order_data );
			  // }

			   $item['positionId'] = $itemsCnt++;
			   $item['name'] = $value['name'];
			   $item['quantity'] = array(
				  'value' => $value['quantity'],
				  'measure' => $this->measurement_name
			   );

			   $item['itemAmount'] = $product_price * $value['quantity'];

			   // ОЧИСТКА КОРЗИНЫ ЕСЛИ ПОЗИЦИЙ БОЛЬШЕ ЧЕМ ОДНА
			   $morethenone = $value['quantity'];

			   if ($morethenone > 1) {$item['itemAmount'] = 0;
				   global $woocommerce;
				   $woocommerce->cart->empty_cart();
				   $URL="https://.ru/";
				   header ("Location: https://.ru/");
			   }

			   $cart = $woocommerce->cart->get_cart();
			   $countcart = count($cart);

			   if ($countcart > 1) {
				   $item['itemAmount'] = 0;
				   global $woocommerce;
				   $woocommerce->cart->empty_cart();
				   $URL="https://.ru/";
				   header ("Location: https://.ru/");
			   }



			   $item['itemCode'] = $item_code;

			   $item['tax'] = array(
				   'taxType' => $tax_type
			   );

			   $item['itemPrice'] = $product_price;



			   $attributes = array();

			   $attributes[] = array(
				   "name" => "paymentMethod",
				   "value" => $this->paymentMethodType
			   );

			   $attributes[] = array(
				   "name" => "paymentObject",
				   "value" => $this->paymentObjectType
			   );

			   $item['itemAttributes']['attributes'] = $attributes;
			   $items[] = $item;
		   }


			// delivery_total
			$shipping_total = $order->get_shipping_total();

			// DISCOUNT

			if (!empty($order_data['discount_total'])) {
			   $discount = ($order_data['discount_total'] + $order_data['discount_tax']) * 100;

			   $new_order_total = 0;

			   // coze delivery will be another position
			   $delivery_sum = ($shipping_total > 0) ? $shipping_total * 100 : 0;

			   foreach ($items as &$i) {

				  $p_discount = intval(round(($i['itemAmount'] / ($amount - $delivery_sum + $discount)) * $discount, 2));

				  $this->correctBundleItem($i, $p_discount);
				  $new_order_total += $i['itemAmount'];
			   }

			   // reset order amount
			   // return delivery_sum into amount
			   $args['amount'] = $new_order_total + $delivery_sum;
			}





			// DELIVERY POSITION

			if ($shipping_total > 0) {
				
			   $itemShipment['positionId'] = $itemsCnt;
			   $itemShipment['name'] = __('Delivery', 'wc-puskhin-text-domain');
			   
			   $itemShipment['quantity'] = array(
				  'value' => 1,
				  'measure' => $this->measurement_name
			   );









			   $itemShipment['itemAmount'] = $itemShipment['itemPrice'] = $shipping_total * 100;

			   $itemShipment['itemCode'] = 'delivery';

			   $itemShipment['tax'] = array(
				   'taxType' => $this->tax_type
			   );

			   $attributes = array();

			   $attributes[] = array(
				  "name" => "paymentMethod",
				  "value" => $this->paymentObjectType_delivery
			   );

			   $attributes[] = array(
				  "name" => "paymentObject",
				  "value" => 4
			   );

			   $itemShipment['itemAttributes']['attributes'] = $attributes;
			   $items[] = $itemShipment;
			}

			$order_bundle = array(
			   'orderCreationDate' => $order_timestamp_created,
			   'cartItems' => array('items' => $items)
			);

			// ВОЗМОЖНЫЕ МЕТКИ 3-ПЯТАЯ

			// $localtime = time() + 25200;
			// $paid_normal = date('d.m.y H:i', $localtime);

			$localtime = new DateTime();
			$paid_normal = $localtime->format('Y-m-d H:i:s:u');

			$serializeorder_bundle = serialize($order_bundle);
			$filename = __DIR__ . '/curlinfo.log';
			$fh = fopen($filename, 'c');
			fseek($fh, 0, SEEK_END);
			fwrite($fh, PHP_EOL . "[$paid_normal] 1258 order_bundle \n");
			fclose($fh);

			if (!empty($order_data['billing']['email'])) {
			   $order_bundle['customerDetails']['email'] = $order_data['billing']['email'];
			}

			if (!empty($order_data['billing']['phone'])) {
				$order_bundle['customerDetails']['phone'] = preg_replace("/(\W*)/", "", $order_data['billing']['phone']);
			}
			 $args['orderBundle'] = json_encode($order_bundle);

		 }

		 $args['orderNumber'] = $order_id . '_' . time();
		 // $args['orderNumber'] = trim( str_replace( '#', '', $order->get_order_number() ) ) . "_" . time(); // PLUG-3966

		 $headers = array(
			'CMS: Wordpress ' . get_bloginfo('version') . " + woocommerce version: " . wpbo_get_woo_version_number(),
			'Module-Version: ' . $this->pData['Version'],

		 );

		 $response = $this->_sendRBSData(http_build_query($args, '', '&'), $action_adr, $headers);

		 if (RBS_ENABLE_LOGGING === true) {
			$logData = $args;
			$logData['password'] = '**removed from log**';
			$this->writeRBSLog("[REQUEST]: " . $action_adr . ": \nDATA: " . print_r($logData, true) . "\n[RESPONSE]: " . $response);
		 }

		 $response = json_decode($response, true);


		 if (empty($response['errorCode'])) {

			// ВОЗМОЖНЫЕ МЕТКИ

			// $localtime = time() + 25200;
			// $paid_normal = date('d.m.y H:i', $localtime);

			$localtime = new DateTime();
			$paid_normal = $localtime->format('Y-m-d H:i:s:u');



			$filename = __DIR__ . '/curlinfo.log';
			$fh = fopen($filename, 'c');
			fseek($fh, 0, SEEK_END);
			fwrite($fh, PHP_EOL . "[$paid_normal] 1302 ДО wp_redirect \n ");
			fclose($fh);

			wp_redirect($response['formUrl']);

			// ВОЗМОЖНЫЕ МЕТКИ

			// $localtime = time() + 25200;
			// $paid_normal = date('d.m.y H:i', $localtime);

			$localtime = new DateTime();
			$paid_normal = $localtime->format('Y-m-d H:i:s:u');

			$filename = __DIR__ . '/curlinfo.log';
			$fh = fopen($filename, 'c');
			fseek($fh, 0, SEEK_END);
			fwrite($fh, PHP_EOL . "[$paid_normal] 1319 public function generate_form ПОСЛЕ wp_redirect echo exit \n");
			fclose($fh);

			//EI: if is error in the headers (already send)
			echo '<p><a class="button cancel" href="' . $response['formUrl'] . '">' . __('Proceed with payment', 'wc-puskhin-text-domain') . '</a></p>';
			exit;

		 } else {
			return '<p>' . __('Error code #' . $response['errorCode'] . ': ' . $response['errorMessage'], 'wc-puskhin-text-domain') . '</p>' .
			'<a class="button cancel" href="' . $order->get_cancel_order_url() . '">' . __('Cancel payment and return to cart', 'wc-puskhin-text-domain') . '</a>';
		 }
	 }

	 // ПРО СКИДКУ ПОХОЖЕ //////////////////////////////////////////////////////
	 function correctBundleItem(&$item, $discount)	 {
		$item['itemAmount'] -= $discount;
		$item['itemPrice'] = $item['itemAmount'] % $item['quantity']['value'];

		if ($item['itemPrice'] != 0) {
			$item['itemAmount'] += $item['quantity']['value'] - $item['itemPrice'];
		}

		$item['itemPrice'] = $item['itemAmount'] / $item['quantity']['value'];
	 }



	 // ОКОНЧАНИЕ ПРО СКИДКУ //////////////////////////////////////////////////////

	 /*
	 * Process the payment and return the result
	 */

	 function process_payment($order_id){
		$order = new WC_Order($order_id);

		// ВОЗМОЖНЫЕ МЕТКИ////////////////////////////////////////////////////

		//$localtime = time() + 25200;
		//$paid_normal = date('d.m.y H:i', $localtime);

		$localtime = new DateTime();
		$paid_normal = $localtime->format('Y-m-d H:i:s:u');

		$serializeorder = serialize($order);
		$filename = __DIR__ . '/curlinfo.log';
		$fh = fopen($filename, 'c');
		fseek($fh, 0, SEEK_END);
		fwrite($fh, PHP_EOL . "[$paid_normal] 1366 function process_payment новый WC_Order $serializeorder ");
		fclose($fh);





		//if PLUG-2403
		if (!empty($_GET['pay_for_order']) && $_GET['pay_for_order'] == 'true') {
			$this->generate_form($order_id);

		// ВОЗМОЖНЫЕ МЕТКИ СЕДЬМАЯ

		// $localtime = time() + 25200;
		// $paid_normal = date('d.m.y H:i', $localtime);
			$localtime = new DateTime();
			$paid_normal = $localtime->format('Y-m-d H:i:s:u');

			$filename = __DIR__ . '/curlinfo.log';
			$fh = fopen($filename, 'c');
			fseek($fh, 0, SEEK_END);
			fwrite($fh, PHP_EOL . "ВРЕМЯ ПЕРЕДАЧИ СЕДЬМАЯ $paid_normal");
			fclose($fh);

			die;
		}


		$pay_now_url = $order->get_checkout_payment_url(true);

		$localtime = new DateTime();
		$paid_normal = $localtime->format('Y-m-d H:i:s:u');

		$filename = __DIR__ . '/curlinfo.log';
		$fh = fopen($filename, 'c');
		fseek($fh, 0, SEEK_END);
		fwrite($fh, PHP_EOL . "[$paid_normal] 1401 redirect = [$pay_now_url] \n");
		fclose($fh);


		return array(
			'result' => 'success',
			'redirect' => $pay_now_url
		);


	 }

	 /*
	 * Receipt page
	 */

	 function receipt_page($order) {
		// ВОЗМОЖНЫЕ МЕТКИ 1-ПЯТАЯ

		// $localtime = time() + 25200;
		// $paid_normal = date('d.m.y H:i', $localtime);

		$localtime = new DateTime();
		$paid_normal = $localtime->format('Y-m-d H:i:s:u');

		$filename = __DIR__ . '/curlinfo.log';
		$fh = fopen($filename, 'c');
		fseek($fh, 0, SEEK_END);
		fwrite($fh, PHP_EOL . "[$paid_normal] 1433 ВРЕМЯ ПЕРЕДАЧИ ЭТО СТРАЗУ ПОСЛЕ function receipt_page \n ");
		fclose($fh);

		echo $this->generate_form($order);

		// ВОЗМОЖНЫЕ МЕТКИ ПЯТАЯ

		$localtime = time() + 25200;
		$paid_normal = date('d.m.y H:i', $localtime);

		$filename = __DIR__ . '/curlinfo.log';
		$fh = fopen($filename, 'c');
		fseek($fh, 0, SEEK_END);
		fwrite($fh, PHP_EOL . "[$paid_normal] ВРЕМЯ ПЕРЕДАЧИ ПОСЛЕДНЯЯ СТРОКА ДО ОПЛАТЫ ЭТО ПОСЛЕ ЭХО ГЕНЕРЕЙТ ФОРМ СЛЕД СТРОКА МЕТОД ИЗМЕНЕНИЕ СТАТУСА ОПЛАТЫ ");
		fclose($fh);



	 }



	function writeRBSLog($var, $info = false)	 {

		$information = "";

		if ($var) {

			if ($info) {
			   $information = "\n\n";
			   $information .= str_repeat("-=", 64);
			   $information .= "\nDate: " . date('Y-m-d H:i:s');
			   $information .= "\nWordpress version " . get_bloginfo('version') . "; Woocommerce version: " . wpbo_get_woo_version_number() . "\n";

			}

			$result = $var;
			   if (is_array($var) || is_object($var)) {
				  $result = "\n" . print_r($var, true);
			   }

			$result .= "\n\n";
			$path = dirname(__FILE__) . '/wc_puskhin_' . date('Y-m') . '.log';
			error_log($information . $result, 3, $path);

			return $result;
		}
		return false;
	}

	function puskhin_change_status_function($order_id){
		$order = wc_get_order($order_id);
		$order->update_status('wc-complete');

		// ВОЗМОЖНЫЕ МЕТКИ ТРЕТЬЯ
		$localtime = time() + 25200;
		$paid_normal = date('d.m.y H:i', $localtime);

		$filename = __DIR__ . '/curlinfo.log';
		$fh = fopen($filename, 'c');
		fseek($fh, 0, SEEK_END);
		fwrite($fh, PHP_EOL . "[$paid_normal] ВРЕМЯ ПЕРЕДАЧИ ТРЕТЬЯ ");
		fclose($fh);
	}
 }

 function add_puskhin_gateway($methods)
 {

	$methods[] = 'WC_puskhin';

	// $localtime = time() + 25200;
	// $paid_normal = date('d.m.y H:i', $localtime);

	//$localtime = new DateTime();
	// $paid_normal = $localtime->format('Y-m-d H:i:s:u');

	//$serializemethods = serialize($methods);

	// $filename = __DIR__ . '/curlinfo.log';
	// $fh = fopen($filename, 'c');
	// fseek($fh, 0, SEEK_END);
	// fwrite($fh, PHP_EOL . "[$paid_normal] 1509 add_puskhin_gateway ");
	// fclose($fh);

	return $methods;
	// ВОЗМОЖНЫЕ МЕТКИ ЧЕТВЕРТАЯ

 }



 if (!function_exists('wpbo_get_woo_version_number')) {

	function wpbo_get_woo_version_number(){

		// If get_plugins() isn't available, require it

		if (!function_exists('get_plugins'))
			require_once(ABSPATH . 'wp-admin/includes/plugin.php');

		// Create the plugins folder and file variables
		$plugin_folder = get_plugins('/' . 'woocommerce');

		$plugin_file = 'woocommerce.php';

		// If the plugin version number is set, return it
		if (isset($plugin_folder[$plugin_file]['Version'])) {
			return $plugin_folder[$plugin_file]['Version'];
		} else {
		// Otherwise return null
			return NULL;

		}

	}

 }



 add_filter('woocommerce_payment_gateways', 'add_puskhin_gateway');

}

//Продолжение в части второй
//https://vk.com/@abcnsk-primer-koda-obmena-s-biletnym-reestrom-chast-vtoraya