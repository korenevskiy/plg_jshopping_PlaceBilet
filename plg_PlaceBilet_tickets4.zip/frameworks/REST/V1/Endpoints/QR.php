<?php
/*
=================================================================

Передача данных в билетный реестр при посещении при сканировании QR кода приложением на мобильном телефоне, передача данных в API visit date

REST/V1/Endpoints/QR.php

184 - 311 нужный модуль строки,
код добавленный начинается на 263 заканчивается на 366
*/


/**
 * Allow filtering the API key validation status.
 *
 * @since 5.2.5
 *
 * @param bool $is_valid Whether the provided API key is valid or not.
 * @param array $qr_arr The request data for Check in.
 */

$api_check = apply_filters( 'event_tickets_plus_requested_api_is_valid', $this->has_api( $qr_arr ), $qr_arr );



// Check all the data we need is there

if ( empty( $api_check ) || empty( $qr_arr['ticket_id'] ) ) {
	$response = new WP_REST_Response( $qr_arr );
	$response->set_status( 400 );

	return $response;
}



$ticket_id = (int) $qr_arr['ticket_id'];

$security_code = (string) $qr_arr['security_code'];



/** @var Tribe__Tickets__Data_API $data_api */

$data_api = tribe( 'tickets.data_api' );



$service_provider = $data_api->get_ticket_provider( $ticket_id );

if (empty( $service_provider->security_code )
	|| get_post_meta( $ticket_id, $service_provider->security_code, true ) !== $security_code

) {
	$response = new WP_REST_Response( [ 'msg' => __( 'Security code is not valid!', 'event-tickets-plus' ) ] );
	$response->set_status( 403 );
	return $response;
}



// add check attendee data

$attendee = $service_provider->get_attendees_by_id( $ticket_id );

$attendee = reset( $attendee );

if ( ! is_array( $attendee ) ) {
	$response = new WP_REST_Response( [ 'msg' => __( 'An attendee is not found with this ID.', 'event-tickets-plus' ) ] );
	$response->set_status( 403 );
	return $response;
}



// Add check for completed attendee status.

/** @var Tribe__Tickets__Status__Manager $status */
$status = tribe( 'tickets.status' );

$complete_statuses = (array) $status->get_completed_status_by_provider_name( $service_provider );

if ( ! in_array( $attendee['order_status'], $complete_statuses, true ) ) {
	$response = new WP_REST_Response(
	[
		'msg' => esc_html(
			// Translators: %s: 'ticket' label (singular, lowercase).
			sprintf(
				__( "This attendee's %s is not authorized to be Checked in", 'event-tickets-plus' ),
				tribe_get_ticket_label_singular_lowercase( 'rest_qr' )
			)
		),
	]);

	$response->set_status( 403 );
	return $response;
}



// check if attendee is checked in
$checked_status = get_post_meta( $ticket_id, '_tribe_qr_status', true );
if ( $checked_status ) {
	//$response = new WP_REST_Response( [ 'msg' => __( 'Already checked in!', 'event-tickets-plus' ) ] );


	$response = new WP_REST_Response( [ 'msg' => __( 'Already checked in!', 'event-tickets-plus' ) ] );

	$attendeeserialize = serialize($attendee);

	$order_idforcheckin = $attendee['order_id'];
	$filename = __DIR__ . '/curlinfo.log';
	$fh = fopen($filename, 'c');
	fseek($fh, 0, SEEK_END);
	fwrite($fh, PHP_EOL . $order_idforcheckin);
	fwrite($fh, PHP_EOL . $attendeeserialize);
	fclose($fh);

	$response->set_status( 403 );
	return $response;

}



$checked = $this->_check_in( $ticket_id, $service_provider );

if ( ! $checked ) {
	$msg_arr = [
		'msg' => esc_html( sprintf( __( '%s not checked in!', 'event-tickets-plus' ), tribe_get_ticket_label_singular( 'rest_qr' ) ) ),
		'tribe_qr_status' => get_post_meta( $ticket_id, '_tribe_qr_status', 1 ),
	];
	$result = array_merge( $msg_arr, $qr_arr );
	$response = new WP_REST_Response( $result );
	$response->set_status( 403 );

	return $response;

}



$response = new WP_REST_Response( [ 'msg' => __( 'Checked In!', 'event-tickets-plus' ) ] );
$ticketnumber = $attendee['ticket_id'];
$order_idforcheckin = $attendee['order_id'];

global $wpdb;

$localtime = time() + 25200;
$visited_normal = date('d.m.y H:i', $localtime);

$wpdb->update( 'ticket_id',
	//[ 'visited_unix' => $time],
	[ 'visited_normal' => $visited_normal],
	[ 'ticket_id' => $order_idforcheckin]
);



$gos = $wpdb->get_row( "SELECT * FROM ticket_id WHERE ticket_id = '$order_idforcheckin'" );
$gosId = $gos->gos_id;

$visit_date = time();

$ticketId = $gosId;
$url = 'https://pushka.gosuslugi.ru/api/v1/tickets/'. $ticketId . '/visit';

$data = [
	'visit_date' => $visit_date
];



$jsonData = json_encode($data);

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST,'PUT');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 4000);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ххххххх']);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);



$curlResult = curl_exec($ch);



if ($curlResult === FALSE) {
	$curlerror = curl_error($ch);
}

$curlinfo = curl_getinfo($ch);

$new_str2 = serialize($curlinfo);
$timeqr = time();
$dateqr = date("Передача данных автоматическая d.m.y H:i");
$localtime = time() + 25200;
$visited_normal = date('d.m.y H:i', $localtime);

$filename = __DIR__ . '/curlinfo.log';
curl_close($ch);
$filename = __DIR__ . '/curlinfo.log';
$fh = fopen($filename, 'c');
fseek($fh, 0, SEEK_END);
//fwrite($fh, PHP_EOL . $ticketnumber);
fwrite($fh, PHP_EOL . $visited_normal);
//fwrite($fh, PHP_EOL . $url);
fwrite($fh, PHP_EOL . $new_str2);

fclose($fh);













	$response->set_status( 201 );



	return $response;

//}