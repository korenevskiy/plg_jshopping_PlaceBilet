# CreateTicketRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**barcode** | **string** | ШК билета (QR-код) | 
**visitor** | [**\Swagger\Client\Model\Visitor**](Visitor.md) |  | 
**buyer** | [**\Swagger\Client\Model\Buyer**](Buyer.md) |  | 
**session** | [**\Swagger\Client\Model\Session**](Session.md) |  | 
**payment** | [**\Swagger\Client\Model\Payment**](Payment.md) |  | 
**comment** | **string** | Комментарий (для билета) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

