<?php 
//$api_url = 'https://pushka.gosuslugi.ru/api/v1/tickets';			// PROD
$api_url = 'https://pushka-uat.test.gosuslugi.ru/api/v1/tickets';	// UAT
 
function callAPI($method, $url, $data)
	{
		$curl = curl_init();
		switch ($method)
			{
				case "POST":
					curl_setopt($curl, CURLOPT_POST, 1);
					if ($data)
						curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
					break;
				case "PUT":
					curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
					if ($data)
						curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
					break;
				default:
					if ($data)
						$url = sprintf("%s?%s", $url, http_build_query($data));
			}
		// OPTIONS:
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_HTTPHEADER, array(
		'Authorization: Bearer 93x0ym7pznovkadof1lz', //сюда пишем свой ключ
		'Content-Type: application/json',
		'accept: application/json',
		));
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		// EXECUTE:
		$result = curl_exec($curl);
		if(!$result){die("Connection Failure");}
		curl_close($curl);
		return $result;
}
$data_array = array(
	"barcode" => '9004881200123', // 9004881200123 
	"barcode_type"=> "3",	// 9004881200123 
	 "visitor" => array(
			"full_name" => 'Kornelius Sergio'
	 ),
	 "buyer" => array(
			"mobile_phone" => '9004881200'
	 ),
	 "session" => array(
			"event_id" => '1858741',
			"organization_id" => '2557',
			"date" => intval(mktime(18, 00, 00, 12, 30, 2023)),//time()
	 ),
	 "payment" => array(
			"rrn" => '322',
			"date" => time(),//intval(mktime(22, 30, 0, 12, 31, 2022)),
			"amount" => '30'
	 )
);
$make_call = callAPI('POST', $api_url, json_encode($data_array));
$response = json_decode($make_call, true); //Тут будет массив с ответом. В частности в $resp['id'] будет айди билета, присвоенный реестром







echo "<pre>Запрос: ";
echo print_r($data_array,true); 
echo "</pre>";

echo "<br><br>Ответ JSON: <b>";
echo print_r($make_call,true); 
echo "</b><br><br>";


echo "<pre>Ответ: ";
echo print_r($response,true); 
echo "</pre>";

echo "<pre>Ответ: "; 
echo print_r(json_decode($make_call, JSON_PRETTY_PRINT),true);
echo "</pre>";

?>
<style>html{color: black;background-color: white; text-shadow: 0 0 none}</style>

<?php return;?>

Указано в событии про культура РФ
терминал
боевой токен о передачи сведений о билетах в 2 сайта