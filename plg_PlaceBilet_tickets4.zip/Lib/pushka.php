<?php
 /** ----------------------------------------------------------------------
 * plg_placebilet - Plugin Joomshopping Component for CMS Joomla
 * ------------------------------------------------------------------------
 * author    Sergei Borisovich Korenevskiy
 * @copyright (C) 2019 //explorer-office.ru. All Rights Reserved. 
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 * @package plg_placebilet
 * Websites: //explorer-office.ru/download/joomla/category/view/1
 * Technical Support:  Forum - //fb.com/groups/multimodulefb.com/groups/placebilet/
 * Technical Support:  Forum - //vk.com/placebilet
 * -------------------------------------------------------------------------
 * Test Token -		93x0ym7pznovkadof1lz
 **/ 
namespace API\Kultura;

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);


defined('_JEXEC') or die;

/* 
 * 93x0ym7pznovkadof1lz - Обмен идентификаторами - API для обмена идентификаторами системы «PRO.Культура.РФ». Токен для тестирования
 * https://pro.culture.ru/api/v2.5/pushka?apiKey=93x0ym7pznovkadof1lz
 * 
 * 
 * 
 */

class Pushka{
	
	private $api_url = 'https://pushka-uat.test.gosuslugi.ru/api/v1/tickets';	// UAT
//	private $api_url = 'https://pushka-uat.test.gosuslugi.ru/api/v1';	// UAT
//	private $api_url = 'https://pushka.gosuslugi.ru/api/v1/''			// PROD
	
	/**
	 * ВАШ_КЛЮЧ_БЕЗ_КАВЫЧЕК
	 * API_KEY_FOR_PROCULTURE
	 * @var string
	 */
	private string $api_key = '';
	
	/**
	 * ID Организации продаж билетов
	 * @var int
	 */
	private int $organization_id = 0;
	
	/**
	 * 
	 * @param string $api_key	Ключ доступа к API
	 * @param int $organization_id	ID Организации продаж билетов
	 */
	function __construct($organization_id = 0, $api_key = '93x0ym7pznovkadof1lz'){
		$this->organization_id = $organization_id;
		$this->api_key = $api_key; // API_KEY_FOR_PROCULTURE
	}
	
	/**
	 * 
	 * @param string $api_key	Ключ доступа к API
	 * @param int $organization_id	ID Организации продаж билетов
	 * @return self
	 */
	public static function getInstance($organization_id = 0, $api_key = '93x0ym7pznovkadof1lz') : self {
		return new self($organization_id, $api_key);
	}

	
	
	public function callAPI(PushkaData $data)
	{
		$method = $data->method;// getMethod();
		$urlSfx = $data->urlSfx;// getUrlSfx();
		
		$dataOpt = (string)$data;
		$url = $this->api_url . $urlSfx;
		$curl = curl_init();
		switch ($method)
		{
				case "POST":
					curl_setopt($curl, CURLOPT_POST, 1);
					if ($dataOpt)
						curl_setopt($curl, CURLOPT_POSTFIELDS, $dataOpt);
					break;
				case "PUT":
					curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
					if ($dataOpt)
						curl_setopt($curl, CURLOPT_POSTFIELDS, $dataOpt);
					break;
				default:
					if ($dataOpt)
						$url = sprintf("%s?%s", $url, http_build_query($dataOpt));
		}
		// OPTIONS:
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_HTTPHEADER, [
			'Authorization: Bearer ' . $this->api_key, //сюда пишем свой ключ
			'Content-Type: application/json',
			'accept: application/json',
			]);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		
		
echo "<pre>";
//echo print_r(json_decode($response, JSON_PRETTY_PRINT),true);
echo print_r($dataOpt,true);
echo "</pre>";
echo "<pre>";
//echo print_r(json_decode($response, JSON_PRETTY_PRINT),true);
echo print_r($method,true);
echo "</pre>";
echo "<pre>";
//echo print_r(json_decode($response, JSON_PRETTY_PRINT),true);
echo print_r($url,true);
echo "</pre>";
		
		
		// EXECUTE:
		$result = curl_exec($curl);
		if(!$result){
			die("Connection Failure");
		}
		curl_close($curl);
		return $result;
	}

	public function test() {
		return 'Hello World!';
	}
}


							 

/**
 * Класс данных для запроса в облако
 *
 * @since  1.0
 *
 * @property string $urlSfx					*Урл суфикс
 * @property string $method					*Метод запроса GET, POST, PUT, DELETE
 * 
 * 
 * 
 * @property string $barcode					*ШК билета
 * @property string $barcode_type
 * 
 * @property string $visitor_full_name		*ФИО (целиком)
 * @property string $visitor_first_name		Имя
 * @property string $visitor_middle_name		Отчество
 * @property string $visitor_last_name		Фамилия
 * 
 * 
 * @property string	$buyer_mobile_phone		*Мобильный телефон (10 цифр)
 * 
 * @property string $session_event_id		*ID мероприятия в PRO.Культура
 * @property string $session_organization_id	*ID организации в Про.Культура
 * @property ing	$session_date			*Дата/Время проведения сеанса (unix timestamp)
 * @property string $session_place			Адрес/описание места проведения мероприятия
 * @property string $session_params			Зал+Сектор+Ряд+Место	
 * 
 * @property string $payment_id				ID платежа у Билетного оператора
 * @property string $payment_rrn			RRN (Retrieval Reference Number) уникальный идентификатор транзакции
 * @property int	$payment_date			*Дата/время совершения платежа (unix timestamp
 * @property string	$payment_ticket_price	*Цена билета (номинал)
 * @property string	$payment_amount			*Сумма платежа по Пушкинской карте
 * 
 */
class PushkaData implements \JsonSerializable{ //
	
//	public const RequestAdd = 'add';
//	
//	public const RequestGet = 'get';
//	
//	public const RequestDel = 'del';
//	
//	public const RequestFin = 'fin';
//	
//	public const RequestAddQR = 'addQR';
//	
//	public const RequestFinQR = 'finQR';
	
//	public $request = 'add';
	
	/**
	 * Тип/Фильтр запроса
	 * @var array 
	 */
	public $rFilter = [];

	/**
	 * Или ID платежа у Билетного оператора(Добавление)
	 * Или ID билета (Получение, Удаление, Подтверждение)
	 * @var int
	 */
//	public $id = 0;

	/**
	 * ID мероприятия в PRO.Культура
	 * @var int
	 */
	public $event_id = 0;

	/**
	 * ШК билета - $ticket_code
	 * @var int 
	 */
//	public $barcode = 0;
	
//	public $methods = 'GET';
	
	
//	public $visitor = [
//		'full_name'=>''				// $buyer_name
//		];
	
//	public $buyer = [
//		'mobile_phone'=>''			// $phone
//		];
	
//	public $session = [
//		'event_id'		=>0,		// $event_id
//		'organization_id'=>0,		// $org_id
//		'date'			=>0			// $event_date (int)
//		];
	
//	public $payment = [
//		'rrn'			=>0,			// $rrn
//		'date'			=>0,			// $payment_date	(int)
//		'amount'		=>'',			// $payment_amount
//		];
	
	public function __get($param) {
		switch (strtolower($param)){
			case 'url_sfx':
			case 'urlsfx':
			case 'url-sfx':
				return $this->getUrlSfx();
			case 'method':
				return $this->getMethod();
			default :
				return $this->{$param} ?? null;
		}
	}
	
	
    public function __toString()
    {
        return json_encode($this);
    }
	
    public function jsonSerialize() : array {
		
		$data = [];
		foreach ($this->rFilter as $param => $type){
			if(is_string ($type) && isset($this->{$param})) {
				$data[$param] = $this->{$param} ?? '';
				settype($data[$param], $type);
				continue;
			}
			if(is_array ($type)){
				$params = $type;
				foreach ($params as $param2  => $type){
					if(isset($this->{$param}[$param2])){
						$data[$param][$param2] = $this->{$param}[$param2];
						settype($data[$param][$param2], $type);
					}elseif(isset($this->{"{$param}_{$param2}"})){
						$data[$param][$param2] = $this->{"{$param}_{$param2}"};
						settype($data[$param][$param2], $type);
					}elseif(isset($this->$param2)){
						$data[$param][$param2] = $this->$param2;
						settype($data[$param][$param2], $type);
					}
				}
			}
		}
		return $data;
		
//		
//		
//		switch ($this->rFilter){
//			case static::rAddTickets:
//				
//				return $data;
//				break;
//			default :
//				return [];
//				break;
//		}
		
        return '';
    }
	
	public function getUrlSfx(){
		switch ($this->rFilter){
			case static::rAddTickets:
				return '';
				break;
			case static::rGetTicket:
				return "/{$this->id}";
				break;
			case static::rDelTicket:
				return "/{$this->id}/refund";
				break;
			case static::rFinalTicket:
				return "/{$this->id}/visit";
				break;
			case static::rGetEvent:
				return "/{$this->event_id}/tickets/{$this->barcode}";
				break;
			case static::rFinalTicketQR:
				return "/{$this->event_id}/tickets/{$this->barcode}/visit";
				break;
			default: 
				return '';
		}
	}
	
	public function getMethod(){
		switch ($this->rFilter){
			case static::rAddTickets:
				return 'POST';
				break;
			case static::rGetTicket:
				return 'GET';
				break;
			case static::rDelTicket:
				return 'PUT';
				break;
			case static::rFinalTicket:
				return 'PUT';
				break;
			case static::rGetEvent:
				return 'GET';
				break;
			case static::rFinalTicketQR:
				return 'PUT';
				break;
			default:
				return 'POST';
		}
	}
	
	
	public static function getInstance(array $data = []) : self{
		
		$obj = new self;
		
		foreach ($data as $prop => $val){
			$obj->{$prop} = $val;
		}
		
		return $obj;
	}
	
	function __construct(array $data = []){
		
		$this->rFilter = static::rAddTickets;
		
		foreach ($data as $prop => $val){
			$this->{$prop} = $val;
		}
	}
	
	/**
	 * @var array rAddTickets POST: Добавление билета в реестр
	 * Добавить в реестр информацию о билете, купленном по Пушкинской карте
	 * /tickets
	 */
	public const rAddTickets = [
//		'' => 'add',
		"barcode"=> "string",		// *ШК билета
		"barcode_type"=> "string",	// 9004881200123 
		"visitor"=> [			// Посетитель мероприятия
			"full_name"=> "string",		// *ФИО (целиком)
			"first_name"=> "string",	// Имя
			"middle_name"=> "string",	// Отчество
			"last_name"=> "string"		// Фамилия
		],
		"buyer"=> [				// Участник программы
			"mobile_phone"=> "string"	// *Мобильный телефон (10 цифр)
		],
		"session"=> [			// Сеанс
			"date"=> 'int',				// *Дата/Время проведения сеанса (unix timestamp)
			"event_id"=> "string",		// *ID мероприятия в PRO.Культура
			"organization_id"=> "string",//*ID организации в Про.Культура
			"place"=> "string",			// Адрес/описание места проведения мероприятия
			"params"=> "string",			// Зал+Сектор+Ряд+Место
		],
		"payment"=> [			// Платеж
			"date"=> 'int',				// *Дата/время совершения платежа (unix timestamp
			"id"=> "string",			// ID платежа у Билетного оператора
			"ticket_price"=> "string",	// *Цена билета (номинал)
			"amount"=> "string",			// *Сумма платежа по Пушкинской карте
			"rrn"=> "string",			// RRN (Retrieval Reference Number) уникальный идентификатор транзакции
		],
		"comment"=> "string"

	];
	
	
	
	/**
	 * @var array rGetTicket  GET: Запросить билет по ID
	 * Получение информации о билете
	 * /tickets/{id}
	 * ID билета
	 */
	public const rGetTicket = [
//		'' => 'get',
	];
	
	
	
	/**
	 *  @var array rDelTicket  PUT: Вернуть билет
	 * Добавить информацию о возврате билета
	 * /tickets/{id}/refund
	 * ID билета
	 */
	public const rDelTicket = [
//		'' => 'del',
	];
	
	/**
	 *  @var array rFinalTicket  PUT: Погасить билет
	 * Добавить в билет информацию о посещении
	 * /tickets/{id}/refund
	 * ID билета
	 */
	public const rFinalTicket = [
//		'' => 'fin',
	];
	
	
	
	
	/**
	 * @var array rGetEvent GET: Получение информации о сеансе по билету 
	 * Получение информации о сеансе по QR и ID события
	 * /events/{event_id}/tickets/{barcode}
	 * event_id  - ID мероприятия в ПРО.Культура
	 * barcode   - ШК билета
	 */
	public const rGetEvent = [
//		'' => 'addQR',
	];
	
	
	/**
	 * @var array rFinalTicketQR  PUT: Погасить билет
	 * Добавить в билет информацию о посещении
	 * /events/{event_id}/tickets/{barcode}/visit
	 * event_id -  ID мероприятия в ПРО.Культура
	 * barcode  -	ШК билета
	 */
	public const rFinalTicketQR = [
//		'' => 'finQR',
	];
	
	

}


