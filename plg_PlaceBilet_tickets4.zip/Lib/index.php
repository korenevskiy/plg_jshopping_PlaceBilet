<title>Пушка!!!</title>
<h4>Пушка!!</h4>
<?php
use API\Kultura\Pushka;
use API\Kultura\PushkaData;

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);


define('_JEXEC', true);

//echo "<br> 111<br>";

$lib = realpath(__DIR__ . '/pushka.php');
//echo $lib . '<br> ';
require_once $lib ;
//echo file_exists($lib) ? 'Yes' : 'Noe';
//echo "<br> 222";
//https://3dsec.sberbank.ru/payment/rest
//https://securepayments.sberbank.ru/payment/rest/

// Инициализация объекта API
$api_key = '';
$organization_id = 2557;
$pushka = Pushka::getInstance($organization_id);


// Публикация Билета
$data = PushkaData::getInstance();
$data->rFilter					= PushkaData::rAddTickets;
$data->buyer_mobile_phone		= '9004881200'; // *Мобильный телефон (10 цифр)

$data->payment_ticket_price		= '6600';		// *Цена билета (номинал)
$data->payment_date				= time();//0;//time();		// *Дата/время совершения платежа (unix timestamp
$data->payment_amount			= 6600; // *Сумма платежа по Пушкинской карте

$data->session_event_id			= 1858741; //*ID мероприятия в PRO.Культура
$data->session_organization_id	= $organization_id;//666666; //*ID организации в Про.Культура
$data->session_date				= mktime(18, 00, 00, 12, 30, 2022);	//*Дата/Время проведения сеанса (unix timestamp)
		 
$data->barcode					= '9004881200123';
$data->barcode_type				= '3';
$data->visitor_full_name		= "Kornelius";// Серджио Великий

// Необязательные свойства
$data->comment			= "KogdaJe!";
$data->payment_id		= 123;  // ID платежа у Билетного оператора
$data->payment_rrn		= 321;	// RRN (Retrieval Reference Number) уникальный идентификатор транзакции
$data->session_place	= "OMII IZO/ main hall"; // Адрес/описание места проведения мероприятия
$data->params			= "1zal 2sector 1ryad 3mesto."; // Зал+Сектор+Ряд+Место
$data->visitor_first_name = 'Sergio';
$data->visitor_middle_name = 'Bors';
$data->visitor_last_name = 'Ko';


echo "<pre>";
echo print_r(json_decode($data, JSON_PRETTY_PRINT),true);
echo "</pre><br>";

// Запрос API - Публикация Билета
$response = $pushka->callAPI($data);

echo "<pre>";
//echo print_r(json_decode($response, JSON_PRETTY_PRINT),true);
echo print_r($response,true);
echo "</pre>";
//$data->

//echo "<br> 333";
//echo $pushka->test();
//echo "<br> 444";



?>
<style>html{color: white;background-color: black;text-shadow: 0 0 none;}</style>