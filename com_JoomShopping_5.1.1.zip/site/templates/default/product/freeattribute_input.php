<?php
/**
* @version      5.1.0 14.09.2022
* @author       MAXXmarketing GmbH
* @package      Jshopping
* @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
* @license      GNU/GPL
*/

defined('_JEXEC') or die();
?>
<input type="text" class="inputbox" size="40" name="freeattribut[<?php print $this->id?>]" value="<?php print htmlspecialchars($this->value)?>">