<?php 
/**
* @version      4.15.2 02.02.2017
* @author       MAXXmarketing GmbH
* @package      Jshopping
* @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
* @license      GNU/GPL
*/
defined('_JEXEC') or die();
?>
<div class="jshop jshopcontent" id="comjshop">
<?php print $this->text?>
</div>