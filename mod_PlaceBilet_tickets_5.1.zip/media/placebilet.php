<?php defined('_JEXEC') or die;
 /** ----------------------------------------------------------------------
 * mod_PlaceBilet - Module for plagin Joomshopping Component for CMS Joomla
 * Потом разархивирует архивы в новое место где располагается папка пакета
 * В результате в новой папке пакета находятся архивы и папки расширений
 * ------------------------------------------------------------------------
 * author    Sergei Borisovich Korenevskiy
 * @copyright (C) 2019 //explorer-office.ru. All Rights Reserved. 
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 * @package plg_PlaceBilet
 * Websites: //explorer-office.ru/download/joomla/category/view/1
 * Technical Support:  Forum - //fb.com/groups/multimodulefb.com/groups/placebilet/
 * Technical Support:  Forum - //vk.com/placebilet
 * -------------------------------------------------------------------------
 **/ 
echo file_get_contents(__DIR__ . '/placebilet.js');
