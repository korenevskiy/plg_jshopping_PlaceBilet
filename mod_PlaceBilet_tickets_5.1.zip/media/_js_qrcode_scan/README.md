<<<<<<< HEAD
=======
# js_qrcode_scan
js_qrcode_scan

>>>>>>> 564c04c929775637a6adb8f8e7d0893aa7865935
# QR-Code-Scanning-Form
QR Code Scanning From HTML, JS

**Note**
* QRCode Upload must be JPG or PNG format

![QR Code Scanning From HTML, JS](h1.PNG)

<<<<<<< HEAD
![QR Code](qrcode_ex.jpg)
=======
![QR Code](qrcode_ex.jpg)
>>>>>>> 564c04c929775637a6adb8f8e7d0893aa7865935
