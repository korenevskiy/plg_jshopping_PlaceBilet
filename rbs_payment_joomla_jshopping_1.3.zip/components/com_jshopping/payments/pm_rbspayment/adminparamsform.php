<?php
/*
 * @version      1.1.2
 * @author       RBS
 * @package      Jshopping
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die();

?>
<div class="col100">
    <fieldset class="adminform">
        <table class="admintable" width="100%">
            <tr>
                <td style="width:400px;" class="key">
                    Тестовый режим
                </td>
                <td>
                    <?php
                    print JHTML::_('select.booleanlist', 'pm_params[rbs_test_mode]', 'class = "inputbox" size = "1"', $params['rbs_test_mode']);

                    ?>
                </td>
            </tr>

            <tr>
                <td class="key" width="300">
                    Логин
                </td>
                <td>
                    <input type="text" name="pm_params[rbs_merchant_login]" class="inputbox"
                           value="<?= isset($params['rbs_merchant_login']) ? $params['rbs_merchant_login'] : ""?>">
                </td>
            </tr>

            <tr>
                <td class="key">
                    Пароль
                </td>
                <td>
                    <input type="text" name="pm_params[rbs_merchant_password]" class="inputbox"
                           value="<?= isset($params['rbs_merchant_password']) ? $params['rbs_merchant_password'] : "" ?>">
                </td>
            </tr>
            <tr>
                <td style="width:250px;" class="key">
                    Двустадийные платежы
                </td>
                <td>
                    <?php
                    print JHTML::_('select.booleanlist', 'pm_params[rbs_two_stage]', 'class = "inputbox" size = "1"', $params['rbs_two_stage']);
                    ?>
                </td>
            </tr>

            <tr>
                <td class="key">
                    Статус заказа при успешном платеже
                </td>
                <td>
                    <?php print JHTML::_('select.genericlist', $orders->getAllOrderStatus(), 'pm_params[transaction_end_status]', 'class = "inputbox" ', 'status_id', 'name', $params['transaction_end_status']); ?>
                </td>
            </tr>
            <tr>
                <td class="key">
                    Статус заказа при неудачном платеже
                </td>
                <td>
                    <?php echo JHTML::_('select.genericlist', $orders->getAllOrderStatus(), 'pm_params[transaction_failed_status]', 'class = "inputbox" ', 'status_id', 'name', $params['transaction_failed_status']); ?>
                </td>
            </tr>
            <tr>
                <td class="key">
                    Передача товарной корзины на шлюз
                </td>
                <td>
                    <?php
                    print JHTML::_('select.booleanlist', 'pm_params[rbs_send_order]', 'class = "inputbox" size = "1"', $params['rbs_send_order']);

                    ?>
                </td>
            </tr>
            <tr>
                <td class="key">
                    Система налогообложения
                </td>
                <td>
                    <?php echo JHTML::_('select.genericlist', $rbs_taxSystems, 'pm_params[rbs_tax_system]', 'class = "inputbox"', 'id', 'name', $params['rbs_tax_system']);?>
                </td>
            </tr>
            <tr>
                <td class="key">
                    Формат фискальных документов<br/><em>(ВАЖНО! Формат версии требуется указать в личном кабинете банка и в кабинете сервиса фискализации)</em>
                </td>
                <td>
                    <?php echo JHTML::_('select.genericlist', $rbs_ffdVersions, 'pm_params[rbs_ffd_version]', 'class = "inputbox"', 'id', 'name', $params['rbs_ffd_version']);?>
                </td>
            </tr>
            <tr>
                <td class="key">
                    Тип оплаты<br/><em>(Используется в версих ФФД, начиная с 1.05)</em>
                </td>
                <td>
                    <?php echo JHTML::_('select.genericlist', $rbs_ffd_paymentMethodTypeList, 'pm_params[rbs_ffd_paymentMethodType]', 'class = "inputbox"', 'id', 'name', $params['rbs_ffd_paymentMethodType']);?>
                </td>
            </tr>
            <tr>
                <td class="key">
                    Тип оплачиваемой позиции<br/><em>(Используется в версих ФФД, начиная с 1.05)</em>
                </td>
                <td>
                    <?php echo JHTML::_('select.genericlist', $rbs_ffd_paymentObjectTypeList, 'pm_params[rbs_ffd_paymentObjectType]', 'class = "inputbox"', 'id', 'name', $params['rbs_ffd_paymentObjectType']);?>
                </td>
            </tr>



        </table>
    </fieldset>
</div>
<div class="clr"></div>