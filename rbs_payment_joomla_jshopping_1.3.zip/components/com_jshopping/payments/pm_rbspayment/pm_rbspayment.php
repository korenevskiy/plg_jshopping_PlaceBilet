<?php
/*
 * @version      1.2.0
 * @author       RBS
 * @package      Jshopping
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
defined('_JEXEC') or die('Restricted access');
require_once(__DIR__ . '/include.php');
require_once(__DIR__ . '/rbs_discount.php');

class pm_rbspayment extends PaymentRoot
{
    const VERSION = '1.2.0';
    const ORDER_APPROVED = 'approved';
    const ORDER_DECLINED = 'declined';
    const SIGNATURE_SEPARATOR = '|';
    const ORDER_SEPARATOR = ":";

    function showPaymentForm($params, $pmconfigs)
    {
        include(dirname(__FILE__) . "/paymentform.php");
    }

    /**
     * Данный метод отвечает за настройки плагина в админ. части
     * @param $params Параметры настроек плагина
     */
    function showAdminFormParams($params)
    {
        $module_params_array = array(
            'rbs_merchant_login',
            'rbs_merchant_password',
            'rbs_test_mode',
            'rbs_two_stage',
            'rbs_send_order',
            'rbs_tax_system',
            'transaction_end_status',
            'transaction_failed_status'
        );
        foreach ($module_params_array as $module_param) {
            if (!isset($params[$module_param]))
                $params[$module_param] = '';
        }

        $rbs_taxSystems = array();
        $rbs_taxSystems[] = JHTML::_('select.option', 0, 'Общая', 'id', 'name');
        $rbs_taxSystems[] = JHTML::_('select.option', 1, 'Упрощённая, доход', 'id', 'name');
        $rbs_taxSystems[] = JHTML::_('select.option', 2, 'Упрощённая, доход минус расход', 'id', 'name');
        $rbs_taxSystems[] = JHTML::_('select.option', 3, 'Eдиный налог на вменённый доход', 'id', 'name');
        $rbs_taxSystems[] = JHTML::_('select.option', 4, 'Eдиный сельскохозяйственный налог', 'id', 'name');
        $rbs_taxSystems[] = JHTML::_('select.option', 5, 'Патентная система налогообложения', 'id', 'name');

        $rbs_ffdVersions = array();
        $rbs_ffdVersions[] = JHTML::_('select.option', 'v10', 'v1.0', 'id', 'name');
        $rbs_ffdVersions[] = JHTML::_('select.option', 'v105', 'v1.05', 'id', 'name');
//        $rbs_ffdVersions[] = JHTML::_('select.option', 'v11', 'v1.1', 'id', 'name');

        $rbs_ffd_paymentMethodTypeList = array();
        $rbs_ffd_paymentMethodTypeList[] = JHTML::_('select.option', '1', 'Полная предварительная оплата до момента передачи предмета расчёта', 'id', 'name');
        $rbs_ffd_paymentMethodTypeList[] = JHTML::_('select.option', '2', 'Частичная предварительная оплата до момента передачи предмета расчёта', 'id', 'name');
        $rbs_ffd_paymentMethodTypeList[] = JHTML::_('select.option', '3', 'Аванс', 'id', 'name');
        $rbs_ffd_paymentMethodTypeList[] = JHTML::_('select.option', '4', 'Полная оплата в момент передачи предмета расчёта', 'id', 'name');
        $rbs_ffd_paymentMethodTypeList[] = JHTML::_('select.option', '5', 'Частичная оплата предмета расчёта в момент его передачи с последующей оплатой в кредит', 'id', 'name');
        $rbs_ffd_paymentMethodTypeList[] = JHTML::_('select.option', '6', 'Передача предмета расчёта без его оплаты в момент его передачи с последующей оплатой в кредит', 'id', 'name');
        $rbs_ffd_paymentMethodTypeList[] = JHTML::_('select.option', '7', 'Оплата предмета расчёта после его передачи с оплатой в кредит', 'id', 'name');

        $rbs_ffd_paymentObjectTypeList = array();
        $rbs_ffd_paymentObjectTypeList[] = JHTML::_('select.option', '1', 'Товар', 'id', 'name');
        $rbs_ffd_paymentObjectTypeList[] = JHTML::_('select.option', '2', 'Подакцизный товар', 'id', 'name');
        $rbs_ffd_paymentObjectTypeList[] = JHTML::_('select.option', '3', 'Работа', 'id', 'name');
        $rbs_ffd_paymentObjectTypeList[] = JHTML::_('select.option', '4', 'Услуга', 'id', 'name');
        $rbs_ffd_paymentObjectTypeList[] = JHTML::_('select.option', '5', 'Ставка азартной игры', 'id', 'name');
//        $rbs_ffd_paymentObjectTypeList[] = JHTML::_('select.option', '6', 'Выигрыш азартной игры', 'id', 'name');
        $rbs_ffd_paymentObjectTypeList[] = JHTML::_('select.option', '7', 'Лотерейный билет', 'id', 'name');
//        $rbs_ffd_paymentObjectTypeList[] = JHTML::_('select.option', '8', 'Выигрыш лотереи', 'id', 'name');
        $rbs_ffd_paymentObjectTypeList[] = JHTML::_('select.option', '9', 'Предоставление РИД', 'id', 'name');
        $rbs_ffd_paymentObjectTypeList[] = JHTML::_('select.option', '10', 'Платёж', 'id', 'name');
//        $rbs_ffd_paymentObjectTypeList[] = JHTML::_('select.option', '11', 'Агентское вознаграждение', 'id', 'name');
        $rbs_ffd_paymentObjectTypeList[] = JHTML::_('select.option', '12', 'Составной предмет расчёта', 'id', 'name');
        $rbs_ffd_paymentObjectTypeList[] = JHTML::_('select.option', '13', 'Иной предмет расчёта', 'id', 'name');


        $orders = JModelLegacy::getInstance('orders', 'JshoppingModel');
        include dirname(__FILE__) . '/adminparamsform.php';

    }


    function showEndForm($pmconfigs, $order)
    {

        $lang = JFactory::getLanguage()->getTag();
        switch ($lang) {
            case 'en_EN':
                $lang = 'en';
                break;
            case 'ru_RU':
                $lang = 'ru';
                break;
            default:
                $lang = 'ru';
                break;
        }
        $order_id = $order->order_id;
        $description = 'Order :' . $order_id;

        $base_url = JURI::root() . 'index.php?option=com_jshopping&controller=checkout&task=step7&js_paymentclass=' . __CLASS__ . '&order_id=' . $order_id;
        $success_url = $base_url . '&act=finish';
        $fail_url = $base_url . '&act=cancel';

        $amount = round($this->fixOrderTotal($order) * 100);
        $rbs_args = array(
            'orderNumber' => $order_id . self::ORDER_SEPARATOR . time(),
            'userName' => $pmconfigs['rbs_merchant_login'],
            'password' => $pmconfigs['rbs_merchant_password'],
            'amount' => $amount,
            'returnUrl' => $success_url,
            'failUrl' => $fail_url,
            'language' => $lang,
            'jsonParams' => json_encode(
                array(
                    'CMS:' => 'Joomla + Jshopping ',
                    'Module-Version: ' => self::VERSION,
//                        'Name' => $order_data['billing']['first_name'],
//                        'Famil' => $order_data['billing']['last_name']
                )
            ),
        );

        if ($pmconfigs['rbs_test_mode'] == 1) {
            $action_adr = RBS_TEST_URL;
        } else {
            $action_adr = RBS_PROD_URL;
        }
        if ($pmconfigs['rbs_two_stage'] == 0) {
            $action_adr .= 'register.do';
        } else {
            $action_adr .= 'registerPreAuth.do';
        }


        if ($pmconfigs['rbs_send_order'] == 1) {

            $rbs_args['taxSystem'] = $pmconfigs['rbs_tax_system'];

            $order_items = $order->getAllItems();

//            $items = array();
            $itemsCnt = 1;

            // here we will collect data for orderBundle
            $orderBundle = [];

            $orderBundle['customerDetails'] = array(
                'email' => $order->email
                //'phone' => preg_match('/[7]\d{9}/', $order_info['telephone']) ? $order_info['telephone'] : ''
            );


            /* Заполнение массива данных корзины */
            foreach ($order_items as $value) {
                $item = array();
                $item_tax = $value->product_tax;

                if ($item_tax == 20) {
                    $tax_type = 6;
                } else if ($item_tax == 18) {
                    $tax_type = 3;
                } else if ($item_tax == 10) {
                    $tax_type = 2;
                } else if ($item_tax == 0) {
                    $tax_type = 1;
                } else {
                    $tax_type = 0;
                }

                $product_price = ceil($value->product_item_price * 100);

                $item['positionId'] = $itemsCnt++;
                $item['name'] = $value->product_name;
                $item['quantity'] = array(
                    'value' => $value->product_quantity,
                    'measure' => 'шт'
                );
                $item['itemAmount'] = $product_price * $value->product_quantity;
                $item['itemCode'] = $value->product_id;
                $item['tax'] = array(
                    'taxType' => $tax_type
                );

                $item['itemPrice'] = $product_price;

                // FFD 1.05 added
                if ($pmconfigs['rbs_ffd_version'] == 'v105') {

                    $attributes = array();
                    $attributes[] = array(
                        "name" => "paymentMethod",
                        "value" => $pmconfigs['rbs_ffd_paymentMethodType']
                    );
                    $attributes[] = array(
                        "name" => "paymentObject",
                        "value" => $pmconfigs['rbs_ffd_paymentObjectType']
                    );

                    $item['itemAttributes']['attributes'] = $attributes;
                }

                $orderBundle['cartItems']['items'][] = $item;
            }

            //shipping_tax
            //order_created
            //email
            //f_name
            //l_name
            //phone


            // DISCOUNT CALCULATE (&remove delivery cost)
            if ($order->order_shipping > 0) {
                $amount -= ceil($order->order_shipping * 100);
            }
            $discountHelper = new rbsDiscount();
            $discount = $discountHelper->discoverDiscount($amount, $orderBundle['cartItems']['items']);
            if ($discount > 0) {
                $discountHelper->setOrderDiscount($discount);
                $recalculatedPositions = $discountHelper->normalizeItems($orderBundle['cartItems']['items']);
                $orderBundle['cartItems']['items'] = $recalculatedPositions;
            }


            // DELIVERY POSITION
            if ($order->order_shipping > 0) {
                $itemShipment['positionId'] = $itemsCnt;
                $itemShipment['name'] = 'Доставка';
                $itemShipment['quantity'] = array(
                    'value' => 1,
                    'measure' => 'шт'
                );
                $itemShipment['itemAmount'] = $itemShipment['itemPrice'] = ceil($order->order_shipping * 100);
                $itemShipment['itemCode'] = 'Delivery';
                //todo
//                $itemShipment['tax'] = array(
//                    'taxType' => $this->ofd_taxType
//                );


                // FFD 1.05 added
                if ($pmconfigs['rbs_ffd_version'] == 'v105') {

                    $attributes = array();
                    $attributes[] = array(
                        "name" => "paymentMethod",
                        "value" => $pmconfigs['rbs_ffd_paymentMethodType']
                    );
                    $attributes[] = array(
                        "name" => "paymentObject",
                        "value" => 4
                    );

                    $itemShipment['itemAttributes']['attributes'] = $attributes;

                }
                $orderBundle['cartItems']['items'][] = $itemShipment;
            }


            /* Заполнение массива данных для запроса c фискализацией */
            $rbs_args['orderBundle'] = json_encode($orderBundle);
        }

        $rbsCurl = curl_init();
        curl_setopt_array($rbsCurl, array(
            CURLOPT_URL => $action_adr,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_POSTFIELDS => http_build_query($rbs_args, '', '&'),
            CURLOPT_HTTPHEADER => array(
                'CMS: Joomla + JoomShopping ',
                'Module-Version: ' . self::VERSION
            )
        ));

        $response = curl_exec($rbsCurl);

        $response = json_decode($response, true);
        curl_close($rbsCurl);

        if (!empty($response['formUrl'])) {
            header("Location: " . $response['formUrl']);
            exit;
        } else {
            echo "ERROR #" . $response['errorCode'] . ": " . $response['errorMessage'];
        }

    }


    function fixOrderTotal($order)
    {
        $total = $order->order_total;
        if ($order->currency_code_iso == 'HUF') {
            $total = round($total);
        } else {
            $total = number_format($total, 2, '.', '');
        }
        return $total;
    }


    function checkTransaction($pm_config, $order, $rescode)
    {

		
//		\Joomla\CMS\Factory::getApplication()->getInput()->getArray('');
		$request = \Joomla\CMS\Factory::getApplication()->getInput();
		
//        $payment_data = JRequest::get('get');

//        $rbs_order_id = $payment_data['orderId'];
        $rbs_args = array(
            'userName'	=> $request->getString('rbs_merchant_login'),	// $pm_config['rbs_merchant_login'],
            'password'	=> $request->getString('rbs_merchant_password'),// $pm_config['rbs_merchant_password'],
            'orderId'	=> $request->getString('orderId'),				// $rbs_order_id,
        );

        if ($pm_config['rbs_test_mode'] == 1) {
            $action_adr = RBS_TEST_URL;
        } else {
            $action_adr = RBS_PROD_URL;
        }

        $action_adr .= 'getOrderStatus.do';

        $rbsCurl = curl_init();
        curl_setopt_array($rbsCurl, array(
            CURLOPT_URL => $action_adr,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($rbs_args),
        ));
        $response = curl_exec($rbsCurl);
        curl_close($rbsCurl);
        $response = json_decode($response, true);

        $orderStatus = $response['OrderStatus'];

        if ($orderStatus == '1' || $orderStatus == '2') {
            JFactory::getApplication()->enqueueMessage("Платеж успешно оплачен " . $request->getInt('payment_id'));// $_REQUEST['payment_id']);
            return [1, 'Платеж успешно оплачен. ID:' . $request->getInt('payment_id')];// $_REQUEST['payment_id']);
        } else {
            return [0, 'Транзакция была отклонена.'];
        }

    }

    function getUrlParams($rbs_config)
    {
        $params = array();
        $input = JFactory::$application->input;
        $params['order_id'] = $input->getInt('order_id', null);
        $params['hash'] = "";
        $params['checkHash'] = 0;
        $params['checkReturnParams'] = 1;
        return $params;
    }
}