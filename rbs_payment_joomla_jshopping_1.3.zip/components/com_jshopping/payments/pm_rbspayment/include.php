<?php
/*
 * @version      1.2.0
 * @author       RBS
 * @package      Jshopping
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

define('RBS_PROD_URL' , 'https://securepayments.sberbank.ru/payment/rest/');
define('RBS_TEST_URL' , 'https://3dsec.sberbank.ru/payment/rest/');
