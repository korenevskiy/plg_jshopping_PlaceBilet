<script type="text/javascript">
function check_pm_modulbank(){
    $_('payment_form').submit();
}
</script>