<?php

/**
 * @package     Joomla.Administrator
 * @subpackage  plg_placebilet
 *
 * @copyright   (C) 2018 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Extension\Service\Provider\HelperFactory;
use Joomla\CMS\Extension\Service\Provider\Module;
use Joomla\CMS\Extension\Service\Provider\ModuleDispatcherFactory;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use Joomla\Plugin\Jshopping\Placebilet\Extension\Placebilet;
use Joomla\CMS\Plugin\PluginHelper as JPluginHelper;

/**
 * The placebilet plubin service provider.
 *
 * @since  4.0.0
 */
return new class implements ServiceProviderInterface
{
    /**
     * Registers the service provider with a DI container.
     *
     * @param   Container  $container  The DI container.
     *
     * @return  void
     *
     * @since   4.0.0
     */
	public function register(Container $container)
    {
		
//		$container->registerServiceProvider(new ModuleDispatcherFactory('\\Joomla\\Plugin\\Placebilet'));
//		$container->registerServiceProvider(new           HelperFactory('\\Joomla\\Plugin\\Placebilet\\Administrator\\Helper'));
//		if(file_exists(__DIR__.'/../src/Dispatcher/Dispatcher.php'))
//			require_once  __DIR__.'/../src/Dispatcher/Dispatcher.php';
		
        $container->set(
            PluginInterface::class,
            function (Container $container) {
				
				$plugin     =  new Placebilet(
					$container->get(DispatcherInterface::class),
					(array) JPluginHelper::getPlugin('jshopping', 'placebilet')
				);
				
                $plugin->setApplication(Factory::getApplication());
//echo "<pre>Cadabra placebilet  ". print_r(get_class($plugin), true) ."</pre>";
                return $plugin;
            }
        );
        $container->set(
            PluginInterface::class,
            function (Container $container) {
				
				$plugin     =  new Plugin(
					$container->get(DispatcherInterface::class),
					(array) JPluginHelper::getPlugin('jshopping', 'placebilet')
				);
				
                $plugin->setApplication(Factory::getApplication());
//echo "<pre>Cadabra placebilet  ". print_r(get_class($plugin), true) ."</pre>";
                return $plugin;
            }
        );
    }
};
