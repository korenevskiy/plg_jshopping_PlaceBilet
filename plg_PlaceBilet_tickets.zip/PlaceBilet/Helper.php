<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
defined('_JEXEC') or die;

require_once (JPATH_SITE.'/components/com_jshopping/lib/factory.php'); 
require_once (JPATH_SITE.'/components/com_jshopping/lib/functions.php');

class PlaceBiletHelper{
    public static function getView($name){
		$jshopConfig = JSFactory::getConfig();		
		include_once(PlaceBiletPath."/views/".$name."/view.html.php");
		$config = array("template_path"=>$jshopConfig->template_path.$jshopConfig->template."/".$name);
		$viewClass = 'JshoppingView'.$name;
        $view = new $viewClass($config);
        return $view;
    }
    
    public static function JViewLegacy($name, $layout='', $base_path = ''){
        $config = array();
        
        $config['base_path'] = PlaceBiletPath;
        $config['name'] = $name;
        $config['layout'] = 'default';
        
        if($base_path)$config['base_path'] = $base_path;//$this->_basePath;//JPATH_COMPONENT
        if($name)$config['name'] = $name;//$this->_name;
        if($layout)$config['layout'] = $layout;//'default';
        //
        //$config['template_path'] = $this->_basePath . '/views/' . $this->getName() . '/tmpl';
        $config['template_path'] = $config['base_path'] . '/templates/' . $config['name'] . '';
        $view = new JViewLegacy($config);
        return $view;
    }


    public static function getLoadTemplate(&$pathTemplateFile){
        
        if(!file_exists ($pathTemplateFile))
            return FALSE;
        
        ob_start();
        include $pathTemplateFile;

        $output = ob_get_contents();
	ob_end_clean();

	return $output;
    }
    
    public static function getTemplate(&$nameTemplate, $type='Site', $file='default'){
        $type = ucfirst(strtolower($type));
        $path = PlaceBiletPath."/templates/".$nameTemplate.$type."/$file.php";
        return getLoadTemplate($path);
    }
    public static function getTemplateSite(&$nameTemplate, $file='default'){         
        return getTemplateSite($nameTemplate, 'Site', $file);
    }
    public static function getTemplateAdmin(&$nameTemplate, $file='default'){         
        return getTemplateSite($nameTemplate, 'Admin', $file);
    }
    
//    public static function getView($name, $prefix = '', $type = '', $config = array()){
//        		// Clean the view name
//		$viewName = preg_replace('/[^A-Z0-9_]/i', '', $name);
//		$classPrefix = preg_replace('/[^A-Z0-9_]/i', '', $prefix);
//		$viewType = preg_replace('/[^A-Z0-9_]/i', '', $type);
//
//		// Build the view class name
//		$viewClass = $classPrefix . $viewName;
//                //dirname(__FILE__).DIRECTORY_SEPARATOR.'ClassesView'.DIRECTORY_SEPARATOR.''.DIRECTORY_SEPARATOR.''.DIRECTORY_SEPARATOR.'';
//                
//		if (!class_exists($viewClass))
//		{
//			jimport('joomla.filesystem.path');
//			$path = JPath::find($this->paths['view'], $this->createFileName('view', array('name' => $viewName, 'type' => $viewType)));
//
//			if ($path)
//			{
//				require_once $path;
//
//				if (!class_exists($viewClass))
//				{
//					throw new Exception(JText::sprintf('JLIB_APPLICATION_ERROR_VIEW_CLASS_NOT_FOUND', $viewClass, $path), 500);
//				}
//			}
//			else
//			{
//				return null;
//			}
//		}
//
//		return new $viewClass($config);
//    }
    
    public static function PlacesAttrValueDeleteId($id){
        $db = JFactory::getDBO();
	$query = "DELETE FROM `#__jshopping_attr_values` WHERE `value_id` = ".$db->escape($id)."; ";
	$db->setQuery($query);
	$db->query();
        return $query;
    }  
    
    public static function PlacesAttrValueRangeRemove($attr_id, $numberFirst=0, $numberLast=0){
        $numberFirst = intval($numberFirst);
        $numberLast = intval($numberLast);
        //if(PlaceBiletAdminDev)JFactory::getApplication()->enqueueMessage("<pre>Query: \t".$numberFirst.'-'.$numberLast."</pre>");//Warning,Error,Notice,Message
        
        $array = PlaceBiletHelper::getArrayFromRange($numberFirst, $numberLast);
        $query = PlaceBiletHelper::PlacesAttrValueDelete($attr_id, $array);        
        
        return $query;
    } 

    public static function PlacesAttrValueStringAdd($attr_id, $value){
         
         
        
        $nameLang = JSFactory::getLang()->get("name");
        $db = JFactory::getDBO();
        
        $query = "INSERT INTO `#__jshopping_attr_values` (attr_id, value_ordering, image, `$nameLang`) VALUES ";
        $query .= "(".$db->escape($attr_id).", 0, '','".$db->escape($value)."' ); ";
        
         
        
        //INSERT INTO #__jshopping_attr_values (attr_id,value_ordering,image,`name_en-GB`,`name_ru-RU`)
        //VALUES
        //(9631, 0, '','',2 ),
        //(9631, 0, '','',23 )
        
	$db->setQuery($query);
	$db->query();
        return $query;
    }
    
    public static function PlacesAttrValueArrayAdd($attr_id, $arr_values){
        $isArray = is_array($arr_values);
        if($isArray && count($arr_values)==1){
            //$arr_values = $arr_values[0];
            $isArray = FALSE;
        }
        
        if($isArray && count($arr_values)==0){
            return '';
        }
        
        $nameLang = JSFactory::getLang()->get("name");
        $db = JFactory::getDBO();
        
        $query = "INSERT INTO `#__jshopping_attr_values` (attr_id, value_ordering, image, `$nameLang`) VALUES ";
        
        foreach ($arr_values as $value){
            $query .= "(".$db->escape($attr_id).", 0, '','".$db->escape($value)."' ),";
        }
        
        $query = substr($query,0,-1)."; ";
        
        //INSERT INTO #__jshopping_attr_values (attr_id,value_ordering,image,`name_en-GB`,`name_ru-RU`)
        //VALUES
        //(9631, 0, '','',2 ),
        //(9631, 0, '','',23 )
        
	$db->setQuery($query);
	$db->query();
        return $query;
    }
    
    public static function PlacesAttrValueArrayRemove($attr_id, $arr_values){
        $isArray = is_array($arr_values);
        if($isArray && count($arr_values)==1){
            $arr_values = $arr_values[0];
            $isArray = FALSE;
        }
        
        if($isArray && count($arr_values)==0){
            return '';
        }
        
        $nameLang = JSFactory::getLang()->get("name");
        $db = JFactory::getDBO();
        $where = " WHERE `attr_id` = ".$db->escape($attr_id)." and ";
        
        if($isArray){
            $count = count($arr_values);
            
            $names = " '". implode("', '" , $arr_values )."' ";            
            $where .= " `".$nameLang."` IN (".$names.")";
        }
        else {
            $where .= " `".$nameLang."` = '".$db->escape($arr_values)."'"; 
        }
        
        $query = "DELETE FROM `#__jshopping_attr_values` ".$where." ; ";
        
	$db->setQuery($query);
	$db->query();
        return $query;
    }

    public static function getArrayFromString($places){
            $str_for_explode = str_replace(array(',', '.', ';'), ',', $places);             
            $tuples = explode(',', $str_for_explode);
            
            $arr = array();
            
            foreach ($tuples as $range){
                $t = trim($range);
                $range = explode('-', $t);
                $rng =  array();
                foreach ($range as $r){
                    $rng[] = intval(trim($r));
                }
                $range = $rng;
                $count = count($range);
                
                if($count == 0 || $count > 2 || ($count == 2 &&  $range[0] >= $range[1])){
                    JFactory::getApplication()->enqueueMessage("<pre>Ошибка в параметре: \t".$places.' ('.$t.")</pre>",'Error');
                    return '';
                }
                else if($count == 1){
                    $arr[] = intval(trim($range[0]));
                }
                else if($count == 2){
                    $first = $range[0];
                    $last = $range[1];
                    
                    $arr[] = intval(trim($first));
                    for(;$first<= $last;$first++){
                        $arr[] = intval(trim($first));
                    }
                }
            }
            
            $arr = array_unique($arr);
            sort ($arr);
        return $arr;
    }
    
    public static function getArrayFromRange($first, $last){ 
        $array = array(); 
        for(;$first<=$last;++$first){
            $array[]=$first;
        } 
        return $array;
    }
    
    
    public static function saveAttributesPlace($product, $product_id, $post){
        $dispatcher = JDispatcher::getInstance();
        $nameLang = JSFactory::getLang()->get("name");
        $product_id =  intval($post['product_id']); 
        
        $attrib_place_Int_tuple     = $post['attrib_place_Int_tuple'];                 //Список мест                    9, 11
        $attrib_place_Int_value_id  = $post['attrib_place_Int_value_id'];              //Список мест (без пробелов)     9__11
        $attrib_place_Int_id        = $post['attrib_place_Int_id'];                   //Список ID атрибутов для мест    9631
        $attrib_place_Int_price_mod = $post['attrib_place_Int_price_mod'];             //Знаки изменения цены           +
        $attrib_place_Int_price     = $post['attrib_place_Int_price'];                 //Цены                           350
        
        $attrib_place_Str_value_id  = $post['attrib_place_Str_value_id'];              // ID Value Атрибута             14991
        $attrib_place_Str_id        = $post['attrib_place_Str_id'] ;                  // Список ID Атрибутов для мест   9631
        $attrib_place_Str_price_mod = $post['attrib_place_Str_price_mod'] ;            // Знак модификации цены         +
        $attrib_place_Str_price     = $post['attrib_place_Str_price'] ;                // Цена                          350
        
        $attribs_id = array_unique(array_merge($attrib_place_Int_id,$attrib_place_Str_id));
        
        $dispatcher->trigger('onBeforeProductAttributPlaceStore', array(&$product_id, &$attrib_place_Int_tuple, &$attrib_place_Int_value_id, &$attrib_place_Int_id, &$attrib_place_Int_price_mod, $attrib_place_Int_price,
            &$attrib_place_Str_value_id, &$attrib_place_Str_id, &$attrib_place_Str_price_mod, $attrib_place_Str_price));
        
        $db = JFactory::getDBO();
        $arr_query = array();
        
        $query = "";
        $query = "DELETE pa2 FROM #__jshopping_products_attr2 pa2 LEFT JOIN #__jshopping_attr a ON a.attr_id= pa2.attr_id "
                 . "WHERE a.`attr_admin_type`=4 AND pa2.product_id=$product_id;";
        $query = "DELETE FROM #__jshopping_products_attr2 WHERE id IN (SELECT * FROM (SELECT pa2.id FROM #__jshopping_attr a, #__jshopping_products_attr2 pa2 "
                 . "WHERE a.`attr_admin_type`=4 AND pa2.product_id=$product_id AND a.attr_id= pa2.attr_id)  AS ids); ";
        $arr_query[] =$query;
        
        
        foreach($attrib_place_Int_tuple as $key=>$place_Str){
            $arr_Ints   = PlaceBiletHelper::getArrayFromString($place_Str); 
            $attr_id    = $attrib_place_Int_id[$key];
            $mod        = $attrib_place_Int_price_mod[$key];
            $price      = $attrib_place_Int_price[$key];
            $query = "INSERT INTO #__jshopping_products_attr2 (product_id, attr_id, attr_value_id, price_mod, addprice) "
                    . "SELECT $product_id product_id, $attr_id attr_id, value_id attr_value_id, '$mod' price_mod, $price addprice FROM #__jshopping_attr_values v "
                    . "WHERE v.attr_id=$attr_id AND `$nameLang` IN ('".join("','", $arr_Ints)."'); ";
            $arr_query[] = $query; 
        }
        
        
        $count_place_Str = count($attrib_place_Str_value_id);
        if($count_place_Str){
            $query = "INSERT INTO #__jshopping_products_attr2 (product_id, attr_id, attr_value_id, price_mod, addprice) VALUES ";
            foreach($attrib_place_Str_value_id as $key=>$value_id){
                $attr_id    = $attrib_place_Str_id[$key];
                $mod        = $attrib_place_Str_price_mod[$key];
                $price      = $attrib_place_Str_price[$key];
            
                $query .= "($product_id, $attr_id, $value_id, '$mod', $price )";
                if($count_place_Str > ($key + 1))
                    $query .=", ";
            }
            $query .='; ';
            $arr_query[] = $query; 
        }
        
        $delete_double = "DELETE FROM #__jshopping_products_attr2 WHERE id IN (SELECT pa2.pa2_max_id as id FROM 
            (SELECT count(*) `count`, max(id) pa2_max_id, product_id, attr_id, attr_value_id, price_mod, addprice 
            FROM #__jshopping_products_attr2 pa2 
            GROUP BY pa2.attr_value_id, pa2.product_id, pa2.attr_id ) AS pa2, #__jshopping_attr a 
            WHERE  `count`>1 AND a.`attr_admin_type`=4 AND pa2.attr_id = a.attr_id); ";
        //$arr_query[]=$delete_double;
        
        //$query = join("",$arr_query);
        $count_row = 0;
        $query = "";
        foreach ($arr_query as $q){
            $query .= $q;
            $db->setQuery($q);
            $db->query(); 
            $count_row += $db->getAffectedRows();
        }
        
//        $db->setQuery($query);
//        $db->queryBatch();
        
//        $db->setQuery($delete_double);
//        $db->query(); 
        
        if(PlaceBiletAdminDev) JFactory::getApplication()->enqueueMessage("<pre>Колличество затронутых строк: ".$count_row."<br>Count \$arr_query: ".(count($arr_query)-1)."<br>".$query."</pre>"); //print_r($query, TRUE)
        

        while($db->getAffectedRows()){
            $db->setQuery($delete_double);
            $db->query(); 
            $count_row -= $db->getAffectedRows();
        }
        
        extract(js_add_trigger(get_defined_vars(), "after"));    
        
        return $count_row;//$query;
        
        //https://www.ticketland.ru/cirki/cirk-nikulina-na-cvetnom-bulvare/bravo/
    }
    
    public static function getPlacesRequest(){
        $places = JRequest::getVar('jshop_place_id');
        if (!is_array($places)) 
            $places = array();
        foreach($places as $k=>$v){
            $places[intval($k)] = intval($v);
	}
	return $places;
    }
}