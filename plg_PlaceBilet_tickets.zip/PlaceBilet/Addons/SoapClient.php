<?php

    defined( '_JEXEC' ) or die( 'Restricted access' );
//error_reporting( E_ALL );
//echo "<br>?HELP!! <br>";
/**
 * 
 * @param object $obj объект в простыню 
 * @param string $head Заголовок перед простыней
 * @param string $separete текст одновременно до и после простени.
 */
function toLog($obj, $head = "",$separete=''){
    
    if(is_string($obj) && class_exists('JFactory'))        
        $obj = str_replace('#__',JFactory::getDbo()->getPrefix(),$obj);
    
    $print  = ($separete)?"\n $separete":"";
    $print .= ($head)?"\n- $head":"";
    $print .= "\n".print_r($obj,true)."\n";
    $print .= $separete; 
    file_put_contents (__DIR__. '/_log.txt'," \n $print  ", FILE_APPEND );
    //JFactory::getApplication()->enqueueMessage(print_r($query,true));
}

function prnt($obj, $head = "",$separete='', $count = 1, $show = TRUE){
    $pref = '';
    
    if(is_string($obj) && class_exists('JFactory'))        
        $obj = str_replace('#__',JFactory::getDbo()->getPrefix(),$obj);
    
    if(is_array($obj))        {
        $pref = ' Count:'.count($obj);
        if($count>0)
            $obj = array_slice($obj, 0,$count, TRUE);
    }
    $print  = ($separete)?"<br/>$separete":"";
//    $print .= ($head)?"<br/>$head":"";
    $print .= "<pre>$head $pref ".print_r($obj,true)."</pre>";
    $print .= $separete;
    if($show)
        echo $print;
    
    return $print;
}
function toStr( $value=''){//SimpleXMLElement
    //return $value;
//    if ($value->count()==0)                //prnt($value);
//            return $value;
    //return (string)$value;
    return trim((string)$value->__toString());
}

function array_sorting($array = [], $field = ''){
    if(count($array) == 0)
        return [];
    if($field == '') 
        ksort($array); 
    else{
        $keys = array_column($array, $field);
        array_multisort($keys, SORT_ASC, $array);
    }
    return $array;
}
/**
 * 
 * @see     http://market.zriteli.ru/docs/api_specification.pdf 
 */
class SoapClientZriteli extends SoapClient
{
    
    function __construct($url = '')
    { 
        
        if($url)
            parent::__construct($url);
        else
            parent::__construct('http://api.zriteli.ru/index.php?wsdl');
    }
    private static $RequestXMLs = array();
    public static $ErrorId = 0;
    public static $Errors = array();
    public static $Error = '';
    private static $ErrorView = FALSE;
    private static $Client = null;
    
    public static $UserId = 0;
    public static $UserHash = '';
    
    public $response;



    /**
    *  Выполение запроса и возврат XML данных из webservice
    * 
    * @param  string $userId MethodName  for request webservice
    * @param  string $userHash array Attrubtes data for request webservice
    * @param  bool $ErrorView array Attrubtes data for request webservice
    * @return string XML string response from webservice
    */
    public static function getInstance($userId = 111, $userHash = '698d51a19d8a121ce581499d7b701668', $ErrorView=FALSE)//
    {
        if(is_null(self::$Client))
            self::$Client = new self('http://api.zriteli.ru/index.php?wsdl'); 
        
        $userHash = trim($userHash);
        $userId = (int)$userId;
        
        //prnt('getInstanceZriteli: '.self::$UserId.' - '.self::$UserHash.'; '); 
        //prnt('getInstanceZriteli: '.$userId.' - '.$userHash.'; '); 
        
        if(     $userId != self::$UserId && $userHash != self::$UserHash && 
                $userId != 111 &&           $userHash != '698d51a19d8a121ce581499d7b701668' && 
                $userId != 0 &&             $userHash != '' && 
                $userId != NULL &&          $userHash != NULL){
            self::$UserId = (int)$userId;
            self::$UserHash = trim($userHash);
            self::$RequestXMLs = array();
            
            //prnt('getInstanceZriteli:! '.$userId.' - '.$userHash.'; '); 
        }
        self::$ErrorView = $ErrorView;
        
        
    
        if(count(self::$RequestXMLs)==0){
            self::$RequestXMLs['GetPlaceList']              ="<Request> <RequestAuthorization> <UserId>$userId</UserId> <Hash>$userHash</Hash> </RequestAuthorization> <RequestData/></Request>";
            self::$RequestXMLs['GetStageListByPlaceId']     ="<Request> <RequestAuthorization> <UserId>$userId</UserId> <Hash>$userHash</Hash> </RequestAuthorization> <RequestData> <RequestDataObject> <PlaceId>%d</PlaceId> </RequestDataObject> </RequestData> </Request>";
            self::$RequestXMLs['GetSectorListByStageId']    ="<Request> <RequestAuthorization> <UserId>$userId</UserId> <Hash>$userHash</Hash> </RequestAuthorization> <RequestData> <RequestDataObject> <StageId>%d</StageId> </RequestDataObject> </RequestData> </Request> ";
            self::$RequestXMLs['GetRepertoireListByStageId']="<Request> <RequestAuthorization> <UserId>$userId</UserId> <Hash>$userHash</Hash> </RequestAuthorization> <RequestData> <RequestDataObject> <StageId>%d</StageId> </RequestDataObject> </RequestData> </Request> ";
            self::$RequestXMLs['GetAgentList']              ="<Request> <RequestAuthorization> <UserId>$userId</UserId> <Hash>$userHash</Hash> </RequestAuthorization> </Request>";
            self::$RequestXMLs['GetOfferListByRepertoireId']="<Request> <RequestAuthorization> <UserId>$userId</UserId> <Hash>$userHash</Hash> </RequestAuthorization> <RequestData> <RequestDataObject> <RepertoireId>%d</RepertoireId> </RequestDataObject> </RequestData> </Request> ";
            self::$RequestXMLs['GetOfferById']              ="<Request> <RequestAuthorization> <UserId>$userId</UserId> <Hash>$userHash</Hash> </RequestAuthorization> <RequestData> <RequestDataObject> <OfferId>%d</OfferId > </RequestDataObject> </RequestData> </Request> ";
            self::$RequestXMLs['GetOfferListByEventInfo']   ="<Request> <RequestAuthorization> <UserId>$userId</UserId> <Hash>$userHash</Hash> </RequestAuthorization> <RequestData> <RequestDataObject> <RepertoireId>%d</RepertoireId> <EventDateTime>%s</EventDateTime> </RequestDataObject> </RequestData> </Request> ";
            self::$RequestXMLs['GetOfferIdBySeatInfo']      ="<Request> <RequestAuthorization> <UserId>$userId</UserId> <Hash>$userHash</Hash> </RequestAuthorization> <RequestData> <RequestDataObject> <RepertoireId>%d</RepertoireId> <EventDateTime>%s</EventDateTime> <SectorId>%d</SectorId> <Row>%s</Row> <Seat>%s</Seat> </RequestDataObject> </RequestData> </Request> ";
            self::$RequestXMLs['MakeOrder']                 ="<Request> <RequestAuthorization> <UserId>$userId</UserId> <Hash>$userHash</Hash> </RequestAuthorization> <RequestData> <RequestDataObject> <OfferId>%d</OfferId> <SeatList> %s </SeatList> </RequestDataObject> </RequestData> </Request>";
                   
            self::$RequestXMLs['CancelOrder']               ="<Request> <RequestAuthorization> <UserId>$userId</UserId> <Hash>$userHash</Hash> </RequestAuthorization> <RequestData> <RequestDataObject> <OrderId>%d</OrderId> </RequestDataObject> </RequestData> </Request> ";
        }
        return self::$Client;
    }
    
    
    /**
    *  Выполение запроса и возврат XML данных из webservice
    * 
    * @param  string $methodName MethodName  for request webservice
    * @param  array $attributes array Attrubtes data for request webservice
    * @return string XML string response from webservice
    */
    private function call($methodName, $attributes = array(),$getResultOrObject = FALSE){
        
        $xml = self::$RequestXMLs[$methodName];
        //prnt(self::$RequestXMLs,"","<0>");
        $xml = '<?xml version="1.0" encoding="UTF-8" ?'.'>'.$xml; 
        
        //prnt($xml,"","<1>");
        
        
        //$xml = sprintf ($xml,self::$UserId, self::$UserHash);
         
        //prnt($xml,"","<2>");//.self::$UserId." ".self::$UserHash
        
        $xml = vsprintf ($xml,$attributes);
        
        //prnt($xml,"","<3>"); 
        
        
        
        try {
            $this->response = self::$Client->__soapCall($methodName, array($xml));
             
            
        } catch (Exception $ex) {
            $error = $methodName.'('.  join(',', $attributes).')toRecive:';
            $error .= $ex->getMessage();
             
            self::viewExceprtion($error);
            self::$response = "";
        } 
        
        if($getResultOrObject)
            return self::$response;
        else
            return (is_object (self::$Client)? self::$Client: $this);
        
    }

    /**
    *  Преобразование XML в объект
    * 
    * @param  string $response XML для преобразования
    * @param  string $errorMessage  Message For Error Message (Method)
    * @param  array $errorAttributes  array Attrubtes For Error Message (Method)
    * @return array objects From Methods request 
    */
    private function recive($response='', $errorMessage='', $errorAttributes=array()){
        if(empty($response))
            $response = $this->response;
            
        try {
            $result = simplexml_load_string($response);
        } catch (Exception $ex) {
            $error = $errorMessage.'('.  join(',', $errorAttributes).')toObjects:';
            $error .= 'XML_START-> '.$response.' XML_STOP';
            $error .= $e->getMessage();
             
            self::viewExceprtion($error);
            $result = '';
        } 
        return $result;
    }
    
    /**
    *  Добавление(получение) последней ошибки 
    * 
    * @param  string $error exception adds new Error in array errors
    * @return string Error last message
    */
   public static function viewExceprtion($error = ""){
        
        if(self::$ErrorView){
                self::$Errors[]=$error;
                self::$Error=$error;
        }
        
        if($error != "") return '';
        
        return self::$Error;
    } 
    
     /**
     *  Выполнение метода интернет сервиса
     * 
     * @param   string  $methodName  Id площадка
     * @param   array $attributes  array Attrubtes
     * @return  array objects From Methods request 
    */
    private static function Call_Get($methodName, $attributes = array()){
        
        if(is_null(self::$Client))
            return array();
        
        
        //$data = self::$Client->call($methodName,$attributes,FALSE);         
        //prnt($data,'Call_Get','<22>');
        $error='';
        try {
            $data = self::$Client->call($methodName,$attributes,FALSE)->recive('',$methodName,$attributes);         
        } catch (Exception $ex) {
            //$error = $methodName.'('.  join(',', $attributes).')toRecive:';
            $error .= $ex->getMessage();
                
        } 
        
        //$data = self::$Client->call($methodName,$attributes,FALSE)->recive('',$methodName,$attributes);         
        
        //$response = self::$Client->call($methodName,$attributes,FALSE);
        //$data = self::$Client->recive($response,$methodName,$attributes);
        /* Вытаскивание ошибки и времени ответа */
        
        
        self::$ErrorId = (int)$data->ResponseResult->Code;
        
        if(self::$ErrorView){
                self::$Errors[]=$error;
                self::$Error=$error;
        
            $RCode = (int)$data->ResponseResult->Code;
            $RDateTime = toStr($data->ResponseResult->DateTime); // new DateTime( $data->ResponseResult->DateTime);
            $RDesc = $data->ResponseResult->Code;
        
            
            
            switch ($RCode){
                case 0: $RDesc = 'успешное действие; ';break;
                case 1: $RDesc = 'ошибка интерфейса, неверный формат данных; ';break;
                case 2: $RDesc = 'ошибка авторизации; ';break;
                
                case 3: $RDesc = 'предложение недоступно (закрыто или удалено); ';break;
                case 4: $RDesc = 'агент недоступен (удален, забанен или отключен); ';break;
                case 5: $RDesc = 'место недоступно (заказано или удалено); ';break;
                case 6: $RDesc = 'ошибка удаления заказа (заказ не существует или чужой); ';break;
            
                //case 6: $RDesc = '';break;
            } 
            
            if($RCode){
                self::$Error = " $methodName (): errId:$RCode,errDateTime:$RDateTime, errDesc:$RDesc <br/>";
                $err = prnt(self::$Error,"$methodName:$RCode",'<-Error-><br>');
                file_put_contents (__DIR__. '/_log.txt'," \n\r $err \n\r ", FILE_APPEND );
            }
            
            
            self::$Errors[] = ['Code'=> $RCode,'DateTime'=>$RDateTime,'Desc'=>$RDesc];
        }
        //prnt($data->ResponseResult,'Call_Get','<-Error->');
        //prnt($data,'Call_Get','<22>');
        
        return $data;
    }        

    /**
     *  Получить список площадок
     * 
     * @return  array objects Places площадок (Name,PlaceId) 
    */
    public static function Call_GetPlaceList( $IsArray = TRUE){
        
        if(is_null(self::$Client))
            return array();
        
        $xmlData = self::Call_Get('GetPlaceList');
        
        if($xmlData->ResponseData->ResponseDataObject->count()==0)
            return array(); 
        //$places = $xmlData->ResponseData->ResponseDataObject->{"ResponseDataObject"};//->{"Place"}
        //$places = $xmlData->ResponseData->ResponseDataObject->{"Place"};//
        $places = $xmlData->ResponseData->ResponseDataObject->Place ;//
        
        $pls=array();
        //prnt($places,'Call_GetPlaceList','< -*- >');
        foreach ($places as $k=>$pl)
            $pls[(int)toStr($pl->Id)] =  ['Id'=>toStr($pl->Id),'Name'=>toStr($pl->Name)];
            //$pls[] =  ['Id'=>$pl->Id->__toString(),'Name'=>$pl->Name->__toString()];
        
        //prnt($pls);
        
        if($IsArray == FALSE){
            foreach ($pls as $id => $pl)
                $pls[$id] = (object)$pl;
        }
        return $pls; //return array Places( Name, Id )
    }
    
    /**
     *  Получить список залов площадки 
     *
     * @param   int  $PlaceId  Id площадка
     * @return  array objects Stages (StageName,PlaceId,StageId )
     */
    public static function Call_GetStageListByPlaceId($PlaceId, $IsArray = TRUE){
        
        if(is_null(self::$Client))
            return array();
        
                
        $xmlData =  self::Call_Get('GetStageListByPlaceId',array($PlaceId));
        
        
        if($xmlData->ResponseData->ResponseDataObject->count()==0)
            return array();   
        //prnt($xmlData); 
        $stages = $xmlData->ResponseData->ResponseDataObject->Stage ;//

        //prnt($xmlData->ResponseData->ResponseDataObject->count(),"CoUnT:"); 
        //prnt($xmlData->ResponseData->ResponseDataObject); 
        $stgs=array();  
        $i='';
        try {
            foreach ($stages as $o){
              $i=$o;
//            if(!isset($o->Id) || empty($o->Id->__toString())){
//                throw new Exception(print_r($o,true));
//                continue;
//            }
               $stgs[(int)toStr($o->Id)] =  [
                'PlaceId'=>toStr($o->PlaceId),
                'Name'=>toStr($o->Name),
                'Address'=>toStr($o->Address),
                'Id'=>toStr($o->Id)];
            }
        
        
         
        
        } catch (Exception $ex) {
            self::$Error =     $ex->getMessage();
            self::$Errors[]=   $ex->getMessage();
            echo "<pre>Errors: ".ptrint_r($i,true)." $PlaceId - $name<br>".$ex->getMessage();       echo "  *</pre>";//print_r($PlaceId); 
            echo "<pre>Errors: ".ptrint_r(self::$Errors,true)." $PlaceId - $name<br>".$ex->getMessage();       echo "  *</pre>";//print_r($PlaceId); 
        }
//        
        //prnt($stgs);
        
        if($IsArray == FALSE){
            foreach ($stgs as $id => $stg)
                $stgs[$id] = (object)$stg;
        }
        return $stgs; //return array Stages(PlaceId, Name, Address, Id )
    }
    
    
    
    /** 
     * Получить список секторов зала 
     * 
     * @param  int $StageId    
     * @return array objects Sectors (SectorName,StageId,SectorId)
     */
    public static function Call_GetSectorListByStageId    ($StageId, $IsArray = TRUE){ 
        
        if(is_null(self::$Client))
            return array();
        
        $xmlData =  self::Call_Get('GetSectorListByStageId',     array($StageId));
        
        if($xmlData->ResponseData->ResponseDataObject->count()==0)
            return array();         
        //prnt($xmlData); 
        //prnt($xmlData->ResponseData->ResponseDataObject,'xml'); 
        $Sectors = $xmlData->ResponseData->ResponseDataObject->Sector ;// ->Sector
        
        $sctrs=array();  
        foreach ($Sectors as $k=>$o)
            $sctrs[(int)toStr($o->Id)] = [
                'StageId'=>toStr($o->StageId),
                'Name'=>toStr($o->Name),
                'Id'=>toStr($o->Id)];
//
        //prnt($sctrs,'obj');
        if($IsArray == FALSE){
            foreach ($sctrs as $id => $sctr)
                $sctrs[$id] = (object)$sctr;
        }
        return $sctrs; //return array Sectors(StageId, Name, Id) 
    }
    
    /**   
     *   Получить список репертуара для зала 
     * 
     * @param  int $StageId    
     * @return array objects Repertoiries (RepertorieName,StageId,RepertorieId)
     */     
    public static function Call_GetRepertoireListByStageId($StageId, $IsArray = TRUE){ 
        
        if(is_null(self::$Client))
            return array();
        
        $xmlData = self::Call_Get('GetRepertoireListByStageId', array($StageId));        
         
        if($xmlData->ResponseData->ResponseDataObject->count()==0)
            return array(); 
        //toLog($xmlData);
        //prnt($xmlData); 
        //prnt($xmlData->ResponseData->ResponseDataObject,'xml'); //->Repertoire
        $Repertoires = $xmlData->ResponseData->ResponseDataObject->Repertoire ;// ->Sector
        
        $rprtrs=array();
        foreach ($Repertoires as $k=>$o){
            $CategoryIds = array();
            foreach ($o->CategoryIdList->Item as $k => $item)
                $CategoryIds[]=  toStr($item);//->__toString(); 
            
            $rprtrs[(int)toStr($o->Id)] = [
                'StageId'=>toStr($o->StageId),
                'Name'=>toStr($o->Name),
                'CategoryIdList'=>$CategoryIds,
                'Id'=>toStr($o->Id)];
        }
        if($IsArray == FALSE){
            foreach ($rprtrs as $id => $repertoire)
                $rprtrs[$id] = (object)$repertoire;
        }
        //prnt($sctrs,'obj');
        
        return $rprtrs; //return array Repertories(StageId, Name,CategoryIdList, Id)
    }
    
    /**  
     *   Получить список агентов системы 
     *    
     * @return array objects Agents (AgentName,CompanyName,Email,Phone,Code,AgentId)
     */     
    public static function Call_GetAgentList( $IsArray = TRUE){ 
        
        if(is_null(self::$Client))
            return array();
        
        $xmlData =  self::Call_Get('GetAgentList',array());
                
         
        if($xmlData->ResponseData->ResponseDataObject->count()==0)
            return array(); 
        //prnt($xmlData); 
        //prnt($xmlData->ResponseData->ResponseDataObject,'xml'); //->Repertoire
        $Agents = $xmlData->ResponseData->ResponseDataObject->Agent ;// ->Sector
        
        $agnts=array();  
        foreach ($Agents as $k=>$o){
//            $CategoryIds = array();
//            foreach ($o->CategoryIdList->Item as $k => $item){
//                $CategoryIds[]=$item->__toString();//->__toString();
//            }
            
            $agnts[(int)toStr($o->Id)] = [
                //'StageId'=>$o->StageId->__toString(),
                'Name'          => toStr($o->Name),
                'CompanyName'   => toStr($o->CompanyName),
                'Email'         => toStr( $o->Email),
                'Phone'         => toStr($o->Phone),
                'Code'          => toStr($o->Code),
                //'CategoryIdList'=>$CategoryIds,
                'Id'            => toStr($o->Id)];
        }
//
        //prnt($agnts,'obj');
        
        if($IsArray == FALSE){
            foreach ($agnts as $id => $agnt)
                $agnts[$id] = (object)$agnt;
        }
        return $agnts; //return array Agents(Name,CompanyName, Email, Phone, Code, Id)
    }
    
    /**   
     *   Получить список предложений агентов для мероприятия 
     * 
     * @param  int $RepertorieId   Repertorie Id 
     * @return array objects  Offers (SectorId, Row, SeatList, NominalPrice, AgentPrice, EventDateTime, RepertoreId, AgentId, ETicket, OfferId)
     */      
    public static function Call_GetOfferListByRepertoireId($RepertorieId, $IsArray = TRUE){ 
        
        if(is_null(self::$Client))
            return array();
        
        $xmlData = self::Call_Get('GetOfferListByRepertoireId', array($RepertorieId));
                
        
        
         
        if($xmlData->ResponseData->ResponseDataObject->count()==0)
            return array(); 
//        prnt(self::$ErrorId); 
//        prnt(self::$Error); 
        //prnt($xmlData); 
//        prnt($xmlData->ResponseData->ResponseDataObject,'xml:'.$RepertorieId); //->Repertoire
        $Offers = $xmlData->ResponseData->ResponseDataObject->Offer ;// ->Sector
        
        //prnt($RepertorieId,' RepertorieId: ');
        //prnt($Offers,'obj');
        $offrs=array();
        foreach ($Offers as $k=>$o){
            $Seats = array();
            foreach ($o->SeatList->Item as $k => $item){//
                $Seats[]=toStr($item);//->__toString();
            }
            
            $offrs[(int)toStr($o->Id)] = [
                'SectorId'      => toStr($o->SectorId),
                'Row'           => toStr($o->Row),
                'SeatList'      => $Seats,//$o->SeatList->Item->count(),
                'NominalPrice'  => toStr($o->NominalPrice),
                'AgentPrice'    => toStr($o->AgentPrice),
                'EventDateTime' => toStr($o->EventDateTime), 
                'RepertoireId'  => toStr($o->RepertoireId),
                'AgentId'       => toStr($o->AgentId),
                'ETicket'       => toStr($o->ETicket),
                //'CategoryIdList'=>$CategoryIds,
                'Id'            => toStr($o->Id)];
            
            
        }
        if($IsArray == FALSE){
            foreach ($offrs as $id => $offer)
                $offrs[$id] = (object)$offer;
        }
        //prnt($offrs,'obj');
        
        
        return $offrs; //return array Offers(SectorId,Row,SeatList(id),NominalPrice,AgentPrice,EventDateTime, RepertoireId, AgentId, ETicket, Id)
    }
    
    /** 
     *   Получить предложение 
     * 
     * @param  int $OfferId    
     * @return object Offer (SectorId,Row,SeatList,NominalPrice,AgentPrice,EventDateTime,RepertoireId,AgentId,ETicket,OfferId)
     */     
    public static function Call_GetOfferById($OfferId){ 
        
        if(is_null(self::$Client))
            return array();
        
        $xmlData = self::Call_Get('GetOfferById',               array($OfferId));
        
         
        if($xmlData->ResponseData->ResponseDataObject->count()==0)
            return array(); 
        //prnt(self::$ErrorId); 
        //prnt(self::$Error); 
        //prnt($xmlData); 
        //prnt($xmlData->ResponseData->ResponseDataObject,'xml'); //->Repertoire
        $Offers = $xmlData->ResponseData->ResponseDataObject->Offer ;// ->Sector
        
        //prnt($Offers,'obj');
        $offrs=array();
        foreach ($Offers as $k=>$o){
            $Seats = array();
            foreach ($o->SeatList->Item as $k => $item){//
                $Seats[]=toStr($item);//->__toString();
            }
            
            $offrs[(int)toStr($o->Id)] = [
                'SectorId'      => toStr($o->SectorId),
                'Row'           => toStr($o->Row),
                'SeatList'      => $Seats,//$o->SeatList->Item->count(),
                'NominalPrice'  => toStr($o->NominalPrice),
                'AgentPrice'    => toStr($o->AgentPrice),
                'EventDateTime' => toStr($o->EventDateTime), 
                'RepertoireId'  => toStr($o->RepertoireId),
                'AgentId'       => toStr($o->AgentId),
                'ETicket'       => toStr($o->ETicket),
                //'CategoryIdList'=>$CategoryIds,
                'Id'            => toStr($o->Id)];
        }

        //prnt($offrs,'obj');
        
        return $offrs; //return array Offer(SectorId,Row,SeatList(id),NominalPrice,AgentPrice,EventDateTime, RepertoireId, AgentId, ETicket, Id)
    }
    
    /** 
     *   Получить(загрузка) список предложений агентов для события  
     * 
     * @param  int $RepertoireId
     * @param  int $EventDateTime
     * @return array objects Offers (SectorId,Row,SeatList,NominalPrice,AgentPrice,EventDateTime,RepertoireId,AgentId,ETicket,OfferId)
     */     
    public static function Call_GetOfferListByEventInfo($RepertoireId,$EventDateTime, $IsArray = TRUE){ 
        
        if(is_null(self::$Client))
            return array();
        
        $xmlData = self::Call_Get('GetOfferListByEventInfo',    array($RepertoireId,$EventDateTime));
        
         
        if($xmlData->ResponseData->ResponseDataObject->count()==0)
            return array(); 
        //prnt(self::$ErrorId); 
        //prnt(self::$Error); 
        //prnt($xmlData); 
        //prnt($xmlData->ResponseData->ResponseDataObject,'xml'); //->Repertoire
        $Offers = $xmlData->ResponseData->ResponseDataObject->Offer ;// ->Sector
        
        //prnt($Offers,'obj');
        $offrs=array();
        foreach ($Offers as $k=>$o){
            $Seats = array();
            foreach ($o->SeatList->Item as $k => $item){//
                $Seats[]=toStr($item);//->__toString();
            }
            
            $offrs[(int)toStr($o->Id)] = [
                'SectorId'      => toStr($o->SectorId),
                'Row'           => toStr($o->Row),
                'SeatList'      => $Seats,//$o->SeatList->Item->count(),
                'NominalPrice'  => toStr($o->NominalPrice),
                'AgentPrice'    => toStr($o->AgentPrice),
                'EventDateTime' => toStr($o->EventDateTime), 
                'RepertoireId'  => toStr($o->RepertoireId),
                'AgentId'       => toStr($o->AgentId),
                'ETicket'       => toStr($o->ETicket),
                //'CategoryIdList'=>$CategoryIds,
                'Id'            => toStr($o->Id)];
        }
        if($IsArray == FALSE){
            foreach ($offrs as $id => $offer)
                $offrs[$id] = (object)$offer;
        }
        //prnt($offrs,'obj');
        
        return $offrs; //return array Offers(SectorId,Row,SeatList(id),NominalPrice,AgentPrice,EventDateTime, RepertoireId, AgentId, ETicket, Id)
    }
    
    /** 
     *   Получить Id предложения по информации о месте
     * 
     * @param   int $RepertoireId	
     * @param   int $EventDateTime	
     * @param   int $SectorId		
     * @param   int $Row				
     * @param   int $Seat			   
     * 
     * @return int Offer OfferId 
     */     
    public static function Call_GetOfferIdBySeatInfo($RepertoireId, $EventDateTime, $SectorId, $Row, $Seat){ 
        
        if(is_null(self::$Client))
            return array();
        
        $xmlData = self::Call_Get('GetOfferIdBySeatInfo',array($RepertoireId, $EventDateTime, $SectorId, $Row, $Seat));        
        
         
        if($xmlData->ResponseData->ResponseDataObject->count()==0)
            return array(); 
        //prnt(self::$ErrorId); 
        //prnt(self::$Error); 
        //prnt($xmlData); 
        //prnt($xmlData->ResponseData->ResponseDataObject,'xml'); //->Repertoire
        $OfferId = $xmlData->ResponseData->ResponseDataObject->OfferId ;// ->Sector
        
        //prnt($Offers,'obj'); 
        return toStr($OfferId);//return int OfferId
    }
    
    /**  
     *   Сделать заказ билетов в предложении 
     * 
     * @param   int $OfferId  
     * @param   array $SeatList
     * @return object Order SeatList,Price,Comment,DateTime,ClientId,AgentId,OfferId,OrdrId
     * 0 - выполнено; 
     * 3 – предложение недоступно (закрыто или удалено); 
     * 4 – агент недоступен (удален, забанен или отключен); 
     * 5 – место недоступно (заказано или удалено);  
     */     
    public static function CallMod_MakeOrder                 ( $OfferId, array $SeatList){ 
        
        if(is_null(self::$Client))
            return array();
        
        
        $Seats = '';
        foreach ($SeatList as $seat)
            $Seats .= "<Item>$seat</Item> ";
        
        $xmlData = self::Call_Get('MakeOrder',                  array($OfferId,$Seats));
        
        
         
        if($xmlData->ResponseData->ResponseDataObject->count()==0)
            return array(); 
        //prnt(self::$ErrorId); 
        //prnt(self::$Error); 
        //prnt($xmlData); 
        //prnt($xmlData->ResponseData->ResponseDataObject,'xml'); //->Repertoire
        $Orders = $xmlData->ResponseData->ResponseDataObject->Order ;// ->Sector
        
        //prnt($Offers,'obj');
        $ordrs=array();
        foreach ($Orders as $k=>$o){
            $Seats = array();
            foreach ($o->SeatList->Item as $k => $item){//
                $Seats[]=toStr($item);//->__toString();
            }
            
            $ordrs[(int)toStr($o->Id)] = [
                'SeatList' => $Seats,//$o->SeatList->Item->count(),
                'Price'    => toStr($o->Price),
                'Comment'  => toStr($o->Comment),
                'DateTime' => new DateTime( toStr($o->DateTime)),
                'ClientId' => (int)toStr($o->ClientId),
                'AgentId'  => (int)toStr($o->AgentId),
                'OfferId'  => (int)toStr($o->OfferId),
                'Id'       => (int)toStr($o->Id)];
        }

        //prnt($ordrs,'obj');
        
        return $ordrs; //return array Offers(SectorId,Row,SeatList(id),NominalPrice,AgentPrice,EventDateTime, RepertoireId, AgentId, ETicket, Id)
    }
    
    /**  
     *  Отменить заказ билетов 
     * 
     * @param   int $OrderId    
     * @return bool Success run method 
     * 0 - выполнено; 
     * 6 - ошибка удаления заказа (заказ не существует или чужой);  
     */     
    public static function CallMod_CancelOrder               ($OrderId){ 
        
        if(is_null(self::$Client))
            return array();
        
        $xmlData = self::Call_Get('CancelOrder',                array($OrderId));
        
        
        $RCode = (int)$xmlData->ResponseResult->Code; 
        
        //prnt($xmlData,'obj'); 
        //prnt(self::$ErrorId); 
        if($RCode==0)
            return TRUE;
        
        return FALSE;//return bool Success
    }
    
    
     /**  
     *  Получить описание метода
     * 
     * @param  string Name method
     * @return string Descrtiption method   
     * @see http://php.net/manual/en/class.reflectionmethod.php
     * @see https://habrahabr.ru/post/139649/
     */    
    public static function GetDocComment($MethodName,$tag=''){//'@DocTag'
        
        $getDocComment = function  ($str, $tag = '') { 
                if (empty($tag)) {    
                    $str = str_replace([' * ','/**','*/'], '<br/>', $str);
                    return $str;  
                }

                $matches = array(); 
                preg_match("/".$tag.":(.*)(\\r\\n|\\r|\\n)/U", $str, $matches); 

                if (isset($matches[1]))     
                    return trim($matches[1]);    

                return ''; 
            };


        $method = new ReflectionMethod('SoapClientZriteli', $MethodName); 
        return $getDocComment($method->getDocComment(), $tag); //'@DocTag'
    }//http://php.net/manual/en/class.reflectionmethod.php
    
    public static function GetDocParams($MethodName,$tag=''){//'@DocTag'
        
        $getDocComment = function  ($str, $tag = '') { 
                if (empty($tag)) {    
                    $str = str_replace([' * ','/**','*/'], '<br/>', $str);
                    return  explode ('@param', trim(explode('@return', $str, 1))) ;    
                }

                $matches = array(); 
                preg_match("/".$tag.":(.*)(\\r\\n|\\r|\\n)/U", $str, $matches); 

                if (!isset($matches[1]))     
                    return ''; 
                
                $s = trim($matches[1]);
                $s = explode('@return', $s, 1) ;
                return explode ('<br/>', trim($s)) ;    

                
            };


        $method = new ReflectionMethod('SoapClientZriteli', $MethodName); 
        return $getDocComment($method->getDocComment(), $tag); //'@DocTag'
    }//http://php.net/manual/en/class.reflectionmethod.php
    
}