<?php
error_reporting( E_ALL );
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$rootpath = __DIR__. "/../../../../";
$rootpath = realpath($rootpath);
define('JPATH_BASE', $rootpath);

//$fileconfig = JPATH_BASE. '/configuration.php';
//if(file_exists($fileconfig))
//    require_once $fileconfig;
//else 
//    exit ();


function toPrnt($obj, $head = "",$separete='', $count = 1, $show = TRUE){
    $pref = '';
    
//    if(is_string($obj) && class_exists('JFactory'))        
//        $obj = str_replace('#__',JFactory::getDbo()->getPrefix(),$obj);
    
    if(is_array($obj))        {
        $pref = ' Count:'.count($obj);
        if($count>0)
            $obj = array_slice($obj, 0,$count, TRUE);
    }
    $print  = ($separete)?"<br/>$separete":"";
//    $print .= ($head)?"<br/>$head":"";
    $print .= "<pre>$head $pref ".print_r($obj,true)."</pre>";
    $print .= $separete;
    if($show)
        echo $print;
    
    return $print;
}


define('_JEXEC', 1);
require_once JPATH_BASE . '/includes/defines.php';
require_once JPATH_BASE . '/includes/framework.php';



//echo ("Готово!");echo JPATH_BASE . '/includes/defines.php';exit("Готово!");


define('JPATH_PLATFORM', JPATH_BASE . '/libraries');
require_once JPATH_PLATFORM.'/import.php';

jimport('joomla.environment.uri');
jimport('joomla.utilities.date');

$select = "SELECT params FROM #__extensions WHERE `element` = 'PlaceBilet' ; ";
$str_params = JFactory::getDbo()->setQuery($select)->loadResult();

toPrnt(JDate::getInstance()->modify('+ 3 hour')->toSql());

$registry = new \Joomla\Registry\Registry($str_params);
//$registry->set('dtUpdateProducts', JDate::getInstance()->modify('+ 3 hour')->toSql());
//$str_params = $registry->toString();  
//$update = "UPDATE #__extensions SET params = $str_params WHERE element = 'PlaceBilet' ; ";
//JFactory::getDbo()->setQuery($update)->execute();



if(file_exists(JPATH_PLUGINS.'/jshopping/PlaceBilet/Addons/Zriteli.php'))
        require_once (JPATH_PLUGINS.'/jshopping/PlaceBilet/Addons/Zriteli.php');


$params = $registry ;
Zriteli::Instance($params);

toPrnt(Zriteli::$dtUpdateProducts,'Date Update last products: ');


$count = Zriteli::LoadAllProducts();

echo "New $count bilets.";
        
//prnt($str_params); 
//toPrnt($registry);
exit("Готово!");
//echo ("Готово!");
//exit("Готово!");

//index.php?option=com_blog&view=item&task=getAjaxData&format=raw

//
//
//$fileFactory = __DIR__. "/../../../../includes/joomla/defines.php";
//$fileFactory = __DIR__. "/../../../../includes/joomla/framework.php";
//
//
////$fileFactory = __DIR__. "/../../../../libraries/joomla/factory.php";
////$fileFactory = __DIR__. "/../../../../libraries/vendor/joomla/registry/src/Registry.php";
////C:\Downloads\Joomla\libraries\vendor\joomla\compat\src\JsonSerializable.php_ini_loaded_file()
//////namespace Joomla\Registry;
//
//
//$conf = new JConfig();
//$bd_link = null;
//
//$bd_connect = function ()use(&$bd_link, &$conf){
//    $db_name = $conf->db;
//    $db_type = $conf->dbtype;
//    $db_host = $conf->host;
//    $db_user = $conf->user;
//    $db_password = $conf->password;
//    $db_dbprefix = $conf->db;
//    
//    /** Пароли базы 
//	$db = 'cirkbilet_teat';
//	$dbtype = 'mysqli';
//	$host = 'localhost';
//	$user = 'cirkbilet_teat';
//	$password = 'KCcj45yK';
//	$dbprefix = 'pac0x_';
//*/
//    $bd_link = mysqli_connect( $db_host, $db_user, $db_password, $db_dbprefix); 
//    
//    if (!$link) { 
//        printf("Невозможно подключиться к базе данных. Код ошибки: %s\n", mysqli_connect_error()); 
//        exit ("Невозможно подключиться к базе данных. Код ошибки: ". mysqli_connect_error().'\n'); 
//    }
//    
//    return $bd_link;
//};
//
//
// $bd_query = function ($query = '',$type='')use (&$bd_link){
//    if(!$query)         return '';
//    
//    $result = mysqli_query($link, $query); 
//    if(!$result) return ''; 
//            
//    $result = mysql_result ($result);
////    $arr= ['mysql_result',''];
//            
////    /* Выборка результатов запроса */ 
////    while( $row = mysqli_fetch_assoc($result) ){ 
////        printf("%s (%s)\n", $row['Name'], $row['Population']);
////    }
//
//    /* Освобождаем используемую память */ 
//    mysqli_free_result($result); 
//    return $result;
// };
//
// 
//$select = "SELECT params FROM pac0x_extensions WHERE `element` = 'PlaceBilet' ; ";
//$params = $bd_query($select);
//
//
//JFactory::getDbo();