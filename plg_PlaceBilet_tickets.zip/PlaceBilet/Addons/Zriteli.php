<?php

    defined( '_JEXEC' ) or die( 'Restricted access' );
//error_reporting( E_ALL );


require_once (JPATH_PLUGINS.'/jshopping/PlaceBilet/Addons/SoapClient.php');
//echo "<br>?HELP!! <br>";
class Zriteli{
    /**
     * Проценты наценки
     * @var int 
     */
    public static $Jackpot;
    /**
     * Сумма округления рублей
     * @var int 
     */
    public static $CostCurrency;
    
    /**
     * Параметры плагина
     * @var JObject 
     */
    public static $Params;
    /**
     * Массив ID площадок
     * @var array teatrId, stageId, category_id
     */
    public static $StagePlaces=array();
    /**
     * Список репертуаров
     * @var array 
     */
    public static $Repertoires=array();
    /**
     * Список предложений
     * @var array
     */
    public static $Offers=array();
    
    /**
     * ID категории с продуктами
     */
    public static $CatCategoriesProducts = -1;
    /**
     * ID категории с площаками
     */
    public static $CatCategoriesStages = -1;
    
    
    /** 
     * ID пользователя сервиса ЗРИТЕЛИ
     * @var int 
     */   
    public static $UserId;
    /** 
     * Хэш пользователя сервиса ЗРИТЕЛИ
     * @var string 
     */   
    public static $UserHash;
    
    
    /** 
     * Включение модуля загрузки данных из ЗРИТЕЛИ
     * @var bool 
     */   
    public static $enabled=FALSE;
    /** 
     * Разрешение отображение ошибок
     * @var bool 
     */   
    public static $ErrorView=FALSE;
    
    /** Доработат !!!
     * Удалять не существующие категории, иначе публикацию снимать.
     * @var bool 
     */
    public static $delete_NoExistCategory = TRUE;
    
    /** 
     * время последнего обновления продуктов
     * @var DateTime 
     */   
    public static $dtUpdateProducts='';
    /** 
     * время последнего обновления предложений
     * @var DateTime 
     */   
    public static $dtUpdateOffers='';
    
    /** 
     * разрешение на обноление Представлений
     * @var bool 
     */    
//    public static $UpdateProducts=FALSE;
    /** 
     * разрешение на обноление Предложений
     * @var bool 
     */    
    public static $UpdateOffers=FALSE;
    /** 
     * разрешение на обноление Репертуаров
     * @var bool 
     */    
    public static $UpdateRepertoiries=FALSE;


    public static function Instance( $paramsPlugin, $ErrorView=FALSE){//JRegistry JObject
        
        if(static::$Params instanceof  JRegistry)
            return;
        static::$UpdateOffers = TRUE;
        static::$Params = $paramsPlugin;
            static::$Jackpot = (int)$paramsPlugin->get('jackpot', 0);
            static::$CostCurrency = (int)$paramsPlugin->get('costCarrency', '0-0');
            static::$UserId = (int)$paramsPlugin->get('UserId', 111);
            static::$UserHash = $paramsPlugin->get('Hash', '698d51a19d8a121ce581499d7b701668');
        if(count(static::$StagePlaces)==0){
            static::$StagePlaces = $paramsPlugin->get('StagePlaces', []);
            foreach (static::$StagePlaces as $Id => $stage){
                list($stageId,$teatrId) = explode ('-',$stage); 
                static::$StagePlaces[(int)$stageId] = (object)['TeatrId'=>$teatrId,'PlaceId'=>$teatrId,'StageId'=>$stageId,'category_id'=>0, 'Name'=>'', 'Teatr'=>'', 'Title'=>''];
                unset(static::$StagePlaces[(int)$Id]);
            }
        }
        
//        prnt(static::$StagePlaces, 'static::$StagePlaces: '.count(static::$StagePlaces));        return;
        static::$enabled = TRUE;
        static::$ErrorView = $ErrorView;
//        CategoriesProducts     CategoriesStages
        static::$CatCategoriesProducts = (int)$paramsPlugin->get('CategoriesProducts', -1); // ID категории с продуктами
        static::$CatCategoriesStages = (int)$paramsPlugin->get('CategoriesStages', -1);// ID категории с площаками
        
        static::$dtUpdateProducts = new DateTime($paramsPlugin->get('dtUpdateProducts', 'now'));
        static::$dtUpdateProducts -> modify('+1 day');
        static::$dtUpdateOffers = new DateTime($paramsPlugin->get('dtUpdateOffers', 'now'));
        
        static::$delete_NoExistCategory = (bool)$paramsPlugin->get('delete_NoExistCategory', TRUE);
        
//        static::$UpdateOffers = static::$enabled && static::$dtUpdateProducts < new DateTime();
        static::$UpdateRepertoiries = static::$enabled && static::$dtUpdateProducts < new DateTime();
        
        SoapClientZriteli::getInstance(static::$UserId,static::$UserHash, $ErrorView);
        
        //prnt('ZriteliInstance: '.self::$UserId.' - '.self::$UserHash.'; '); 
                    
        //prnt('ZriteliInstance: '.SoapClientZriteli::$UserId.' - '.SoapClientZriteli::$UserHash.'; ->'.self::$UpdateProducts);
    }
    /**
     * Обновление даты "последней даты обновления" продуктов в базе.
     * Занесение параметров с новой датой в параметры плагина.
     * @param JRegistry $paramsPlugin Парамеры плагина
     */
    public static function ParamsSave(JRegistry $paramsPlugin = NULL){
        
        if(is_null($paramsPlugin))
            $paramsPlugin = static::$Params;
        
        $paramsPlugin->set('dtUpdateProducts', JDate::getInstance()->modify('+3 hour')->toSql());
        
        $params = $paramsPlugin->toString(); 
        //$params = JFactory::getDBO()->quote($params);
        
        $query = " UPDATE #__extensions SET params = '$params' WHERE element='PlaceBilet'; "; 
        //prnt($query);        return;
        JFactory::getDBO()->setQuery($query)->execute();
    }
    static function DisabledUpdateProductsAndRepertoires(){
        //self::$Params =$paramsPlugin;
        
        $date = JDate::getInstance()->modify('+3 hour')->toSql();
//        prnt($date,' $date' );
        static::$Params->set("dtUpdateProducts", $date);
        $params = self::$Params->toString();
        
        
        //$db = JFactory::getDbo(); 
        //$params = $db->quote($params);
        
//        self::$dtUpdateProducts = new DateTime($paramsPlugin->get('dtUpdateProducts', 'now'));
       
        //$query = " SELECT params FROM #__extensions WHERE element='PlaceBilet'; ";
        $query = " UPDATE #__extensions SET params = '$params' WHERE element='PlaceBilet'; ";
        JFactory::getDBO()->setQuery($query)->execute();

//        prnt($query,' $query' );
//        
//        $params = json_decode($params);
//        $this->params = new JObject();
//        $this->params->setProperties($params);
                
//        $this->params = JRegistry::getInstance('PlaceBilet'); 
//        $this->params->loadString($params);
    }


    static $Products = array();
    /*
     * Продукты сформировланы из репертуаров
     */
    static $Prods = array();

    
    public static function LoadAllProducts(){

//   prnt(static::$StagePlaces, 'static::$StagePlaces: x'.count(static::$StagePlaces)); 
        
        //prnt('LoadAllProducts: '.self::$UserId.' - '.self::$UserHash.'; ->'.self::$UpdateProducts); 
        
        
//   prnt(array_slice(static::$StagePlaces, 0,3, TRUE), ' \static::$StagePlaces V Count:'.count(static::$StagePlaces));
        
        if(!static::$UpdateRepertoiries)
            return 0;
        
        //prnt('Обновление!!!');
        //prnt('LoadAllProducts: '.self::$UserId.' - '.self::$UserHash.'; ->'.self::$UpdateProducts); 
        //prnt('LoadAllProducts: '.SoapClientZriteli::$UserId.' - '.SoapClientZriteli::$UserHash.'; ->'.self::$UpdateProducts); 
        
        //static::$StagePlaces = static::UpdateLoadStages();
         
        //prnt($log); 
        //prnt(static::$StagePlaces," \$StagePlaces Count:".count(static::$StagePlaces)); 
        
        
        //******************************************* Закачка мероприятий с Зрители
        //$Repertoires = array();
        foreach (static::$StagePlaces as $stageId => $stage){
            $Rprtrs = SoapClientZriteli::Call_GetRepertoireListByStageId($stageId, FALSE);
            // Получение репертуара  (StageId, Name, CategoryIdList, Id)
            foreach ($Rprtrs as $id=>$rprt)
                $Rprtrs[$id]->StageId=$stageId;
//            prnt($Rprtrs); 
            self::$Repertoires += $Rprtrs;
        }
        
        //static::$StagePlaces[(int)$stageId] = (object)['TeatrId'=>$teatrId,'PlaceId'=>$teatrId,'StageId'=>$stageId,'category_id'=>0, 'Name'=>'', 'Teatr'=>'', 'Title'=>''];
        //$Offers = array();
        foreach (static::$Repertoires as $id => $repertoire){
            //self::$Repertoires[$id] = (object)$repertoire;
            $ffrs = SoapClientZriteli::Call_GetOfferListByRepertoireId($id, FALSE);
            //$ffrs->Repertoire = self::$Repertoires[$id];
            if(count($ffrs)==0){
                unset (static::$Repertoires[$id]);
                continue;
            }
            
            static::$Repertoires[$id]->PlaceId = static::$StagePlaces[$repertoire->StageId]->PlaceId;
            static::$Repertoires[$id]->Teatr = static::$StagePlaces[$repertoire->StageId]->Teatr; 
            
            static::$Repertoires[$id]->category_image = '';
            
            static::$Repertoires[$id]->category_image = '';
            static::$Repertoires[$id]->category_id = 0;
            static::$Repertoires[$id]->description = '';
            static::$Repertoires[$id]->Offers = &$ffrs;
            static::$Offers += $ffrs;
             
            
//        prnt($ffrs, "$ffrs --- \$id:$id ".'  count:'.count($ffrs)); 
            foreach ($ffrs as $id_ffr => $ffr){
                static::$Offers[$id_ffr]->Name = $repertoire->Name;
                static::$Offers[$id_ffr]->description = '';
                static::$Offers[$id_ffr]->product_id = 0;
                  
                //$prod->Offers = $ffrs;
                if(!isset(static::$Products[$repertoire->Name][$ffr->EventDateTime][$repertoire->StageId])){
                    static::$Products[$repertoire->Name][$ffr->EventDateTime][$repertoire->StageId] = new stdClass();
                    static::$Products[$repertoire->Name][$ffr->EventDateTime][$repertoire->StageId]->EventDateTime = $ffr->EventDateTime;
                    static::$Products[$repertoire->Name][$ffr->EventDateTime][$repertoire->StageId]->Name = $repertoire->Name;
                    static::$Products[$repertoire->Name][$ffr->EventDateTime][$repertoire->StageId]->RepertoireId = $id;
                    
                    static::$Products[$repertoire->Name][$ffr->EventDateTime][$repertoire->StageId]->category_id  = 0;
                    static::$Products[$repertoire->Name][$ffr->EventDateTime][$repertoire->StageId]->product_id   = 0;
                    static::$Products[$repertoire->Name][$ffr->EventDateTime][$repertoire->StageId]->StageId   = $repertoire->StageId;
                    static::$Products[$repertoire->Name][$ffr->EventDateTime][$repertoire->StageId]->description  = '';
                    static::$Products[$repertoire->Name][$ffr->EventDateTime][$repertoire->StageId]->image        = '';
                    static::$Products[$repertoire->Name][$ffr->EventDateTime][$repertoire->StageId]->OffersCount  = 0;//count($ffrs);
                    
                    static::$Products[$repertoire->Name][$ffr->EventDateTime][$repertoire->StageId]->Offers[$id_ffr] = $ffr;
                    
                    static::$Repertoires[$id]->Prods[]  = & static::$Products[$repertoire->Name][$ffr->EventDateTime][$repertoire->StageId];
                    static::$Prods[]                    = & static::$Products[$repertoire->Name][$ffr->EventDateTime][$repertoire->StageId];
                }
                //self::$Repertoires[$id]->Products 
            }
            static::$Repertoires[$id]->ProdsCount = count(static::$Repertoires[$id]->Prods);
        }
        
//        prnt(self::$Products, ' self::$Products '.count(self::$Products));
//        prnt(self::$Prods, ' self::$Prods '.count(self::$Prods));
        
        
        $db = JFactory::getDbo(); 
        $name = 'name_'.JFactory::getLanguage()->getTag();
        $short_desc = 'short_description_'.JFactory::getLanguage()->getTag();
        $description = 'description_'.JFactory::getLanguage()->getTag(); 
        
        //******************************************* Добавление в базу мероприятий
        
        // Сортировка репертуаров по имеющимся в базе и неимеющихся
        $RepertoiresCompare     = static::RepertoiresCompare(); 
        $Repertoires_exist      = $RepertoiresCompare->Repertoires_exist;
        $Repertoires_NOexist    = $RepertoiresCompare->Repertoires_NOexist;
        $Repertoires_existUnpublish = $RepertoiresCompare->Repertoires_existUnpublish;
        // prnt($repertoire->Name);
        
        // Категории  - Удаление отсутствующих репертуаров
        if(count($Repertoires_existUnpublish) && static::$delete_NoExistCategory){
            
            $rprtrs = array_column($Repertoires_existUnpublish, 'RepertoireId');
            
            $update = " UPDATE `#__jshopping_categories` SET `category_publish` = 1 WHERE RepertoireId NOT IN (".  join(',', $rprtrs).") AND RepertoireId != 0; "; 
            if(count($rprtrs)>0)
                    JFactory::getDBO()->setQuery($update)->execute();
        }
        
        // Категории  - добавление отсутсвующих Репертуаров в категориии и получение их ID
        if(count($Repertoires_NOexist)>0){
            $CatCategoriesProducts = static::$CatCategoriesProducts;
            if($CatCategoriesProducts > -1){
                $querys = array();
                foreach ($Repertoires_NOexist as $id => $repertoire)
                    $querys[] = " (".$db->quote($repertoire->Name).",$repertoire->Id, $CatCategoriesProducts, 1, 1, 1, NOW(), 12, 2, 1, $repertoire->StageId, $repertoire->PlaceId ) ";//$db->quote($db->escape($repertoire->Name),false)
            
                $query_insert =" INSERT INTO `#__jshopping_categories` "
                    . "(`$name`,RepertoireId,`category_parent_id`,`category_publish`,`category_ordertype`,`ordering`,`category_add_date`,`products_page`,`products_row`,`access`,StageId,PlaceId) "
                    . " VALUES ".  join(', ', $querys)."; "; 
                if(count($querys)>0)
                    JFactory::getDBO()->setQuery($query_insert)->execute();
            }
            // загрузка добавление и опредиление категорий для площадок
            $CatCategoriesStages = static::$CatCategoriesStages;
            if($CatCategoriesStages > -1){
                static::$StagePlaces = static::UpdateLoadStages();
//                prnt(static::$StagePlaces," \$StagePlaces Count:".count(static::$StagePlaces)); 
            }
//            prnt($query);
            
            $RepertoiresCompare     = static::RepertoiresCompare();
            $Repertoires_exist      = $RepertoiresCompare->Repertoires_exist;
            $Repertoires_NOexist    = $RepertoiresCompare->Repertoires_NOexist;
// prnt($repertoire->Name);
        }
    
        //params        {"StageId":950,"category_id":485,"RepertoireId":6172,"OffersId":[981302]}
        
        foreach (static::$Prods as $id_prod=> $prod){
            if($prod->RepertoireId == 0)
                continue;
            static::$Prods[$id_prod]->category_id = $Repertoires_exist[$prod->RepertoireId]->category_id;
            static::$Prods[$id_prod]->image = $Repertoires_exist[$prod->RepertoireId]->category_image;
            static::$Prods[$id_prod]->description = $Repertoires_exist[$prod->RepertoireId]->description;
            static::$Prods[$id_prod]->OffersCount  = count(static::$Prods[$id_prod]->Offers);
        }
//        foreach ($Repertoires_exist as $id_cat => $repertoire){
//            foreach (static::$Prods as $id_prod=> $prod){
//                if($prod->Name == $repertoire->Name){
//                    static::$Prods[$id_prod]->category_id = $repertoire->category_id;
//                    static::$Prods[$id_prod]->image = $repertoire->category_image;
//                    static::$Prods[$id_prod]->description = $repertoire->description;
//                    static::$Prods[$id_prod]->OffersCount  = count(static::$Prods[$id_prod]->Offers);
//                }
//            }
//        }
        
//        prnt(self::$Products, ' self::$Products '.count(self::$Products));
//        prnt(self::$Prods, ' self::$Prods '.count(self::$Prods));
        
        
        
        //**********************************************
//        $cats = array();
//        foreach (self::$Repertoires as $id => $repertoire){
//            $cats[] = $repertoire->category_id;
//        }
//        $query =" SELECT product_id, category_id, product_ordering FROM `#__jshopping_products_to_categories` WHERE category_id IN (".join(", ",$cats).") ORDER BY category_id, product_id, product_ordering; ";
//        $cats_prods = JFactory::getDBO()->setQuery($query)->loadObjectList();
//        
//        $query =" SELECT pc.category_id, product_ordering , p.* "
//                . "FROM `#__jshopping_products_to_categories` pc,`#__jshopping_products` p "
//                . "WHERE pc.product_id=p.product_id AND pc.category_id IN (".join(", ",$cats).") "
//                . "ORDER BY pc.category_id, pc.product_id, pc.product_ordering; ";
//        
//        $query =  "SELECT p1.* "
//                . "FROM `#__jshopping_products` p1, `#__jshopping_products` p2 "
//                . "WHERE p1."
//                . "ORDER BY category_id, product_id, product_ordering; ";
//        
        
//        prnt(self::$Repertoires, ' self::$Repertoires! '.count(self::$Repertoires)); // 0 
        

//        prnt(static::$Prods, ' static::$Prods '.count(static::$Prods)); 
        list($products_exist, $products_NOexist, $products_onlyDB) = static::ProductsCompare(); 
//        $products_onlyDB = $ProductsCompare->products_onlyBD;
    
        // Удаление спектаклей которых уже нет в репертуаре.
        if($products_onlyDB){
             $ids = array_keys($products_onlyDB);
             $delete = " DELETE FROM `#__jshopping_products` WHERE product_id IN ("
                    . join(',', $ids). " ) ; ";
            if($ids)
                JFactory::getDBO()->setQuery($delete)->execute();
            
            $delete = " DELETE p1 FROM pac0x_jshopping_products p1, pac0x_jshopping_products p2
                WHERE p1.RepertoireId = p2.RepertoireId AND p1.date_event = p2.date_event AND p1.product_id > p2.product_id; ";
            JFactory::getDBO()->setQuery($delete)->execute();
            
            $delete = " DELETE FROM `#__jshopping_products_to_categories` WHERE product_id NOT IN (SELECT product_id FROM `#__jshopping_products` ); ";
            JFactory::getDBO()->setQuery($delete)->execute();
            
            $delete = " DELETE FROM `#__jshopping_products_images` WHERE product_id NOT IN ( SELECT p.product_id FROM `#__jshopping_products` AS p ); ";
            JFactory::getDBO()->setQuery($delete)->execute();
        }
//     self::$Offers = 1446      
//        prnt($products_NOexist, ' $products_NOexist '.count($products_NOexist));

        
//        prnt(self::$Products, ' self::$Products '.count(self::$Products));
//        prnt(self::$Prods, ' self::$Prods '.count(self::$Prods));
          
//        prnt($products_NOexist, ' \$products_NOexist '.count($products_NOexist)); // 1472
//        prnt($products_onlyDB, ' \$products_onlyDB '.count($products_onlyDB)); // 1472        184,188
//        prnt($products_exist, ' \$products_exist '.count($products_exist)); // 0
        
    
//prnt("\$products_NOexist-COUNT:".count($products_NOexist). ' - $products_exist-COUNT:'.count($products_exist)); 

        // ДОбавление спектаклей которых нет в базе
        if($products_NOexist){
//            prnt(array_slice($Repertoires_NOexist, 0,2) , " \$Repertoires_NOexist Count:".count($Repertoires_NOexist));
//            prnt(array_slice($products_NOexist, 0,2), " \$products_NOexist Count:".count($products_NOexist));
            
            $CatCategoriesStages = static::$CatCategoriesStages;
            if(count($Repertoires_NOexist)==0 && $CatCategoriesStages > -1){
                $query = " SELECT *, `$name` Name, `$short_desc` short_desc, `$description` description "
                       . " FROM `#__jshopping_categories` WHERE category_parent_id = $CatCategoriesStages; ";
                $cats = JFactory::getDBO()->setQuery($query)->loadObjectList('StageId');//category_id   StageId  
                
                foreach (static::$StagePlaces  as $stageId => $stage){
                    static::$StagePlaces[$stageId]->category_id  = $cats[$stageId]->category_id;
                    static::$StagePlaces[$stageId]->StageCatId  = $cats[$stageId]->category_id;
                    static::$StagePlaces[$stageId]->Name        = $cats[$stageId]->Name;
                    static::$StagePlaces[$stageId]->Address     = $cats[$stageId]->short_desc;
                    static::$StagePlaces[$stageId]->Teatr       = $cats[$stageId]->Name;
                    static::$StagePlaces[$stageId]->Title       = $cats[$stageId]->Name;
                }
                
//                prnt(array_slice(static::$StagePlaces, 0,3, TRUE), ' \static::$StagePlaces F Count:'.count(static::$StagePlaces));
//                static::$StagePlaces = static::UpdateLoadStages();
//                prnt(static::$StagePlaces," \$StagePlaces Count:".count(static::$StagePlaces)); 
            }   
            
            $query = "SELECT * FROM `#__jshopping_products` LIMIT 1; ";
            $first = JFactory::getDBO()->setQuery($query)->loadObject();
            if(is_null($first)) $first = (object)['currency_id'=> 1 , 'add_price_unit_id'=> 1 , 'different_prices'=> 1];
        
            $querys = array();            
            foreach ($products_NOexist as $id => &$product){
//                $product->params['StageCatId'] = $cats[$product->StageId]->category_id;
                $product->params['StageCatId'] = static::$StagePlaces[$product->StageId]->StageCatId;
//                prnt($product->params, ' \$product->params Count:'.count($product->params));
                $querys[] = " ('$product->EventDateTime','".json_encode($product->params)."',".$db->quote($product->image).",NOW(),1,$first->currency_id,$first->add_price_unit_id,$first->different_prices,'default',1,".$db->quote($product->Name).",".$db->quote($product->description).",$product->RepertoireId,$product->StageId) ";//$db->quote($db->escape($repertoire->Name),false)   
            }
            $query_insert =" INSERT INTO `#__jshopping_products` "
                    . "(`date_event`,`params`,`image`,`product_date_added`,`product_publish`,`currency_id`,`add_price_unit_id`,`different_prices`, `product_template`,`access`, `$name`,`$description`,RepertoireId,StageId) VALUES "
                    . join(', ', $querys). "; ";
            if(count($products_NOexist)>0)        JFactory::getDBO()->setQuery($query_insert)->execute();    //{"StageId":950,"category_id":482,"RepertoireId":3738,"OffersId":[986490]}
//            prnt($products_NOexist, ' \$products_NOexist '.count($products_NOexist));
//            prnt($query_insert, ' \$query_insert '.count($products_NOexist));
      
            static::SetCatsToProds($products_NOexist); 
            
            $ProductsCompare = static::ProductsCompare(); 
            $products_exist = $ProductsCompare->products_exist;
            $products_NOexist = $ProductsCompare->products_NOexist; 
//            $products_onlyDB = $ProductsCompare->products_onlyBD;
            //foreach ($products_NOexist )
//            prnt($products_NOexist, ' \$products_NOexist xx');
//            prnt($ProductsCompare->products_exist, ' \$ProductsCompare->products_exist xx');
              
            
            
        }
        
//        if(!PlaceBiletDev){
                //$products_id_bd = array_keys($products_onlyDB);
                static::ProductsDeleteFromDB();
//        }        
 
//prnt("123", ' $count ');        
        static::SetCatsToProds();
        
//prnt("123", ' $count ');      
//            $querys = array();
//            foreach ($prod_cats_NOexist as $id => $prod){
//                $querys[] = " (".$products_exist[$id]->product_id.", ".$products_exist[$id]->category_id.", 1 ) ";
//            }
//            $query_insert =" INSERT INTO `#__jshopping_products_to_categories` "
//                    . "(product_id, category_id, product_ordering) VALUES " .  join(',', $querys)."; ";
////            JFactory::getDBO()->setQuery($query_insert)->execute();
////            prnt($query_insert, ' $query_insert '); 
//-------------------------------
        
//        foreach(self::$Repertoires as $id=>$repertoire){
//             $xx[]= $db->quote($repertoire->Name);
//        }
//        foreach($categories_bd as $id=>$repertoire){
////             $xx[]= $db->quote($repertoire->$name);
//             $xx[$id] = $repertoire->$name;
//        }
//        prnt($xx, ' $xx ');
        
//        prnt( ' $products_NOexist '.count($products_NOexist));
//        prnt( ' $products_exist '.count($products_exist)); 
        
//        prnt($prod_cats_NOexist, ' $prod_cats_NOexist '.count($prod_cats_NOexist));
//        prnt($Repertoires_NOexist, ' $Repertoires_NOexist '.count($Repertoires_NOexist));
//        prnt($Repertoires_exist, ' $Repertoires_exist '.count($Repertoires_exist));
//        prnt($products_NOexist, ' $products_NOexist '.count($products_NOexist));
//        prnt($products_exist, ' $products_exist '.count($products_exist));
//        prnt($query, ' $name ');
//        self::$CatCategoriesProducts = 0;
//        self::$CatCategoriesStages = 0;
        //CategoriesProducts     CategoriesStages
    //    prnt(self::$CatCategoriesProducts, ' $CatCategoriesProducts ');
        //self::$Offers ;
        
//      prnt(self::$Repertoires,'LoadAllProducts(): Call_GetRepertoireListByStageId(): count:'.count(self::$Repertoires));
//        prnt(self::$Offers,' self::$Offers: count:'.count(self::$Offers));
        
        
        
//        toLog($Repertoires);
//        return; //удалить
//        CategoriesProducts
//        CategoriesStages
        static::UpdateLoadCostCarencys();
        static::UpdateInfoDescritpion();
//        static::DisabledUpdateProductsAndRepertoires();
        static::ParamsSave();
        
//        echo 'Done!!!!!!!!!!!!';
        static::$UpdateRepertoiries = FALSE;
        
        return count($products_NOexist);
    }
    
    /*
     * Сравнение репертуаров с категориями 
     */
    private static function RepertoiresCompare(){
        
        $db = JFactory::getDbo(); 
        $name = 'name_'.JFactory::getLanguage()->getTag();
        $description = 'description_'.JFactory::getLanguage()->getTag(); 
        
	$CatCategoriesProducts = static::$CatCategoriesProducts;
        $query_select = " SELECT * , `$description` description  FROM `#__jshopping_categories` WHERE category_parent_id = $CatCategoriesProducts ; ";
        $categories_bd = JFactory::getDBO()->setQuery($query_select)->loadObjectList('RepertoireId');
        // name_ru-RU, description_ru-RU, category_parent_id, category_id,    
        // ordering 1, products_page 12, products_row 2, access 1, category_add_date, category_publish 1, 
		
	$Repertoires_exist   = array();
	$Repertoires_existUnpublish   = array();
        $Repertoires_NOexist = array();
	
//        foreach($categories_bd as $repertoire_id => $repertoire_bd){  
//            if(isset(static::$Repertoires[$repertoire_id]))
//                $Repertoires_exist[$repertoire_id] = static::$Repertoires[$repertoire_id]; 
//            else {
//                static::$Repertoires[$repertoire_id] = new stdClass; 
//                $Repertoires_NOexist[$repertoire_id] = static::$Repertoires[$repertoire_id]; 
//            }
//            static::$Repertoires[$repertoire_id]->category_image = $repertoire_bd->category_image;
//            static::$Repertoires[$repertoire_id]->description    = $repertoire_bd->$description;
//            static::$Repertoires[$repertoire_id]->category_id    = $repertoire_bd->category_id;
//        }
        
        foreach(static::$Repertoires as $rep_id => $repertoire){ 
            if(!isset($categories_bd[$rep_id])){
                $Repertoires_NOexist[$rep_id] = static::$Repertoires[$rep_id]; 
                continue;    
            }
            else
                $Repertoires_exist[$rep_id] = static::$Repertoires[$rep_id]; 
            
            if($categories_bd[$rep_id]->category_publish==0)
                $Repertoires_existUnpublish[$rep_id] = static::$Repertoires[$rep_id]; 
            
            static::$Repertoires[$rep_id]->category_image = $categories_bd[$rep_id]->category_image;
            static::$Repertoires[$rep_id]->description    = $categories_bd[$rep_id]->description;//$categories_bd[$rep_id]->$description;
            static::$Repertoires[$rep_id]->category_id    = $categories_bd[$rep_id]->category_id;
        }
        
//        if(count($Repertoires_exist) < count($categories_bd)){
//            $only_db = [];
//            $ids = [];
//            foreach ($categories_bd as $cat_id => $categories_bd){
//                if(!isset(static::$Repertoires[$cat_id])){
//                    $only_db[$cat_id] = $categories_bd;
//                    $ids[] = $cat_id;
//                }
//            }
//            $delete = " DELETE FROM `#__jshopping_categories` c WHERE c.category_parent_id = $CatCategoriesProducts AND c.Repertoire_Id IN ("
//                    . join(',', $ids). " ) ; ";
//            if(count($ids)>0)   JFactory::getDBO()->setQuery($delete)->execute();
//            
//            $delete = " DELETE FROM `#__jshopping_products` c WHERE c.Repertoire_Id IN ("
//                    . join(',', $ids). " ) ; ";
//            if(count($ids)>0)   JFactory::getDBO()->setQuery($delete)->execute();
//        }
        
//	foreach(static::$Repertoires as $id=>$repertoire){// Сортировка репертуаров по имеющимся в базе и неимеющихся 
////            foreach($categories_bd as $id_bd=>$repertoire_bd){ 
////                static::$Repertoires[$id]->category_id = 0;
////                if($repertoire->Name == trim($repertoire_bd->$name)){
//////                if($repertoire->Name ==  ($repertoire_bd->$name)){
////                    static::$Repertoires[$id]->category_image = $repertoire_bd->category_image;
////                    static::$Repertoires[$id]->description    = $repertoire_bd->$description;
////                    static::$Repertoires[$id]->category_id    = $id_bd;
////                    break;
////                } 
////            }
//            if($repertoire->category_id == 0)
//                $Repertoires_NOexist[$id] = static::$Repertoires[$id];  
//            else 
//                $Repertoires_exist[$id] = static::$Repertoires[$id]; 
//        }// prnt($repertoire->Name);
		
	
	return (object)['Repertoires_NOexist' => $Repertoires_NOexist, 'Repertoires_exist' => $Repertoires_exist, 'Repertoires_existUnpublish'=>$Repertoires_existUnpublish];
    }
    /*
     * Сравнение продуктов с предложениями
     */
    static function ProductsCompare(){
        
        $db = JFactory::getDbo(); 
        $name = 'name_'.JFactory::getLanguage()->getTag();
        $description = 'description_'.JFactory::getLanguage()->getTag(); 
		
        $querys = array();
        $rprtrs = array_column(static::$Prods, 'RepertoireId');
//        foreach(static::$Prods as $id=>$prod){//             $xx[]= $db->quote($repertoire->$name); 
//            $querys[] = "SELECT ".$db->quote($prod->Name)." Name, '$prod->EventDateTime' EventDateTime, $prod->RepertoireId RepertoireId, $prod->StageId StageId ";
//            //SELECT Name, EventDateTime FROM 
//        } 
        $query_select =  "SELECT p.*, p.`$name` AS Name, p.`$description` AS description "
                . "FROM `#__jshopping_products` p " 
//                . " , ( ".join(" UNION ",$querys)." ) sel "
                . "WHERE p.RepertoireId IN ( ".join(" , ",$rprtrs)." )"
                . " AND p.RepertoireId != 0 " 
//                . " AND p.date_event = sel.EventDateTime " 
//                . "WHERE p.`$name` = sel.Name AND p.date_event = sel.EventDateTime " 
                . "ORDER BY product_id; ";
//        prnt($query, ' $query ',"<br><br>");
        $products_bd = JFactory::getDBO()->setQuery($query_select)->loadObjectList("product_id");
// prnt($products_bd, ' $products_bd '.count($products_bd));
        
        $products_exist = array();
        $products_NOexist = array();

// prnt(static::$Prods, ' $products_bd '.count(static::$Prods));
//		$i = 0;
        foreach (static::$Prods as $id=>$prod){
            foreach ($products_bd as $id_bd=>$product_bd){
                //4276134002019418 Зотова Наталья Леонидовна
                //if($prod->Name == $product_bd->$name && $prod->EventDateTime== $product_bd->date_event){
                if($prod->RepertoireId == $product_bd->RepertoireId && $prod->EventDateTime == $product_bd->date_event){
                    
                    if($id!=$id_bd){
                        static::$Prods[$id_bd] = static::$Prods[$id];                        
                        unset(static::$Prods[$id]);
                        $id = $id_bd;
                    }
                    static::$Prods[$id]->product_id = $id_bd;
                    
                    if(!empty($product_bd->description))    static::$Prods[$id]->description = $product_bd->description; 
                    if(!empty ($product_bd->image))         static::$Prods[$id]->image = $product_bd->image;//image ,   category_image
                    else                                    static::filecopy($prod->image);                            
                    
                    //static::$Prods[$id]->params['EventDateTime']    = static::$Prods[$id]->EventDateTime;
                    static::$Prods[$id]->params['StageId']          = (int)static::$Prods[$id]->StageId;
                    static::$Prods[$id]->params['category_id']      = (int)static::$Prods[$id]->category_id;
                    static::$Prods[$id]->params['RepertoireId']     = (int)static::$Prods[$id]->RepertoireId;
                    static::$Prods[$id]->params['OffersId']         = array_keys(static::$Prods[$id]->Offers);
                    
                    unset($products_bd[$id_bd]);
                }
            }
            if(static::$Prods[$id]->product_id == 0){//$offer->image = $offer->image; //image ,   category_image
                $prod->params = [];
                $prod->params['StageId']          = (int)$prod->StageId;
                $prod->params['category_id']      = (int)$prod->category_id;
                $prod->params['RepertoireId']     = (int)$prod->RepertoireId;
                $prod->params['OffersId']         = array_keys($prod->Offers);
                        
                $products_NOexist[$id] = $prod;
            }
            else
                $products_exist[$id] = $prod;
        }//     self::$Offers = 1446
        

// prnt(static::$Prods, ' $products_bd '.count(static::$Prods));
        
//        $prods_onlyBD = [];
//        foreach ($products_bd as $id_bd=>&$product_bd){
//            if(!empty($product_bd->params))
//                $product_bd->params = json_decode($product_bd->params);
//            if(is_object($product_bd->params)){
//                $product_bd->StageId        = isset($product_bd->params->StageId)?$product_bd->params->StageId:0;
//                $product_bd->category_id    = $product_bd->params->category_id;
//                $product_bd->RepertoireId   = $product_bd->params->RepertoireId;
//                $product_bd->OffersId       = $product_bd->params->OffersId; 
//            //$product_bd->Name           = $product_bd->$name;
//            }
//            else{ 
//                $product_bd->params = '';
//                $product_bd->StageId        = 0;
//                $product_bd->category_id    = 0;
//                $product_bd->RepertoireId   = 0;
//                $product_bd->OffersId       = [];  
//            }
//            $product_bd->EventDateTime  = $product_bd->date_event;
//            //if(!isset(static::$Prods[$id_bd]))
//            if(!array_key_exists($id_bd, static::$Prods)){
//                $prods_onlyBD[$id_bd] = $product_bd; //184, 188
//                //prnt($id_bd, ' $id_bd   $prods_onlyBD   ' );
//            }
//        }
//        prnt(array_keys(static::$Prods), ' $id_bd   static::$Prods  KEYS ');
//        prnt(array_keys($prods_onlyBD), ' $id_bd   $prods_onlyBD  KEYS ');
        
        
//        prnt($prods_onlyBD, ' $prods_onlyBD   Count: '.count($prods_onlyBD),"<br><br>");
//        prnt($products_bd, ' $products_bd   Count: '.count($products_bd),"<br><br>");
//        prnt(static::$Prods, ' static::$Prods \t Count: '.count(static::$Prods),"<br><br>");
        
 
        
        return  [ $products_exist, $products_NOexist, $products_bd];
//        return  (object)['products_exist'=>$products_exist,'products_NOexist'=>$products_NOexist,'products_onlyDB'=>$products_bd];
 
    }

    /*
     * Удаление несуществующих сязей и создание новых на основе ID репертуаров и площадок
     * @return int Колличество добавленных строк связей для репертуаров
     */
    public static function SetCatsToProds(){
        
	$CatCategoriesProducts = static::$CatCategoriesProducts;
        $CatCategoriesStages = static::$CatCategoriesStages;
        $db = JFactory::getDbo(); 
        $name = 'name_'.JFactory::getLanguage()->getTag();
        $description = 'description_'.JFactory::getLanguage()->getTag(); 
        $count = 0;
        
//        $querys = array();
//        $cats_id = array();
        
//        if(count($products)==0)
//            $products = static::$Prods;
        //DELETE t1 FROM tbl_name t1, tbl_name t2 WHERE t1.userID=t2.userID AND t1.eventID=t2.eventID AND t1.ueventID < t2.ueventID
        //DELETE FROM LargeTable WHERE ID IN (SELECT ID FROM TemporarySmallTable);
        $delete = " DELETE FROM `#__jshopping_products_to_categories` WHERE category_id NOT IN (SELECT category_id FROM `#__jshopping_categories`); ";
        JFactory::getDBO()->setQuery($delete)->execute();
            
        $delete = " DELETE FROM `#__jshopping_products_to_categories` WHERE product_id NOT IN (SELECT product_id FROM `#__jshopping_products` ); ";
        JFactory::getDBO()->setQuery($delete)->execute();

        if($CatCategoriesProducts>-1){
//            foreach($products as $id=>$prod){//             $xx[]= $db->quote($repertoire->$name); 
//                $querys[] = "SELECT  $prod->category_id  category_id,  $prod->product_id  product_id, $prod->RepertoireId RepertoireId, $prod->StageId StageId, 1 product_ordering ";
//                            //SELECT Name, EventDateTime FROM 
//                $cats_id[] = $prod->category_id;
//            } 
            $insert  = " INSERT INTO `#__jshopping_products_to_categories` (`category_id`,`product_id`,`product_ordering`) "
                    . " SELECT exst.category_id, exst.product_id, 1 `product_ordering` FROM "
                    . "     (SELECT c.category_id, p.product_id FROM `#__jshopping_products` p, `#__jshopping_categories` c "
                    . "      WHERE c.category_parent_id = $CatCategoriesProducts AND c.RepertoireId = p.RepertoireId ) exst"
                    . " LEFT JOIN  "
                    . "     (SELECT c.category_id, p.product_id FROM `#__jshopping_products` p, `#__jshopping_products_to_categories` pc, `#__jshopping_categories` c "
                    . "      WHERE c.category_parent_id = $CatCategoriesProducts AND c.category_id = pc.category_id AND p.product_id = pc.product_id  ) ll "
                    . " ON exst.category_id = ll.category_id AND  exst.product_id = ll.product_id "
                    . " WHERE ll.category_id IS NULL AND ll.product_id IS NULL ; " ;

            JFactory::getDBO()->setQuery($insert)->execute();
            //JFactory::getDBO()->execute();
            $count = JFactory::getDBO()->getAffectedRows ();
            
            //JFactory::getDBO()->execute();
//prnt($insert, ' $insert ');
//        JFactory::getDBO()->setQuery($insert)->execute();
//prnt(0, ' $count ');        
//prnt($count, ' $count ');      

        
//             //{"StageId":950,"category_id":485,"RepertoireId":6172,"OffersId":[981302]}
//            if(count($cats_id)>0){
//                
//                
//                $delete = "DELETE FROM `#__jshopping_products_to_categories` WHERE category_id IN (".  join(',', $cats_id)."); ";
//                
//                $delete = "DELETE FROM `#__jshopping_products_to_categories` WHERE category_id IN (".  join(',', $cats_id)."); ";
//                JFactory::getDBO()->setQuery($delete)->execute();
//            
//                $count = JFactory::getDBO()->getAffectedRows();
//            
//                $insert =  "INSERT INTO `#__jshopping_products_to_categories`( `category_id`, `product_id`, `product_ordering`) "
//                    . "SELECT * FROM ( ".join(" UNION ",$querys)." ) AS cp; ";
//                JFactory::getDBO()->setQuery($insert)->execute();
//            } 
        }
        // _products_to_categories: product_id, category_id, product_ordering
        // _jshopping_products:     RepertoireId, StageId, params
        // _jshopping_categories:   PlaceId, StageId, RepertoireId
        if($CatCategoriesStages>-1){          
            $insert  = " INSERT INTO `#__jshopping_products_to_categories` (`category_id`,`product_id`,`product_ordering`) "
                    . " SELECT exst.category_id, exst.product_id, 1 FROM "
                    . "     (SELECT c.category_id, p.product_id FROM `#__jshopping_products` p, `#__jshopping_categories` c "
                    . "      WHERE c.category_parent_id = $CatCategoriesStages AND c.StageId = p.StageId ) exst"
                    . " LEFT JOIN  " 
                    . "     (SELECT c.category_id, p.product_id FROM `#__jshopping_products` p, `#__jshopping_products_to_categories` pc, `#__jshopping_categories` c "
                    . "      WHERE c.category_parent_id = $CatCategoriesStages AND c.category_id = pc.category_id AND p.product_id = pc.product_id  ) ll "
                    . " ON exst.category_id = ll.category_id AND  exst.product_id = ll.product_id "
                    . " WHERE ll.category_id IS NULL AND ll.product_id IS NULL ; " ; 
            JFactory::getDBO()->setQuery($insert)->execute();
        }
        
        return $count;
    }
    
    /*
     * Удаление Продуктов и Категорий и соотношения с несуществующими репертуарами, 
     * удаление сесуществующих кроме RepertoireId = 0
     * @param array array products OR DEFAULT attribute
     * @return int $userId MethodName  for request webservice
     */
    public static function ProductsDeleteFromDB(array $products_delete = []){ 
        
        if(count($products_delete)>0){
         
        
            if(is_int($products_delete[0]))
                $prods_id = $products_delete;
            else
                //$prods_id = array_keys($products_delete);
                $prods_id = array_column($products_delete, 'product_id', 'product_id');
        
            $delete = " DELETE FROM `#__jshopping_products_to_categories` pc"
                    . " WHERE  pc.product_id IN "
                    . "(SELECT sel.product_id FROM `#__jshopping_products` p WHERE product_id IN (".  join(',', $prods_id).")) ; ";
            JFactory::getDBO()->setQuery($delete)->execute();
        
            $delete = "DELETE FROM `#__jshopping_products` WHERE product_id IN (".  join(',', $prods_id)."); ";
            JFactory::getDBO()->setQuery($delete)->execute();
            return JFactory::getDBO()->getAffectedRows();
        }    
        
        $rprtrs = array_column(static::$Prods, 'RepertoireId');    
            
            
        if(count($rprtrs)){
 
            if(static::$delete_NoExistCategory)
                $delete = " DELETE FROM `#__jshopping_categories` WHERE RepertoireId NOT IN (".  join(',', $rprtrs).") AND RepertoireId != 0; "; 
            else 
                $delete = " UPDATE `#__jshopping_categories` SET `category_publish` = 0 WHERE RepertoireId NOT IN (".  join(',', $rprtrs).") AND RepertoireId != 0; "; 
            JFactory::getDBO()->setQuery($delete)->execute();
            
            $delete = " DELETE FROM `#__jshopping_products` WHERE RepertoireId NOT IN (".  join(',', $rprtrs).") AND RepertoireId != 0; "; 
            JFactory::getDBO()->setQuery($delete)->execute();
            
            $ps = JFactory::getDBO()->getAffectedRows();
            
            $delete = " DELETE FROM `#__jshopping_products_to_categories` WHERE category_id NOT IN (SELECT category_id FROM `#__jshopping_categories`); ";
            JFactory::getDBO()->setQuery($delete)->execute();
            
            $delete = " DELETE FROM `#__jshopping_products_to_categories` WHERE product_id NOT IN (SELECT product_id FROM `#__jshopping_products` ); ";
            JFactory::getDBO()->setQuery($delete)->execute();
            
            return $ps;
        }
             
    }

    
    
    static function filecopy($fileName, $newName='',  $overWrite = FALSE, $OnlyFullImage = FALSE){ 
        $s = DIRECTORY_SEPARATOR;
        $fileCat = JPATH_ROOT . "{$s}components{$s}com_jshopping{$s}files{$s}img_categories{$s}$fileName"; 
        $file    = JPATH_ROOT . "{$s}components{$s}com_jshopping{$s}files{$s}img_products{$s}";
        if(file_exists($fileCat) && $overWrite ){
            copy($fileCat , $file.$newName.$fileName);
            copy($fileCat , $file."thumb_".$newName.$fileName);
            copy($fileCat , $file."full_".$newName.$fileName);
            return ;
        }
        else if(file_exists($fileCat) && !file_exists($file.$newName.$fileName)  && !$OnlyFullImage){
            copy($fileCat , $file.$newName.$fileName);
            copy($fileCat , $file."thumb_".$newName.$fileName);
            if(!file_exists($file."full_".$newName.$fileName))
                    copy($fileCat , $file."full_".$newName.$fileName); 
            return ;
        }
        else if($OnlyFullImage){
            copy($fileCat , $file."full_".$newName.$fileName); 
            return ;
        }
//            toLog(JPATH_COMPONENT,'JPATH_COMPONENT');
//            toLog(file_exists($fileCat),'file_exists($fileCat)');
//            toLog(!file_exists($file.$fileName),'!file_exists($file.$fileName)');
//            toLog($fileCat,'$fileCat');
//            toLog($file.$fileName,'$file.$fileName');
//            toLog($file."thumb_".$fileName,'$file."thumb_".$fileName');
//            toLog($file."full_".$fileName,'$file."full_".$fileName');
    }
    



 
    





    
    /**
     * Получение(загрузка) секторов зала и присвоение каждой афере сектора
     * @return array 
     */
    static function UpdateOffersSectorName($StageId, $Offers){
        
        $sectors = SoapClientZriteli::Call_GetSectorListByStageId($StageId, FALSE);
        
        $sectors = array_column($sectors, 'Name', 'Id');
        
        foreach ($Offers as $id => &$offer){ 
            $offer->SectorName = $sectors[$offer->SectorId];
            $offer->StageId = $StageId;
//            $offer->StageCatId = $StageCatId;
            $Offers[$offer->Id] = $offer;
            //unset($Offers[$id]);
        } 
        
        return $Offers;
    }

    static function UpdateSectorsFromOffers($StageId, $Offers){
        
    }

    /**
     * обновление картинки и описаний для пустых продуктов из их категорий.
     * Обновление каритнок и описани для продуктов из категории
     * @return void
     */
    public static function UpdateInfoDescritpion(){
        
        $cat = static::$CatCategoriesProducts;
        
        if($cat == -1)            return;
        
        $update = [];
        $words  = [];
        
        $lang = JFactory::getLanguage()->getTag();
        $words[] = $name           = 'name_'.$lang;
        $words[] = $short_desc     = 'short_description_'.$lang;
        $words[] = $description    = 'description_'.$lang; 
        $words[] = $meta_desc      = 'meta_description_'.$lang; 
        $words[] = $meta_keyword    = 'meta_keyword_'.$lang; 
        $words[] = $meta_title    = 'meta_title_'.$lang; 
        
        // short_description_ru-RU   description_ru-RU   meta_description_ru-RU      meta_keyword_ru-RU      meta_title_ru-RU         category_image
        //$update = " SELECT  SUBSTRING_INDEX(SUBSTRING_INDEX(`params`,',\"RepertoireId\"',1),'category_id\":',-1) AS category_id, p.* FROM `pac0x_jshopping_products` AS p WHERE `image`='' AND `RepertoireId`!=0  ORDER BY category_id; ";
        
        foreach ($words as $word){
            $update = " UPDATE `#__jshopping_products` p, `#__jshopping_categories` c "
                      . " SET p.`$word` = c.`$word` "
                      . " WHERE p.`RepertoireId`!=0 AND c.`$word`!='' " //p.`$word`='' AND 
                      . " AND SUBSTRING_INDEX(SUBSTRING_INDEX(p.params,',\"RepertoireId\"',1),'category_id\":',-1) = c.category_id ; ";
            JFactory::getDBO()->setQuery($update)->execute();
        }
        
        $insert = " INSERT INTO `#__jshopping_products_images` (product_id, image_name, name) "
                . " SELECT  p.product_id, c.category_image, c.`$name` "
                . " FROM `#__jshopping_products` AS p,`#__jshopping_categories` c, `#__jshopping_products_to_categories` pc "
                . " WHERE pc.product_id = p.product_id AND pc.category_id = c.category_id "
                . " AND c.RepertoireId = p.RepertoireId AND c.category_parent_id = $cat "
                . " AND p.image='' AND p.RepertoireId!=0 AND c.category_image!='' ORDER BY category_image; "; 	
        JFactory::getDBO()->setQuery($insert)->execute();
        
//        prnt($insert);
//        toLog($insert);

        $select = " SELECT c.category_image, p.product_id, c.`$name` "
                . " FROM `#__jshopping_products` AS p,`#__jshopping_categories` c, `#__jshopping_products_to_categories` pc "
                . " WHERE pc.product_id = p.product_id AND pc.category_id = c.category_id "
                . " AND c.RepertoireId = p.RepertoireId AND c.category_parent_id = $cat "
                . " AND p.image='' AND p.RepertoireId!=0 AND c.category_image!='' ORDER BY category_image; ";
        $images = JFactory::getDBO()->setQuery($select)->loadObjectList('category_image');
        
        $update = " UPDATE `#__jshopping_products` p, `#__jshopping_categories` c, `#__jshopping_products_to_categories` pc  "
                . " SET p.image = c.category_image "
                . " WHERE  pc.product_id = p.product_id AND pc.category_id = c.category_id "
                . " AND c.RepertoireId = p.RepertoireId AND c.category_parent_id = $cat "
                . " AND p.`image`='' AND p.`RepertoireId`!=0 AND c.category_image!='' ; ";
        JFactory::getDBO()->setQuery($update)->execute();
        
        $delete = " DELETE FROM `#__jshopping_products_images` WHERE product_id NOT IN ( SELECT p.product_id FROM `#__jshopping_products` AS p ); ";
        JFactory::getDBO()->setQuery($delete)->execute();
        
        $delete = " DELETE i1 FROM #__jshopping_products_images i1, #__jshopping_products_images i2 "
                . " WHERE i1.product_id = i2.product_id AND  i1.image_name = i2.image_name AND i1.image_id< i2.image_id; ";
        JFactory::getDBO()->setQuery($delete)->execute();
        
        foreach ($images as $image)
            static::filecopy($image->category_image);     
        
        //UPDATE `pac0x_jshopping_products` SET `image`='' WHERE 1;
        
        
//        toLog($select);
//        toLog($images);
        
//{"StageId":950,"category_id":1332,"RepertoireId":6226,"OffersId":[991762],"StageCatId":"1164"}
    }
    
    /*
     * Загрузка Площадок , Добавление площадок в базу, Обновление площадок из базы
     * @return array Категории площадок если выбран родитель
     */
    public static function UpdateLoadStages(JRegistry $params = NULL, $gley = " - "){
         

        
        if(is_null($params))
            $params = static::$Params;
        
        $catId_stages = (int)$params->get('CategoriesStages', -1);
        $StagePlaces_id = $params->get('StagePlaces', []);
        $view_Name_Place = $params->get('view_Name_Place', 0);
        $gley = ($view_Name_Place)? $gley : '';
//        prnt($catId_stages, ' $catId_stages    '.count($catId_stages),"<br><br>");
        if($catId_stages == -1)
            return;
       

        
        $db = JFactory::getDbo(); 
        $lang = JFactory::getLanguage()->getTag();
        $name = 'name_'.$lang;
        $short_desc = 'short_description_'.$lang;
        $description = 'description_'.$lang; 
        
        $query = " SELECT *, `$name` Name, `$short_desc` short_desc, `$description` description "
               . " FROM `#__jshopping_categories` WHERE category_parent_id = $catId_stages; ";
        $cats = JFactory::getDBO()->setQuery($query)->loadObjectList('category_id');//category_id   StageId     
        $cs = array_column($cats, 'StageId', 'category_id');
        
        if($view_Name_Place)
            $NamePlaces = SoapClientZriteli::Call_GetPlaceList(FALSE);
        
        $newCats = [];
        $oldCats = [];
        $CatsDB = [];
        $querys = [];
        foreach ($StagePlaces_id as $Id => $stage){
                list($stageId,$teatrId) = explode ('-',$stage);
                $stageId = (int)$stageId;
                unset($StagePlaces_id[$Id]);
                $s = SoapClientZriteli::Call_GetStageListByPlaceId($teatrId, FALSE);//(int)$teatrId;   
                if(isset($s[$stageId]))
                    $StagePlaces_id[$stageId] = $s[$stageId];
                else{
                    $StagePlaces_id[$stageId] = new stdClass();
                    $StagePlaces_id[$stageId]->Name = '';
                    $StagePlaces_id[$stageId]->Teatr = '';
                }
                $StagePlaces_id[$stageId]->StageId = (int)$stageId;
                $StagePlaces_id[$stageId]->TeatrId = $teatrId;
                $StagePlaces_id[$stageId]->category_id = 0;
                $StagePlaces_id[$stageId]->StageCatId  = 0;
                
                
                $StagePlaces_id[$stageId]->Teatr = ($view_Name_Place)? $NamePlaces[ $stages[$StageId]->PlaceId ]->Name : '' ;
                $StagePlaces_id[$stageId]->Title = ($view_Name_Place)? (trim($StagePlaces_id[$stageId]->Teatr) . $gley) : ''  . trim($StagePlaces_id[$stageId]->Name);
                
                
//                $c = in_array($stageId, $cs);// $cs[$stageId];
            $c_id = array_search($stageId, $cs);// $cs[$stageId];
            if(!is_null($c_id)){
                $StagePlaces_id[$stageId]->category_id = $cats[$c_id]->category_id;
                $StagePlaces_id[$stageId]->StageCatId  = $cats[$c_id]->category_id;
                 unset($cats[$c_id]);
            }
//            else 
//                $StagePlaces_id[$stageId]->category_id = 0;
           
            
//                foreach ($cats as $category_id=>$cat){
//                    if(trim($cat->Name) == trim($StagePlaces_id[(int)$stageId]->Title)){
//                        $StagePlaces_id[(int)$stageId]->category_id = $cat->category_id;
//                    }
//                }
            if($StagePlaces_id[$stageId]->category_id == 0){
                $newCats[$stageId] = &$StagePlaces_id[$stageId];
            }else{
                $oldCats[$stageId] = &$StagePlaces_id[$stageId];
            }
        } 
        
        $f = reset($cats);
        
        if(count($cats)>0){ 
            $query = "DELETE FROM `#__jshopping_categories` WHERE category_parent_id = $catId_stages AND category_id IN (".  join(',', array_keys($cats))."); ";
            
            JFactory::getDBO()->setQuery($query)->execute();
        }
        
        if(count($newCats)==0)
            return $StagePlaces_id;
        
         
        if(is_null($f) || !$f)
            $f = (object)['products_page'=>12,'products_row'=>2];
        
//        prnt($f," \$f");
//        prnt($cats," \$cats");
         
        foreach ($newCats as $cat)
            $querys[] = "\n($catId_stages,1,1,1,1,$f->products_page,$f->products_row,".$db->quote ($cat->Name.$gley.$cat->Teatr) .",".$db->quote ($cat->Address) .",$cat->PlaceId,$cat->Id)";
        
        $query_insert =" INSERT INTO `#__jshopping_categories` "//$f->product_page
                    . " (category_parent_id,category_publish,category_ordertype,ordering,access,products_page,products_row,`$name`,`$short_desc`, PlaceId, StageId)"
                    . " VALUES " .  join(',', $querys)."; "; 
//            prnt($query_insert,"UpdateLoadStages(): \$query_insert - count:".count($querys));
        
        JFactory::getDBO()->setQuery($query_insert)->execute();
        
        
        
//        prnt($query_insert, ' $query_insert    '.count($newCats),"<br><br>");
//        prnt($newCats, ' $query_insert    '.count($newCats),"<br><br>");
//        prnt($f, ' $f    '.count($f),"<br><br>");
        $query = " SELECT *, `$name` Name, `$short_desc` short_desc, `$description` description "
               . " FROM `#__jshopping_categories` WHERE category_parent_id = $catId_stages; ";
        $cats = JFactory::getDBO()->setQuery($query)->loadObjectList('StageId');
        
        
        
        foreach($newCats as $stageId => $stage){
            $StagePlaces_id[$stageId]->category_id = $cats[$stageId]->category_id;
            $StagePlaces_id[$stageId]->StageCatId  = $cats[$stageId]->category_id;
            
//            foreach ($cats as $category_id=>$cat) 
//                if(trim($cat->Name) == trim($StagePlaces_id[$stageId]->Title)) 
//                    $StagePlaces_id[$stageId]->category_id = $cat->category_id; 
        }
             
        
        return $StagePlaces_id;
    }

    /**
     * Оновление цен для изменяющихся цен продуктов.
     */
    public static function UpdateLoadCostCarencys(){
        
    }

    











    /**
     * Загрузка и обновление мест, цен и атрибутов и рядов для представления
     * @param type $productBD
     * @param type $productId
     * @param type $repertoireId
     * @param type $eventDateTime
     * @return type
     */
    public static function LoadAllPiecesFromProducts( $productBD=null, $productId=0, $repertoireId=0, $eventDateTime=''){
//        return;
        if(!static::$UpdateOffers)
            return;
//        prnt($productId, ' $productId    '.count($productId),"<br><br>");
        
        $db = JFactory::getDbo(); 
        $l = JFactory::getLanguage();
        $name = 'name_'.$l->getTag();
        $description = 'description_'.$l->getTag(); 
        
        
//        $path = JPATH_PLUGINS.'/jshopping/PlaceBilet/';    //$path = JPATH_PLUGINS.'/jshopping/PlaceBilet/language/'.'ru-RU';  
//        $l->load('PlaceBilet', $path, 'ru-RU', TRUE);
        
//        JFactory::getLanguage()->load('PlaceBilet', $path, 'ru-RU', TRUE);
        
 // <editor-fold defaultstate="collapsed" desc="Инициализация параметров из атрибутов метода">

        if (is_object($productBD) && is_object($productBD->params)) {

            $params = $productBD->params;
            $RepertoireId = $productBD->RepertoireId;
            $StageId = $productBD->StageId;
            $productBD->EventDateTime = $productBD->date_event;

            $eventDateTime = $productBD->date_event;
            $StageCatId = $params->StageCatId;
        }else if (is_object($productBD) && !is_object($productBD->params)) {

            $params = json_decode($productBD->params);
            $productBD->params = $params;
            if (!is_object($params))
                return;
            $productBD->StageId = $params->StageId;
            $productBD->category_id = $params->category_id;
            $productBD->StageCatId = $params->StageCatId;
            $productBD->RepertoireId = $params->RepertoireId;
            $productBD->OffersId = $params->OffersId;

            $productBD->EventDateTime = $productBD->date_event;

            $RepertoireId = $productBD->RepertoireId;
            $StageId = $productBD->StageId;
            $eventDateTime = $productBD->date_event;

        }else if ($productId != 0 && !is_object($productBD)) {
            $query = "SELECT * FROM `#__jshopping_products` WHERE product_id=$productId LIMIT 1; ";
            $productBD = JFactory::getDBO()->setQuery($query)->loadObject();
            if (!isset($productBD))
                return;
            if (empty($productBD->params))
                return;
            $params = json_decode($productBD->params);
//            prnt($offers, ' $offers    '.count($params) );
            $productBD->params = $params;

            if (is_object($params)) {
//                $productBD->StageId = $params->StageId;
                $productBD->category_id = $params->category_id;
//                $productBD->RepertoireId = $params->RepertoireId;
                $productBD->OffersId = $params->OffersId;
                $productBD->StageCatId = $params->StageCatId;

            }


            $RepertoireId = $productBD->RepertoireId;
            $StageId = $productBD->StageId;
            $productBD->EventDateTime = $productBD->date_event;

            $eventDateTime = $productBD->date_event;
        }else if ($productId == 0 && !is_object($productBD) && $repertoireId != 0 && $eventDateTime != '') {
            $query = " SELECT * FROM `#__jshopping_products` p " // , `#__jshopping_products_to_categories` pc, `#__jshopping_categories` c
                    . " WHERE  p.`RepertoireId` = $repertoireId  " // pc.product_id = p.product_id AND pc.category_id = c.category_id 
                    . " AND c.`date_event`= '$eventDateTime' LIMIT 1; "; //         {"StageId":"10","category_id":475,"RepertoireId":6210,"OffersId":[989086]}
            $productBD = JFactory::getDBO()->setQuery($query)->loadObject(); //      {"StageId":950,"category_id":485,"RepertoireId":6172,"OffersId":[981302]}
            if (!isset($productBD))
                return;
            if (empty($productBD->params))
                return;
            $params = json_decode($productBD->params);
            $productBD->params = $params;

            if (is_object($params)) {
//                $productBD->StageId = $params->StageId;
                $productBD->category_id = $params->category_id;
//                $productBD->RepertoireId = $params->RepertoireId;
                $productBD->OffersId = $params->OffersId;
                $productBD->StageCatId = $params->StageCatId;

            }
            $RepertoireId = $productBD->RepertoireId;
            $StageId = $productBD->StageId;
            $productBD->EventDateTime = $productBD->date_event;

            $eventDateTime = $productBD->date_event;
        }else
            return;
        // </editor-fold>
 
        if($repertoireId == 0 || $eventDateTime == '')
            return;
    
        static::$UpdateOffers = FALSE;
        
        $productId = $productBD->product_id;
        $StageCatId =(isset($productBD->StageCatId))? $productBD->StageCatId : 0;
        $category_id = (isset($productBD->category_id))? $productBD->category_id: 0;
        $OffersId = (isset($productBD->OffersId))? $productBD->OffersId: [];
        
// prnt($OffersId, "\$RepertoireId:->  $RepertoireId  <br>\$eventDateTime:->  $eventDateTime    <br>\$category_id:->  $category_id    <br>\$StageCatId:->  $StageCatId       <br>\$StageId:->  $StageId   <br>\$OffersId"  ); 
//        prnt($OffersId, ' $OffersId'  );
        
        $offers = SoapClientZriteli::Call_GetOfferListByEventInfo($repertoireId, $eventDateTime, FALSE); 
//         prnt($offers, ' $offers    '.count($offers),"<br><br>");
//        $sectors = SoapClientZriteli::Call_GetSectorListByStageId($productBD->StageId, FALSE);
        $offers = static::UpdateOffersSectorName($productBD->StageId,$offers);
// prnt( $offers  , ' $offers    ','',2);

        /**
         * Места
         */
        $SeatS = array();
        $MestaAttr = [];
        $SeatsAttr = [];
 
        
// <editor-fold defaultstate="collapsed" desc="Инициализация Атрибутов">


        foreach ($offers as &$offer) {
            $offer->category_id = $category_id;

            $offer->StageCatId = $StageCatId;


            foreach ($offer->SeatList as $Seat) {
                $OrderId = $offer->SectorId * 1000 + $offer->Row;
                
                $Seat = (object) [ 'OrderId' => $OrderId,
                            'StageId' => $offer->StageId,
                            'StageCatId' => $StageCatId,
                            'RepertoireId' => $offer->RepertoireId,
                            'category_id' => $offer->category_id,
                            'SectorId' => $offer->SectorId,
                            'SectorName' => $offer->SectorName,
                            'OfferId' => $offer->Id,
                            'EventDateTime' => $offer->EventDateTime,
                            'AgentId' => $offer->AgentId,
                            'ETicket' => $offer->ETicket,
                            'NominalPrice' => $offer->NominalPrice,
                            'AgentPrice' => $offer->AgentPrice,
                            'Row' => $offer->Row,
                            'Seat' => $Seat];
                $SeatS[] = $Seat;
 
                if (!isset($SeatsAttr[$OrderId])) {
                    $attr = new stdClass();
                    //$SeatsAttr[$Seat->SectorId][$Seat->Row]->             // Умолчания присвоить.
                    $attr->attr_admin_type = 4;
                    $attr->group = 0;
                    $attr->allcats = 0;
                    $attr->independent = 1;
                    $attr->attr_type = 0;
                    $attr->attr_ordering = 1;
                    //$attr->attr_id = 0;

                    $attr->OrderId = $OrderId;

                    $attr->SectorName = $Seat->SectorName;
                    if ($Seat->Row < 10)

                        $pr = "  ";
                    else if ($Seat->Row < 100)

                        $pr = " ";
                    else

                        $pr = "";
                    $attr->Name = $pr . $Seat->Row . JText::_('JSHOP_ROW') . JText::_('JSHOP_U1') . $Seat->SectorName . JText::_('JSHOP_U2');
                    $attr->$name = $attr->Name;
                    $attr->cat_s = [$StageCatId]; //(array)
                    $attr->cats = serialize((array) $StageCatId);
                    $attr->Row = $Seat->Row;


                    $attr->StageCatId = $StageCatId;
                    $attr->StageId = $offer->StageId;
                    $attr->_RepertoireId = $offer->RepertoireId;
                    $attr->_category_id = $offer->category_id;
                    $attr->SectorId = $offer->SectorId;
                    $attr->_EventDateTime = $offer->EventDateTime;
//                    $attr->AgentId = $offer->AgentId;
//                    $attr->ETicket = $offer->ETicket;
//                    $attr->SectorId = $offer->SectorId;


                    $attr->attr_id = 0;


//                    prnt($Seat->Row ,' $row:   ' );  
//                    prnt($Order  );   
//                    $MestaAttr[] =  $attr;
//                    $SeatsAttr[$offer->SectorId][$offer->Row] = $attr;
//                    $SeatsAttr[$offer->SectorId][$offer->Row]->SeatSCount = 0;
//                    $SeatsAttr[$offer->SectorId][$offer->Row]->SeatS = [];
                    $SeatsAttr[$OrderId] = $attr;
                    $SeatsAttr[$OrderId]->SeatSCount = 0;
                    $SeatsAttr[$OrderId]->SeatS = [];
                }
                $SeatsAttr[$OrderId]->SeatSCount += 1;
                $SeatsAttr[$OrderId]->SeatS[] = $Seat;  //Раскоментировать!!!!!!!!!!!!!!!!
////                $SeatsAttr[$OrderId]->SeatSCount = count($SeatsAttr[$Seat->SectorId][$Seat->Row]->SeatS);
////                unset($SeatsAttr[$OrderId]->SeatS);
            }
        }
        // </editor-fold>
        
        ksort($SeatsAttr); 
        $MestaAttr = &$SeatsAttr;
 
        
        
        
        
        
//prnt($SeatsAttr ,' $SeatsAttr   ','',1 );    
//prnt($MestaAttr ,' $MestaAttr   ','',1 );   
//prnt($SeatS ,' $SeatS   '  );   
        
        
        
//        $attrs_new = [];
//        $attrs_exist = [];
//        $attrs_db = [];
        
        // Добавление атрибутов в базу

 
       
//--------------------------------------------------------------------------------------        
//                                  ДОбавление Атрибутов - добавление рядов
//--------------------------------------------------------------------------------------        
 
        
// <editor-fold defaultstate="collapsed" desc=" $attribute_compare(): функция сравнения атрибутов">            
        $attribute_compare = function() use (&$StageCatId, &$MestaAttr)//, &$attrs_new, &$attrs_exist, &$attrs_db
            {
                $attrs_new = [];  
                $attrs_exist = [];
                $attrs_db = [];
            $select = "SELECT * FROM `#__jshopping_attr` ".(($StageCatId)?" WHERE StageCatId = $StageCatId  ":"  "); //WHERE product_id=$productId
            $select .= " ORDER BY attr_ordering, SectorId, Row ; ";
//             prnt($select, ' $select    '.count($select));
            $attrs_db = JFactory::getDBO()->setQuery($select)->loadObjectList('attr_id');
            foreach ($attrs_db as &$attr){
//                if(empty($attr->cats))
//                    $attr->cat_s = [];
//                else 
//                    $attr->cat_s = unserialize($attr->cats);
                
                foreach ($MestaAttr as $id=> &$mesto){
                    if($attr->StageCatId == $mesto->StageCatId && $attr->Row == $mesto->Row && $attr->SectorId == $mesto->SectorId){
                        $MestaAttr[$id]->attr_id = $attr->attr_id;//$mesto->attr_id
                        $attrs_exist[$attr->attr_id] = $mesto;
                        unset($attrs_db[$attr->attr_id]);
                    }
                }
            }
            
            foreach ($MestaAttr as $attr_id => &$mesto) {
                if ($mesto->attr_id == 0)
                    $attrs_new[] = $mesto;  
            }

            
//            prnt($attrs_db,'$attrs_db COUNT:'.  count($attrs_db));
//        return; 
//            $tuple = (object)compact($attrs_new, $attrs_exist, $attrs_db);
//            $tuple = (object)compact('attrs_new', 'attrs_exist', 'attrs_db');
          //  $tuple = ['attrs_new'=>$attrs_new, 'attrs_exist'=>$attrs_exist, 'attrs_db'=>$attrs_db];
            
          //  prnt($tuple,'$tuple COUNT:'.  count($tuple));
          //  return;
//            $tuple =  compact($attrs_new, $attrs_exist, $attrs_db);
//            
//              prnt($tuple,'$tuple COUNT:'.  count($tuple));
             
//            $tuple = ['attrs_new'=>$attrs_new, 'attrs_exist'=>$attrs_exist, 'attrs_db'=>$attrs_db];
//                 prnt($tuple,'$tuple 1 COUNT:'.  count($tuple));
//            
//              return;
//              return compact($attrs_new, $attrs_exist, $attrs_db);
//            return $tuple;
//               return (object)['attrs_new'=>$attrs_new, 'attrs_exist'=>$attrs_exist, 'attrs_db'=>$attrs_db];
//               return ['attrs_new'=>$attrs_new, 'attrs_exist'=>$attrs_exist, 'attrs_db'=>$attrs_db];
               return [ $attrs_new,  $attrs_exist,  $attrs_db];
        };
// </editor-fold>
 
        list($attrs_new, $attrs_exist, $attrs_db) = $attribute_compare(); 
      
// <editor-fold defaultstate="collapsed" desc="Запрос БД добавления в базу несуществующих атрибутов">
        $querys = [];
        foreach ($attrs_new as $sort => $attr)
            $querys[] = " ( $attr->StageId,$attr->Row,$attr->SectorId,$attr->StageCatId," . $db->quote($attr->Name) . ", " . $db->quote($attr->cats) . ",   4,0,0,1,0,$attr->OrderId ) "; //$db->quote($db->escape($repertoire->Name),false)
 
        $query_insert = " INSERT INTO `#__jshopping_attr` "
                . "( StageId,`Row`,SectorId,StageCatId,`$name`,cats,     attr_admin_type,`group`,allcats,independent,attr_type,attr_ordering) "
                . " VALUES " . join(', ', $querys) . " ; ";
        if (count($querys) > 0)            
            JFactory::getDBO()->setQuery($query_insert)->execute(); // 
//             prnt($query_insert,' $query_insert   ' );

//            </editor-fold> 
 
       
//--------------------------------------------------------------------------------------        
//                                  ДОбавление мест для продукта
//--------------------------------------------------------------------------------------        
 
// <editor-fold defaultstate="collapsed" desc="$attr_values_compare(): функция сравнения мест">

        $attr_values_compare = function () use(&$MestaAttr, &$SeatS) {
 
            $name = 'name_' . JFactory::getLanguage()->getTag();
 
            $attr_values_new = [];

            $attr_values_exist = [];
            $attr_values_db = [];
 
            $attrs_ids = array_column($MestaAttr, 'attr_id');
            $select = "SELECT *, `$name` Name, CAST(TRIM(`$name`) AS UNSIGNED)+0 Seat, 1*TRIM(`$name`) Seat2 FROM `#__jshopping_attr_values` WHERE attr_id IN ( " . join(',', $attrs_ids) . " ) ; "; //WHERE product_id=$productId 
            if (count($attrs_ids))
                $attr_values_db = JFactory::getDBO()->setQuery($select)->loadObjectList('value_id');
//             prnt($select, ' $select    '.count($select));


            foreach ($SeatS as $id => &$seat) {
                $seat->attr_id = $MestaAttr[$seat->OrderId]->attr_id;
                $seat->value_id = 0;
                
                if($seat->attr_id == 748 && $attr_value_db->attr_id == 748){
                    prnt ($seat->Seat);
//                    prnt ($id);
//                    prnt ($attr_value_db->Seat);
//                    prnt ($id);
                }
 
                foreach ($attr_values_db as $value_id => &$attr_value_db) {
                    
                    if ((int)$seat->Seat == (int)trim($attr_value_db->Seat) && (int)$seat->attr_id == (int)$attr_value_db->attr_id) {
                        $seat->value_id = (int)$attr_value_db->value_id;
                        $attr_values_exist[$value_id] = $seat;
//                        unset($attr_values_db[$value_id]); // Почему то без комментирования не работает эта строчка, 
                    }
                }
            }
            foreach ($SeatS as $id => &$seat) {
                if ($seat->value_id != 0) continue;
                
                
//                continue;
                $SeatS[$id]->Seat = (int) trim($seat->Seat);
//                prnt ($seat->Seat,  '$seat->Seat '.gettype ($seat->Seat));
                    $id = ($seat->OrderId*1000)+($seat->Seat);
                    $attr_values_new[$id] = $seat;
            }


            return [$attr_values_new, $attr_values_exist, $attr_values_db];
        }; 
// </editor-fold>
 
        list($attr_values_new,$attr_values_exist,$attr_values_db) = $attr_values_compare();

 // <editor-fold defaultstate="collapsed" desc="Запрос БД добавления в базу несуществующих мест">
        
        $attr_values_new = array_sorting($attr_values_new, 'Seat');
        $querys = [];
        foreach ($attr_values_new as $sort => $att_v)
            $querys[] = " ( $att_v->attr_id,$att_v->Seat,0) "; //$db->quote($db->escape($repertoire->Name),false)

        $query_insert = " INSERT INTO `#__jshopping_attr_values` "
                . "( attr_id,`$name`,       value_ordering ) "
                . " VALUES " . join(', ', $querys) . " ; ";
        if (count($attr_values_new) > 0)            
            JFactory::getDBO()->setQuery($query_insert)->execute(); // 
//             prnt($query_insert,' $query_insert   ' );

//            </editor-fold> 
        
 
//--------------------------------------------------------------------------------------        
//                                  ДОбавление цен для продукта
//--------------------------------------------------------------------------------------
        
        if($productId == 0) 
            return;
        
// <editor-fold defaultstate="collapsed" desc="Вычисление наценки на билеты">

        $percent = static::$Jackpot / 100;

        list($CostRound) = explode('-', static::$CostCurrency);
 
        foreach ($SeatS as &$seat) {
            $Cost1 = $seat->AgentPrice * $percent + $seat->AgentPrice; 
                $polovina =  $CostRound / 2;$ost = $Cost1 % $CostRound;
                
            if ($polovina < $ost)
                $seat->CostPrice = ceil($Cost1 / $CostRound) * $CostRound; // Большее
            else if($polovina > $ost)
                $seat->CostPrice = floor($Cost1 / $CostRound) * $CostRound; // меньшее 
            else if($CostRound == $ost)
                $seat->CostPrice = $Cost1; // меньшее 
            else
                $seat->CostPrice = ceil($Cost1 / $CostRound) * $CostRound; // Большее
            
//            $seat->CostPrice = $Cost;
//            prnt($seat->AgentPrice . " - $Cost1 -$CostRound) " . $seat->CostPrice);
        }
        // </editor-fold>
         
// <editor-fold defaultstate="collapsed" desc="$prod_values_compare(): метод сравнения цен с базой">

        $prod_values_compare = function () use (&$MestaAttr, &$SeatS, &$productId) { // _jshopping_products   product_id,    
            /**
             * Места новые добавленные 
             */
            $prod_values_new = []; 
            /**
             * Места существующие
             */
            $prod_values_exist = []; 
            /**
             * Места требующие удаления
             */
            $prod_values_db = []; 
            /**
             * Места требующие обновления цен
             */
            $prod_values_update = [];


            $select = " SELECT * "
                    . " FROM `#__jshopping_products_attr2` "
                    . " WHERE  	product_id = $productId ; "; //WHERE product_id=$productId  
            $prod_values_db = JFactory::getDBO()->setQuery($select)->loadObjectList('id');




            foreach ($SeatS as $id => $seat) {
                $seat->cost_id = 0;
                foreach ($prod_values_db as $id_db => $prod_val_db) {
                    if ($seat->attr_id == $prod_val_db->attr_id && $seat->value_id == $prod_val_db->attr_value_id) {

                        $seat->cost_id = $prod_val_db->id;
                        
                        if($seat->CostPrice != $prod_val_db->addprice){
                            $prod_values_update[$id] = $seat;
//                            prnt($seat);
                        }

                        $prod_values_exist[$id] = $seat;
                        unset($prod_values_db[$id_db]);
                    }
                }
                if ($seat->cost_id == 0)
                    $prod_values_new[$id] = $seat;
            }

 

            return [$prod_values_new, $prod_values_exist, $prod_values_db, $prod_values_update];
        };
        // </editor-fold>
 
        list($prod_values_new, $prod_values_exist, $prod_values_db, $prod_values_update) = $prod_values_compare();
 
// <editor-fold defaultstate="collapsed" desc="Запрос БД добавления в базу несуществующих Цен">
        
        $prod_values_new = array_sorting($prod_values_new, 'Seat');
        $querys = [];
        foreach ($prod_values_new as $sort => $att_v)
            $querys[] = " ( $att_v->CostPrice, $att_v->value_id, $att_v->attr_id ,$att_v->OfferId , $productId, '+') "; //$db->quote($db->escape($repertoire->Name),false)

        $query_insert = " INSERT INTO `#__jshopping_products_attr2` "
                . "( addprice, attr_value_id, attr_id, OfferId, product_id, price_mod) "
                . " VALUES " . join(', ', $querys) . " ; ";
        if (count($prod_values_new) > 0)            
            JFactory::getDBO()->setQuery($query_insert)->execute(); // 
//             prnt($query_insert,' $query_insert   ' );

//            </editor-fold> 
 

// <editor-fold defaultstate="collapsed" desc="Удаление остутсвующих цен из базы">

        if (count($prod_values_db) > 0) { 
            $keys = array_column($prod_values_db, 'id'); //'value_id'
            $delete = " DELETE FROM `#__jshopping_products_attr2` "
                . " WHERE id IN ( " . join(', ', $keys) . ") ; ";
            if (count($keys)) 
            JFactory::getDBO()->setQuery($delete)->execute(); 
        }
        // </editor-fold>
        
// <editor-fold defaultstate="collapsed" desc="обновление существующих цен в базе">

//        $prod_values_update[] = (object)['cost_id'=>5379,'CostPrice'=>123];
//        $prod_values_update[] = (object)['cost_id'=>5380,'CostPrice'=>321];
//        $prod_values_update[] = (object)['cost_id'=>5381,'CostPrice'=>666];
        
        if (count($prod_values_update) > 0) { 
            $update = "";
            $querys = [];
            
            foreach ($prod_values_update as $v)
                $querys[] = " SELECT $v->cost_id AS id, $v->CostPrice AS addprice " ;
            $update = " UPDATE `#__jshopping_products_attr2` at2, (". join(' UNION ',$querys ) .") AS sel   SET at2.addprice = sel.addprice WHERE at2.id = sel.id ; "; 
//            prnt($update);
            if(count($prod_values_update))
                JFactory::getDBO()->setQuery($update)->execute();
        }
        // </editor-fold>

//        list($prod_values_new, $prod_values_exist, $prod_values_db, $prod_values_update) = $prod_values_compare();
     
        
  //    prnt($prod_values_exist); 
//prnt($prod_values_new ,' $prod_values_new   '  );      
//prnt($prod_values_new ,' $prod_values_new   '  );
//prnt($prod_values_exist ,' $prod_values_exist   ' );
//prnt($prod_values_db,' $prod_values_db   ' );
 //    prnt($SeatS ,' $SeatS   ' );   
        

 
        
        
//         prnt($productBD, ' $productBD    '.count($productBD),"<br><br>");
        //prnt(array_slice($sectors, -2), " \$sectors->  -  ID: $productBD->StageId  - Count: ".count($sectors) );
        //prnt(array_slice($offers, -2), ' $offers    '.count($offers) );
//        prnt($offers, ' $offers    '.count($offers) );
//        prnt(array_slice($offers, -2), ' $offers    '.count($offers) );
        //отсортировать по группам чтобы ---------------------------------------------------------------------- 
        
         
        //  pac0x_jshopping_attr            Ряды,Сектор
        //  pac0x_jshopping_attr_groups     Стороны
        //  pac0x_jshopping_attr_values     Места
        //  pac0x_jshopping_products_attr2  Цены мест
        
        static::$UpdateOffers = FALSE;
    }
    
}