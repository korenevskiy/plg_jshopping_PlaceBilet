<?php
 /** ----------------------------------------------------------------------
 * plg_PlaceBilet - Plugin Joomshopping Component for CMS Joomla
 * ------------------------------------------------------------------------
 * author    Sergei Borisovich Korenevskiy
 * @copyright (C) 2019 //explorer-office.ru. All Rights Reserved. 
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 * @package plg_PlaceBilet
 * Websites: //explorer-office.ru/download/joomla/category/view/1
 * Technical Support:  Forum - //fb.com/groups/multimodulefb.com/groups/placebilet/
 * Technical Support:  Forum - //vk.com/placebilet
 * -------------------------------------------------------------------------
 **/ 
    defined( '_JEXEC' ) or die( 'Restricted access' );
    defined('DS') || define('DS', DIRECTORY_SEPARATOR);
 
//http://www.php.su/debug_backtrace
//http://www.php.su/functions/?func-get-arg
//http://www.php.su/functions/?cat=funchand
     

if(!function_exists('toStr')){
    function toStr( $value=''){//SimpleXMLElement
    //return $value;
//    if ($value->count()==0)
//            return $value;
    //return (string)$value;
    return trim((string)$value);//->__toString()
}
}

if(!function_exists('array_sorting')){
function array_sorting($array = [], $field = ''){
    if(count($array) == 0)
        return [];
    if($field == '') 
        ksort($array); 
    else{
        $keys = array_column($array, $field);
        array_multisort($keys, SORT_ASC, $array);
    }
    return $array;
}
}




if(!function_exists('toLog')){ 
/**
 * Debug log function
 * @version 0.1
 */
function toLog($obj = '', $head = '', $file='', $view = FALSE, $debug = FALSE):string{
     
    
    return $head;
    //JFactory::getApplication()->enqueueMessage(print_r($query,true));
}

}


if(!function_exists('toPrint')){ 
/**
 * Debug dump function
 */
function toPrint($obj = NULL, $head = "", $count = 1, $show = TRUE, $debug = FALSE):string{
    if(empty($debug) || empty($show))     
        return $head;
    
    $deb_tr = debug_backtrace();
    if(count($deb_tr)>1)
            list($_file,$_method) = $deb_tr;
    if(count($deb_tr)==1)
            $_method = $_file = $deb_tr[0];
        $paths = explode(DS, $_file['file']) ;
//        var_dump($_file['file']);
//        var_dump($paths);
//        var_dump(DS);
    if($head)
            $head = "<br>".$head;
    if($deb_tr){
            $head = "<span style='opacity:0.15'>".ucfirst($_method['class']??'').ucfirst($_method['type']??'').ucfirst($_method['function']??'')
                . "() /".($paths[count($paths)-2]??'') .'/'.(end($paths)??'') .' ('.($_file['line']??'') .')</span>'.$head;
    } 
    
//    echo "<hr style='opacity:0.2'>";
        
    if(is_array($obj) && ($obj = array_slice($obj, 0, ($count?$count:NULL), TRUE)))
        echo "<pre>$head<br>(".count($obj).")" . print_r ($obj,TRUE) . "</pre>";
    elseif(is_array($obj) && empty($obj))
        echo "<pre>array(): $head<br></pre>";
    elseif(is_null($obj))
        echo "<div>$head</div>";
    else 
        echo "<pre>$head <br>". gettype($obj) .":". print_r ($obj,TRUE) . "</pre>";
    
    return $head;
}

}
 