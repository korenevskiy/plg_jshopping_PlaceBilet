<?php
 /** ----------------------------------------------------------------------
 * plg_PlaceBilet - Plugin Joomshopping Component for CMS Joomla
 * ------------------------------------------------------------------------
 * author    Sergei Borisovich Korenevskiy
 * @copyright (C) 2019 //explorer-office.ru. All Rights Reserved. 
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 * @package plg_PlaceBilet
 * Websites: //explorer-office.ru/download/joomla/category/view/1
 * Technical Support:  Forum - //fb.com/groups/multimodulefb.com/groups/placebilet/
 * Technical Support:  Forum - //vk.com/placebilet
 * -------------------------------------------------------------------------
 **/ 

/*
 * 1
 * Назначить значение свойства в конструкторе с ключом DEMO языковывого словаря.
 * 
 * 2
 * Загрузить в контсрукторе этот файл
 * 
 * 3
 * в этом файле переопределить значение свойства ключами ПРО версии.
 * 
 * 4
 * использовать константы из файлаёё    
 * 
 */

$this->ver = '{"":"", "":"", "":"", "":"", "":"", "":"", "":"", "":""}';


//CAST5-CBC, CAST5-CFB, CAST5-ECB, CAST5-OFB,   RC2-CBC, RC2-CFB, RC2-ECB, RC2-OFB, RC4, RC4-40, RC4-HMAC-MD5,      ,BF-CBC BF-CFB, BF-ECB, BF-OFB, 
//SEED-CBC, SEED-CFB, SEED-ECB, SEED-OFB, , ,  RC4,        IDEA-CBC, IDEA-CFB, IDEA-ECB, IDEA-OFB, , , 




//$decrypted = openssl_encrypt ($text, 'RC4', ' '); 
//$crypttext = openssl_decrypt ($decrypted, 'RC4', ' ');
//crypt ( string $str [, string $salt ] ) : string
//$hashtext = crc32 ($text):int;
