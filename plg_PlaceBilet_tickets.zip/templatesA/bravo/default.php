<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */


use \Joomla\CMS\Language\Text as JText;

?>
<table>
	<tr>
		<td><?= JText::_('JSHOP_PLACE_BILET_DESC') ?></td>
		
	</tr>
	
</table>